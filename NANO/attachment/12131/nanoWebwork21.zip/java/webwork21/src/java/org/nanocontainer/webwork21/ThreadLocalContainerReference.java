/*****************************************************************************
 * Copyright (C) NanoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the LICENSE.txt file.                                                     *
 *                                                                           *
 *****************************************************************************/
/*
 * Created on May 3, 2004
 */
package org.nanocontainer.webwork21;

import org.picocontainer.defaults.ObjectReference;

/**
 * TODO this class should be temporary waiting for a wider scope (wider than ww2
 * integration) ThreadLocalObjectReference
 * 
 * @author <a href="mailto:cleclerc@pobox.com">Cyrille Le Clerc </a>
 */
public class ThreadLocalContainerReference implements ObjectReference {

	private static ThreadLocal container = new ThreadLocal();

	/**
	 *  
	 */
	public ThreadLocalContainerReference() {
		super();
	}

	/**
	 * @see org.picocontainer.defaults.ObjectReference#get()
	 */
	public Object get() {
		return container.get();
	}

	/**
	 * @see org.picocontainer.defaults.ObjectReference#set(java.lang.Object)
	 */
	public void set(Object item) {
		container.set(item);
	}

}