package org.nanocontainer.sample.nanoweb;

/*
$Id:$
$Log:$
*/

/**
 * User: pelleb
 * Date: Aug 10, 2004
 * Time: 1:42:23 PM
 */
public class SalaryCalculator {
    private String name;
    private String salary;

    public String getName() {
        if (name==null)
            return "Enter name";
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSalary() {
        if (salary==null)
            return "0";
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getMonthlySalary(){
        return Double.toString(Double.parseDouble(salary)/12);
    }

    public String calculate(){
        if (name==null||salary==null)
            return "input";
        else
            return "view";
    }
}
