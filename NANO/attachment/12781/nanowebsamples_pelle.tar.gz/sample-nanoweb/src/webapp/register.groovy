class Person {
	name=""
	age=0
	java.util.Map map

	Person(java.util.Map database) {
	   map=database;
	   if (name!=""&&age==0) {
		age=map.get(name)
	   }
	}
	
	enter() {
		if (age==0&&name!="")
			age=map.get(name)
		return "input"
	}
	
	search() {
		return "search"
	}	
	register() {
		if (name==""||age==0) 
			return "error"
		map.put(name,age)
		return "success"	
	}
	view() {
		if (name=="")
			return "error"
		age=map.get(name);
		return "view"
	}

	list(){
		return "list"
	}		
}
