package org.nanocontainer.nanoweb.defaults;

import ognl.Ognl;
import ognl.OgnlException;
import org.nanocontainer.nanoweb.ActionExecutor;
import org.nanocontainer.nanoweb.CachingScriptClassLoader;
import org.nanocontainer.nanoweb.ScriptException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Enumeration;

/**
 *
 * @author gjoseph
 * @author $Author: $ (last edit)
 * @version $Revision: $
 */
public class DefaultActionExecutor implements ActionExecutor {
    private HttpServletRequest httpServletRequest;
    private HttpServletResponse httpServletResponse;
    private CachingScriptClassLoader cachingScriptClassLoader;

    public DefaultActionExecutor(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, CachingScriptClassLoader cachingScriptClassLoader) {
        this.httpServletRequest = httpServletRequest;
        this.httpServletResponse = httpServletResponse;
        this.cachingScriptClassLoader = cachingScriptClassLoader;
    }

    public Object getActionObjectKey() {
        return getScriptPathWithoutExtension(httpServletRequest);
    }

    public String executeAction(Object actionObject) throws ServletException, IOException {
        Object scriptPathWithoutExtension = getScriptPathWithoutExtension(httpServletRequest);
        if (actionObject == null) {
            // Try to get an action from a script (groovy)
            try {
                actionObject = getScriptAction(httpServletRequest, scriptPathWithoutExtension + ".groovy");
            } catch (ScriptException e) {
                handleScriptException(httpServletRequest, httpServletResponse, e);
            } catch (IOException e) {
                throw new ServletException(e);
            }
        }

        if (actionObject == null) {
            String msg = "No action found for '" + scriptPathWithoutExtension + "'";
            throw new ServletException(msg);
        }

        setPropertiesWithOgnl(httpServletRequest, actionObject);

        String servletPath = Util.getServletPath(httpServletRequest);
        int dot = servletPath.lastIndexOf('.');
        String actionMethod = servletPath.substring(servletPath.lastIndexOf('/') + 1, dot);
        String result = execute(actionObject, actionMethod);

        httpServletRequest.setAttribute("action", actionObject);

        return result;
    }

    private Object getScriptPathWithoutExtension(HttpServletRequest httpServletRequest) {
        String servletPath = Util.getServletPath(httpServletRequest);
        String scriptPathWithoutExtension = servletPath.substring(0, servletPath.lastIndexOf('/'));
        return scriptPathWithoutExtension;
    }

    private Object getScriptAction(HttpServletRequest httpServletRequest, String scriptPath) throws IOException, ScriptException {
        Object result = null;
        result = cachingScriptClassLoader.getClassInstance(scriptPath, httpServletRequest);
        return result;
    }

    private void setPropertiesWithOgnl(HttpServletRequest servletRequest, Object action) throws ServletException {
        Enumeration parameterNames = servletRequest.getParameterNames();
        while (parameterNames.hasMoreElements()) {
            String parameterName = (String) parameterNames.nextElement();
            String parameterValue = servletRequest.getParameter(parameterName);
            try {
                Ognl.setValue(parameterName, action, parameterValue);
            } catch (OgnlException e) {
                throw new ServletException(e);
            }
        }
    }

    private String execute(Object actionObject, String actionMethodName) throws ServletException {
        Method actionMethod = null;
        try {
            actionMethod = actionObject.getClass().getMethod(actionMethodName, null);
        } catch (NoSuchMethodException e) {
            String message = "The " + actionObject.getClass().getName() + " doesn't have the method " + actionMethodName + "()";
            throw new ServletException(message, e);
        }
        try {
            String view = (String) actionMethod.invoke(actionObject, null);
            return view;
        } catch (IllegalAccessException e) {
            String message = actionObject.getClass().getName() + "." + actionMethodName + "() isn't public";
            throw new ServletException(message, e);
        } catch (InvocationTargetException e) {
            String message = "Failed to actionMethod " + actionObject.getClass().getName() + "." + actionMethodName + "()";
            throw new ServletException(message, e);
        }
    }

    private void handleScriptException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ScriptException e) throws IOException {
        e.printStackTrace();
        // Print the stack trace and the script (for debugging)
        PrintWriter writer = httpServletResponse.getWriter();
        writer.println("<html>");
        writer.println("<pre>");
        e.printStackTrace(writer);
        writer.println(httpServletRequest.getRequestURI());
        URL scriptURL = e.getScriptURL();
        InputStream in = scriptURL.openStream();
        int c;
        while ((c = in.read()) != -1) {
            writer.write(c);
        }
        writer.println("</pre>");
        writer.println("</html>");
    }
}
