using System;
using NUnit.Framework;
using PicoContainer.Defaults;
using PicoContainer;
using NanoContainer.Script.VB;
using NanoContainer.Script.Xml;
using System.IO;
using System.Text;
using System.Collections;

namespace Test.Script.Xml 
{
	//PSANTOS new
	[TestFixture]
	public class XmlContainerBuilderTestCase : AbstractScriptedContainerBuilderTestCase 
	{
		[Test]
		public void TestSimpleContent()
		{
			string xmlScript = @"
				<container>
					<component-instance key='Hello'>XML</component-instance>
					<component-instance key='Hei'>XMLContinerBuilder</component-instance>
				</container>";

			StreamReader scriptStream = new StreamReader(new MemoryStream(new ASCIIEncoding().GetBytes(xmlScript)));

			IMutablePicoContainer parent = new DefaultPicoContainer();
			IPicoContainer pico = buildContainer(new XMLContainerBuilder(scriptStream), parent, new ArrayList());
			
			Assert.AreEqual("XML", pico.GetComponentInstance("Hello"));
			Assert.AreEqual("XMLContinerBuilder", pico.GetComponentInstance("Hei"));
		}

		[Test]
		public void TestCreateSimpleContainer()
		{
			string xmlScript = @"
				<container>
					<component-implementation class='System.Text.StringBuilder'/>
					<component-implementation class='NanoContainer.Test.TestModel.DefaultWebServerConfig'/>
					<component-implementation key='NanoContainer.Test.TestModel.WebServer' class='NanoContainer.Test.TestModel.DefaultWebServer'/>
				</container>";

			StreamReader scriptStream = new StreamReader(new MemoryStream(new ASCIIEncoding().GetBytes(xmlScript)));
			IMutablePicoContainer parent = new DefaultPicoContainer();
			IPicoContainer pico = buildContainer(new XMLContainerBuilder(scriptStream), parent, new ArrayList());
			
			Assert.IsNotNull(pico.GetComponentInstance(typeof(StringBuilder)));
			Assert.IsNotNull(pico.GetComponentInstance(typeof(NanoContainer.Test.TestModel.DefaultWebServerConfig)));
			Assert.IsNotNull(pico.GetComponentInstance("NanoContainer.Test.TestModel.WebServer"));
		}

		[Test]
		public void TestCreateSimpleContainerWithExplicitKeysAndParameters()
		{
			string xmlScript = @"
					<container>
						<component-implementation key='aBuffer' class='System.Text.StringBuilder'/>
						<component-implementation key='NanoContainer.Test.TestModel.WebServerConfig' class='NanoContainer.Test.TestModel.DefaultWebServerConfig'/>
						<component-implementation key='NanoContainer.Test.TestModel.WebServer' class='NanoContainer.Test.TestModel.DefaultWebServer'>
				 				<parameter key='NanoContainer.Test.TestModel.WebServerConfig'/>
				 				<parameter key='aBuffer'/>
						</component-implementation>
					</container>";

			StreamReader scriptStream = new StreamReader(new MemoryStream(new ASCIIEncoding().GetBytes(xmlScript)));

			IMutablePicoContainer parent = new DefaultPicoContainer();
			IPicoContainer pico = buildContainer(new XMLContainerBuilder(scriptStream), parent, new ArrayList());

			Assert.AreEqual(3, pico.ComponentInstances.Count);
			Assert.IsNotNull(pico.GetComponentInstance("aBuffer"));
			Assert.IsNotNull(pico.GetComponentInstance("NanoContainer.Test.TestModel.WebServerConfig"));
			Assert.IsNotNull(pico.GetComponentInstance("NanoContainer.Test.TestModel.WebServer"));
		}

		[Test]
		public void TestNonParameterElementsAreIgnoredInComponentImplementation()
		{
			string xmlScript = @"
					<container>
						<component-implementation key='aBuffer' class='System.Text.StringBuilder'/>
						<component-implementation key='NanoContainer.Test.TestModel.WebServerConfig' class='NanoContainer.Test.TestModel.DefaultWebServerConfig'/>
						<component-implementation key='NanoContainer.Test.TestModel.WebServer' class='NanoContainer.Test.TestModel.DefaultWebServer'>
				 				<parameter key='NanoContainer.Test.TestModel.WebServerConfig'/>
				 				<parameter key='aBuffer'/>
								<any-old-stuff/>
						</component-implementation>
					</container>";

			StreamReader scriptStream = new StreamReader(new MemoryStream(new ASCIIEncoding().GetBytes(xmlScript)));

			IMutablePicoContainer parent = new DefaultPicoContainer();
			IPicoContainer pico = buildContainer(new XMLContainerBuilder(scriptStream), parent, new ArrayList());

			Assert.AreEqual(3, pico.ComponentInstances.Count);
			Assert.IsNotNull(pico.GetComponentInstance("aBuffer"));
			Assert.IsNotNull(pico.GetComponentInstance("NanoContainer.Test.TestModel.WebServerConfig"));
			Assert.IsNotNull(pico.GetComponentInstance("NanoContainer.Test.TestModel.WebServer"));
		}

		[Test]
		[Ignore("Not implemented yet")]
		public void TestContainerCanHostAChild()
		{
			string xmlScript = @"
					<container>
						<component-implementation class='NanoContainer.Test.TestModel.DefaultWebServerConfig'/>
						<component-implementation class='System.Text.StringBuilder'/>
						<container>
							<component-implementation key='NanoContainer.Test.TestModel.WebServer' class='NanoContainer.Test.TestModel.DefaultWebServer'/>
						</container>
					</container>";

			StreamReader scriptStream = new StreamReader(new MemoryStream(new ASCIIEncoding().GetBytes(xmlScript)));

			IMutablePicoContainer parent = new DefaultPicoContainer();
			IPicoContainer pico = buildContainer(new XMLContainerBuilder(scriptStream), parent, new ArrayList());

			Assert.IsNotNull(pico.GetComponentInstance("NanoContainer.Test.TestModel.WebServerConfig"));
			
			StringBuilder sb = (StringBuilder) pico.GetComponentInstance(typeof(System.Text.StringBuilder));
			Assert.IsTrue(sb.ToString().IndexOf("-WebServer") != -1 );
		}

		[Test]
		public void TestUnknownclassThrowsPicoCompositionException()
		{
			string xmlScript = @"
					<container>
						<component-implementation class='Foo'/>
					</container>";

			StreamReader scriptStream = new StreamReader(new MemoryStream(new ASCIIEncoding().GetBytes(xmlScript)));

			IMutablePicoContainer parent = new DefaultPicoContainer();
			
			try
			{
				IPicoContainer pico = buildContainer(new XMLContainerBuilder(scriptStream), parent, new ArrayList());
				Assert.Fail();
			}
			catch(NanoContainer.IntegrationKit.PicoCompositionException expected)
			{
				Assert.IsTrue(expected.Message.StartsWith("Error compiling the composition script"));
			}
		}

		[Test]
		public void TestConstantParameterWithNoChildElementThrowsPicoCompositionException()
		{
			string xmlScript = @"
					<container>
						<component-implementation key='NanoContainer.Test.TestModel.WebServer' class='NanoContainer.Test.TestModel.DefaultWebServer'>
				 			<parameter/>
				 			<parameter/>
					</component-implementation>
					</container>";

			StreamReader scriptStream = new StreamReader(new MemoryStream(new ASCIIEncoding().GetBytes(xmlScript)));

			IMutablePicoContainer parent = new DefaultPicoContainer();
			
			try
			{
				IPicoContainer pico = buildContainer(new XMLContainerBuilder(scriptStream), parent, new ArrayList());
				Assert.Fail();
			}
			catch(NanoContainer.IntegrationKit.PicoCompositionException expected)
			{
				Assert.IsTrue(expected.Message.StartsWith("Parameter not set"));
			}
		}

		[Test]
		public void TestEmptyScriptDoesNotThrowsEmptyCompositionException()
		{
			string xmlScript = @"<container/>";

			StreamReader scriptStream = new StreamReader(new MemoryStream(new ASCIIEncoding().GetBytes(xmlScript)));
			IPicoContainer pico = buildContainer(new XMLContainerBuilder(scriptStream), null, new ArrayList());
		}

		[Test]
		public void TestCreateContainerFromNullScriptThrowsArgumentNullException()
		{
			string xmlScript = null;

			try
			{
				StreamReader scriptStream = new StreamReader(new MemoryStream(new ASCIIEncoding().GetBytes(xmlScript)));
				IPicoContainer pico = buildContainer(new XMLContainerBuilder(scriptStream), null, new ArrayList());
				Assert.Fail();
			}
			catch(ArgumentNullException)
			{
			} 
		}
	}
}
