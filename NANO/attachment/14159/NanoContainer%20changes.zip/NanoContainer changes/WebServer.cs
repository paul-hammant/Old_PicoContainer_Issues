using System;

namespace NanoContainer.Test.TestModel
{
	/// <summary>
	/// Summary description for WebServer.
	/// </summary>
	public interface WebServer
	{
	}
}
