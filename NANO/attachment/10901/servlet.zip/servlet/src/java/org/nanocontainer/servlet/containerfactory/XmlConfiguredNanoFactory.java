/*****************************************************************************
 * Copyright (C) NanoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the LICENSE.txt file.                                                     *
 *                                                                           *
 * Original code by Joe Walnes                                               *
 *****************************************************************************/


package org.nanocontainer.servlet.containerfactory;

import org.nanocontainer.servlet.ContainerFactory;
import org.nanocontainer.servlet.ObjectInstantiator;
import org.nanocontainer.xml.InputSourceFrontEnd;
import org.picocontainer.MutablePicoContainer;
import org.picocontainer.PicoContainer;
import org.picocontainer.PicoInitializationException;
import org.picocontainer.PicoRegistrationException;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.servlet.ServletContext;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;

public class XmlConfiguredNanoFactory implements ContainerFactory {
    private ServletContext servletContext;

    public XmlConfiguredNanoFactory(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    public PicoContainer buildContainer(String configName) {
        try {
            return createPico(configName);

        } catch (Exception e) {
            // TODO: Better exception
            throw new RuntimeException("Cannot build internals for config: " + configName, e);
        }
    }

    private MutablePicoContainer createPico(String configName) throws ParserConfigurationException, IOException, SAXException, ClassNotFoundException {
        InputSourceFrontEnd isfe = new InputSourceFrontEnd();
        final MutablePicoContainer rootContainer = (MutablePicoContainer) isfe.createPicoContainer(new InputSource(getConfigInputStream(configName)));

        return rootContainer;
    }

    public PicoContainer buildContainerWithParent(MutablePicoContainer parentContainer,
                                                  String configName) {
        try {
            final MutablePicoContainer picoContainer = createPico(configName);
            picoContainer.addParent(parentContainer);
            return picoContainer;
        } catch (Exception e) {
            // TODO: Better exception
            throw new RuntimeException("Cannot build internals for config: " + configName, e);
        }
    }

    public ObjectInstantiator buildInstantiator(final MutablePicoContainer parentContainer) {
        return new ObjectInstantiator() {
            public Object newInstance(Class cls) throws PicoInitializationException {

                try {
                    (parentContainer).registerComponentImplementation(cls);
                } catch (PicoRegistrationException e) {
                    // TODO: throw a custom exception
                    throw new RuntimeException("Could not instantiate " + cls.getName(), e);
                }
                return (parentContainer).getComponentInstance(cls);
            }
        };
    }

    public void destroyContainer(MutablePicoContainer container) {
        // TODO
    }

    private InputStream getConfigInputStream(String configName) {
        // TODO: find a way of caching this so the XML does not have to be continually reparsed
        return servletContext.getResourceAsStream("/WEB-INF/components-" + configName + ".xml");
    }

}
