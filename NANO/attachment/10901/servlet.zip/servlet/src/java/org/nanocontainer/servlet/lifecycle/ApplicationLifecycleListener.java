/*****************************************************************************
 * Copyright (C) NanoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the LICENSE.txt file.                                                     *
 *                                                                           *
 * Original code by Joe Walnes                                               *
 *****************************************************************************/


package org.nanocontainer.servlet.lifecycle;

import org.nanocontainer.servlet.ObjectHolder;
import org.nanocontainer.servlet.holder.ApplicationScopeObjectHolder;
import org.picocontainer.PicoContainer;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class ApplicationLifecycleListener extends BaseLifecycleListener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent event) {
        ServletContext context = event.getServletContext();

        PicoContainer container = getFactory(context).buildContainer("application");

        ObjectHolder holder = new ApplicationScopeObjectHolder(context, CONTAINER_KEY);
        holder.put(container);

    }


    public void contextDestroyed(ServletContextEvent event) {
        ServletContext context = event.getServletContext();

        destroyContainer(context, new ApplicationScopeObjectHolder(context, CONTAINER_KEY));
    }

}