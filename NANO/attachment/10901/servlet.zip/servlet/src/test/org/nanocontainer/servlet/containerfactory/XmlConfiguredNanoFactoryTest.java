package org.nanocontainer.servlet.containerfactory;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import junit.framework.TestCase;
import org.nanocontainer.servlet.ContainerFactory;
import org.picocontainer.PicoContainer;

import javax.servlet.ServletContext;
import java.io.StringBufferInputStream;

/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 24.09.2003
 * Time: 16:38:00
 * @author csturm
 */
public class XmlConfiguredNanoFactoryTest extends TestCase {
    public void testInstantiatePublisher() {
        Mock m = new Mock(ServletContext.class);
        m.expectAndReturn("getResourceAsStream", C.eq("/WEB-INF/components-application.xml"), new StringBufferInputStream("<?xml version='1.0'?><container>\" +\n" +
                "<component classname='" + Component1.class.getName() + "'/>" +
                "<component classname='" + Component2.class.getName() + "'/>" +
                "</container>"));
        ServletContext sc = (ServletContext) m.proxy();
        ContainerFactory c = new XmlConfiguredNanoFactory(sc);
        PicoContainer pc = c.buildContainer("application");
        Component1 c1 = (Component1) pc.getComponentInstance(Component1.class);
        assertNotNull(c1);
        assertSame(c1, pc.getComponentInstance(Component1.class));
    }

    public static class Component1 {
        public Component1(Component2 c2) {
        }
    }

    public static class Component2 {
        public Component2() {
        }
    }

}
