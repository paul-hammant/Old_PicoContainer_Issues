package org.nanocontainer.servlet.lifecycle;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import junit.framework.TestCase;
import org.nanocontainer.servlet.ContainerFactory;

import javax.servlet.ServletContext;

/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 30.09.2003
 * Time: 14:10:04
 * @author csturm
 */
public class BaseLifecycleListenerTest extends TestCase {
    public void testBaseLifecycleListenerCreatesXmlConfiguredNanoFactory() {
        Mock servletContextMock = new Mock(ServletContext.class);
        servletContextMock.expectAndReturn("getAttribute", C.args(C.eq(BaseLifecycleListener.FACTORY_KEY)), null);
        servletContextMock.expect("setAttribute", C.ANY_ARGS);
        ServletContext ctx = (ServletContext) servletContextMock.proxy();
        LifecycleListener l = new LifecycleListener();
        ContainerFactory factory = l.getFactory(ctx);
        assertNotNull(factory);
    }

    public void testBaseLifecycleListenerCachesFactoryInServletContext() {
        Mock servletContextMock = new Mock(ServletContext.class);
        Mock containerFactoryMock = new Mock(ContainerFactory.class);
        final Object factory = containerFactoryMock.proxy();
        servletContextMock.expectAndReturn("getAttribute", C.args(C.eq(BaseLifecycleListener.FACTORY_KEY)), factory);
        servletContextMock.expect("setAttribute", C.ANY_ARGS);
        ServletContext ctx = (ServletContext) servletContextMock.proxy();
        LifecycleListener l = new LifecycleListener();
        assertSame(factory, l.getFactory(ctx));
    }

    // make the methods public :)
    public static class LifecycleListener extends BaseLifecycleListener {
        public ContainerFactory getFactory(ServletContext context) {
            return super.getFactory(context);
        }

//        public void destroyContainer(ServletContext context, ObjectHolder holder) {
//            super.destroyContainer(context, holder);
//        }
    }
}