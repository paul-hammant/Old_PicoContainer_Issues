package org.nanocontainer.servlet.lifecycle;

import com.mockobjects.dynamic.C;
import com.mockobjects.dynamic.Mock;
import junit.framework.TestCase;
import org.nanocontainer.servlet.ContainerFactory;
import org.picocontainer.MutablePicoContainer;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 26.09.2003
 * Time: 13:16:13
 * @author csturm
 */
public class ApplicationLifecycleListenerTest extends TestCase {
    public void testLifecycle() {
        ApplicationLifecycleListener all = new ApplicationLifecycleListener();

        Mock containerFactoryMock = new Mock(ContainerFactory.class);
        Mock servletContextMock = new Mock(ServletContext.class);
        final MutablePicoContainer picoContainer = (MutablePicoContainer) new Mock(MutablePicoContainer.class).proxy();
        containerFactoryMock.expectAndReturn("buildContainer", C.args(C.eq("application")), picoContainer);
        servletContextMock.expectAndReturn("getAttribute", C.args(C.eq(BaseLifecycleListener.FACTORY_KEY)), containerFactoryMock.proxy());
        servletContextMock.expect("setAttribute", C.args(C.eq(BaseLifecycleListener.CONTAINER_KEY), C.eq(picoContainer)));
        ServletContext ctx = (ServletContext) servletContextMock.proxy();
        ServletContextEvent evt = new ServletContextEvent(ctx);
        all.contextInitialized(evt);
    }
}
