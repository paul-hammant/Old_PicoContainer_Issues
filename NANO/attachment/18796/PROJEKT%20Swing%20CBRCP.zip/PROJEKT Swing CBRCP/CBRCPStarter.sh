#!/bin/bash
# ==========================================================================
# CBRCP - Java Swing Component-Based Rich Client Platform
# Copyright (C) 2006, Jens Krefeldt

# Author: Jens Krefeldt
# Version: $Revision$, $Date$, last change by  $Author$

# GNU Lesser General Public License

# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation,
# version 2.1 of the License.

# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA  02111-1307, USA.
# ==========================================================================

# Edit the following line to point to your java JDK directory
JAVA_HOME=./jre1.5.0_05/linux/

CLASSPATH=./classes/:./core-lib/kunststoff-2.0.2.jar:./core-lib/looks-1.3.2.jar:./core-lib/nanocontainer-1.0-RC-3.jar:./core-lib/jaxen-core.jar.:./core-lib/picocontainer-1.2.jar:./core-lib/picocontainer-gems-1.2.jar:./core-lib/proxytoys-0.2.1.jar:./core-lib/tablelayout-2005-09-20.jar
$JAVA_HOME/bin/java -Xms64m -Xmx256m -cp $CLASSPATH cbrcp.CBRCPStarter

