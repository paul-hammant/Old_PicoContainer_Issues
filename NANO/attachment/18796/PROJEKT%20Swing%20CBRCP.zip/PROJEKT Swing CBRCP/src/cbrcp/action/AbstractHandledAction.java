package cbrcp.action;

import javax.swing.AbstractAction;
import javax.swing.Icon;

import java.awt.Component;


/**
 * This abstract action class extends {@link AbstractAction} by
 * referencing an {@link ActionHandler} to subclasses who manages this action.
 * It also provides a parent {@link Component} which is the owner of the
 * {@link ActionHandler}.
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.8 $, $Date: 2004/10/18 16:30:57 $, last change by: $Author: jens $
 */
public abstract class AbstractHandledAction extends AbstractAction{

    /** The {@link ActionHandler} managing this action. */
    protected ActionHandler handler;

    /** The {@link #handler}s owner {@link Component}. */
    protected Component parent;


    /**
     * Constructor for an action managed by an {@link ActionHandler}.
     * @param handler handler which manages this action, must not be <code>null</code>
     * @param name of this action, can be <code>null</code>
     * @throws NullPointerException if <code>handler</code> is <code>null</code>
     */
    public AbstractHandledAction(ActionHandler handler, String name)
                                        throws NullPointerException{
        this(handler, name, null);
    }


    /**
     * Constructor for an action managed by an {@link ActionHandler}.
     * @param handler handler which manages this action, must not be <code>null</code>
     * @param name of this action, can be <code>null</code>
     * @param icon for this action, can be <code>null</code>
     * @throws NullPointerException if <code>handler</code> is <code>null</code>
     */
    public AbstractHandledAction(ActionHandler handler, String name,
                                 Icon icon) throws NullPointerException{
        this(handler, name, icon, "");
    }


    /**
     * Constructor for an action managed by an {@link ActionHandler}.
     * @param handler handler which manages this action, must not be <code>null</code>
     * @param name of this action, can be <code>null</code>
     * @param icon for this action, can be <code>null</code>
     * @param description for this action, can be <code>null</code>
     * @throws NullPointerException if <code>handler</code> is <code>null</code>
     */
    public AbstractHandledAction(ActionHandler handler, String name,
                                 Icon icon, String description)
                                        throws NullPointerException{
        this(handler, name, icon, description, null);
    }


    /**
     * Constructor for an action managed by an {@link ActionHandler}.
     * @param handler handler which manages this action, must not be <code>null</code>
     * @param name of this action, can be <code>null</code>
     * @param icon for this action, can be <code>null</code>
     * @param description for this action, can be <code>null</code>
     * @param mnemonic
     * @throws NullPointerException if <code>handler</code> is <code>null</code>
     */
    public AbstractHandledAction(ActionHandler handler, String name,
                                 Icon icon, String description, Integer mnemonic)
                                        throws NullPointerException{
        super(name, icon);
        if(handler != null){
            this.handler = handler;
            parent = handler.getOwner();
        }else{
            throw new NullPointerException("Action has no handler!");
        }
        putValue(SHORT_DESCRIPTION, description);
        if(mnemonic != null){
            putValue(MNEMONIC_KEY, mnemonic);
        }
    }
}
