package cbrcp.action;

import javax.swing.Action;
import javax.swing.JToolBar;
import javax.swing.JMenu;
import javax.swing.ImageIcon;

import java.util.HashMap;
import java.util.Set;
import java.util.logging.Logger;

import java.awt.Component;
import java.beans.PropertyChangeListener;


/**
 * This abstract handler for actions should be extended by every component defining any
 * {@link Action}s.
 * 
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.12 $, $Date: 2004/10/27 17:13:01 $, last change by: $Author: jens $
 */
public abstract class AbstractActionHandler
implements ActionHandler{

    /** Just for logging purposes. */
    private static Logger LOGGER = Logger.getLogger(AbstractActionHandler.class.getName());

    protected int mode = 0;

    protected JMenu menu;

    protected JToolBar tool;

    protected int index;

    protected boolean indexReserved;

    protected HashMap<String, Action> actions;

    protected String name;

    private boolean actionHandlerEnabled = true;

    /**
     * A reference to a possible owner {@link Component} for dialogs often used
     * in actions. Should be used in subclasses.
     * */
    protected Component owner;


    public AbstractActionHandler(String name, int mode){
        this(name, mode, 0);
    }


    public AbstractActionHandler(String name, int mode, Component owner){
        this(name, mode, 0, owner);
    }


    public AbstractActionHandler(String name, int mode, int index){
        this(name, mode, index, false);
    }


    public AbstractActionHandler(String name, int mode, int index, Component owner){
        this(name, mode, index, false, owner);
    }


    public AbstractActionHandler(String name, int mode, boolean indexReserved){
        this(name, mode, 0, indexReserved);
    }


    public AbstractActionHandler(String name, int mode, boolean indexReserved, Component owner){
        this(name, mode, 0, indexReserved, owner);
    }


    public AbstractActionHandler(String name, int mode, int index, boolean indexReserved){
        this(name, mode, index, indexReserved, null);
    }


    public AbstractActionHandler(String name, int mode, int index, boolean indexReserved, Component owner){
        this.name = name;
        this.mode = mode;
        this.index = index;
        this.indexReserved = indexReserved;
        this.owner = owner;
        if(mode == BOTH_MODE || mode == TOOL_MODE){
            tool = new JToolBar(name);
            tool.setToolTipText(name);
            tool.setRollover(true);
            tool.setBorderPainted(false);
        }
        if(mode == BOTH_MODE || mode == MENU_MODE){
            menu = new JMenu(name);
        }
        actions = new HashMap<String, Action>();

        /*
        actions = initActions();
        menu = initMenu();
        tool = initTool();   */
    }


    /**
     * Sets the orientation of the tool bar. The orientation must have either the
     * value <code>HORIZONTAL</code> or <code>VERTICAL</code>. If orientation is
     * an invalid value, an exception will be thrown.
     * @param orientation the new orientation -- either <code>HORIZONTAL</code> or <code>VERTICAL</code>
     * @throws IllegalArgumentException if orientation is neither <code>HORIZONTAL</code> nor <code>VERTICAL</code>
     */
    public void setToolBarOrientation(int orientation) throws IllegalArgumentException{
        tool.setOrientation(orientation);
    }


    /**
     * Enables/disables all registered {@link Action}s referenced by
     * their name.
     * @param enabled   the new value for enabling or disabling all {@link Action}s
     */
    public void setActionHandlerEnabled(boolean enabled){
        actionHandlerEnabled = enabled;
        Set<String> keys = actions.keySet();
        for(String key: keys){
            Action a = actions.get(key);
            String nameKey = (String) a.getValue(Action.NAME);
            try{
                setActionEnabled(nameKey, enabled);
            }catch(ActionNotFoundException anfe){
                LOGGER.severe("While setting ActionHandler enable to " + enabled
                              + ", " + anfe.getMessage());
            }
        }
    }


    /**
     * Returns <CODE>false</CODE> if all actions are disabled.
     * @return <CODE>false</CODE> if all actions are disabled else <CODE>true</CODE>
     */
    public boolean isActionHandlerEnabled(){
        return actionHandlerEnabled;
    }


    /**
     * Enable/disable a registered {@link Action} referenced by its name.
     *
     * @param nameKey   identifier for {@link Action}
     * @param enabled   the new value for enabling or disabling the action
     * @throws ActionNotFoundException  thrown if action ist not found in cache
     */
    public void setActionEnabled(String nameKey, boolean enabled)
        throws ActionNotFoundException{
        Action a = actions.get(nameKey);
        if(a != null){
            a.setEnabled(enabled);
        }else{
            throw new ActionNotFoundException("setActionEnabled(...): Action " +
                    "with name key\"" + nameKey + "\" not found.");
        }
    }


    /**
     * Returns enable/disable state of a registered {@link Action}
     * referenced by its name.
     *
     * @param nameKey   identifier for {@link Action}
     * @throws ActionNotFoundException  thrown if action ist not found in cache
     */
    public boolean isActionEnabled(String nameKey)
        throws ActionNotFoundException{
        Action a = actions.get(nameKey);
        if(a != null){
            return a.isEnabled();
        }else{
            throw new ActionNotFoundException("isActionEnabled(...): Action " +
                    "with name key\"" + nameKey + "\" not found.");
        }
    }


    /**
     * Getter for {@link Action} with <code>nameKey</code>.
     * @param nameKey
     * @return
     * @throws ActionNotFoundException if action with <code>nameKey</code> does not exist
     */
    public Action getAction(String nameKey) throws ActionNotFoundException{
        Action a = actions.get(nameKey);
        if(a == null){
            throw new ActionNotFoundException("isActionEnabled(...): Action " +
                    "with name key\"" + nameKey + "\" not found.");
        }else{
            return a;
        }
    }


    /**
     * Adds a {@link PropertyChangeListener}. Containers and attached components use
     * these methods to register interest in this Action object. When its enabled
     * state or other property changes, the registered listeners are informed of
     * the change.
     * @param nameKey
     * @param listener a {@link PropertyChangeListener} object
     * @throws ActionNotFoundException
     */
    public void addPropertyChangeListenerForAction(String nameKey, PropertyChangeListener listener)
            throws ActionNotFoundException{
        Action a = actions.get(nameKey);
        if(a == null){
            throw new ActionNotFoundException("isActionEnabled(...): Action " +
                    "with name key\"" + nameKey + "\" not found.");
        }else{
            a.addPropertyChangeListener(listener);
        }
    }


    public JMenu getMenu() throws NullPointerException{
        if(menu == null && (mode == BOTH_MODE || mode == MENU_MODE)){
            throw new NullPointerException("mode == BOTH_MODE || mode == MENU_MODE, but menu == null!");
        }
        return menu;
    }


    public JToolBar getToolBar() throws NullPointerException{
        if(tool == null && (mode == BOTH_MODE || mode == TOOL_MODE)){
            throw new NullPointerException("mode == BOTH_MODE || mode == TOOL_MODE, but tool == null!");
        }
        return tool;
    }


    public int getMode() {
        return mode;
    }


    public int getIndex() {
        return index;
    }


    public void setMode(int mode) {
        this.mode = mode;
    }


    public void setIndex(int index) {
        this.index = index;
    }


    public String getName() {
        return name;
    }


    public boolean isIndexReserved() {
        return indexReserved;
    }


    public void setIndexReserved(boolean indexReserved) {
        this.indexReserved = indexReserved;
    }


    public HashMap<String, Action> getActions() {
        return actions;
    }


    public void setOwner(Component owner){
        this.owner = owner;
    }

    public Component getOwner(){
        return owner;
    }

    public ImageIcon getIconResource(String name){
        try {
            ClassLoader classLoader = this.getClass().getClassLoader();
            //System.out.println(ClassLoader.getSystemResource("logo.png").toString());
            return new ImageIcon(classLoader.getResource(name));
        } catch (Exception e) {
            LOGGER.severe(e.getClass().getName() + ": Image called " + name + " not found. " + e.getMessage());
        }
        return null;
    }

    public static ImageIcon getIconSystemResource(String name){
        try {
            //System.out.println(ClassLoader.getSystemResource("logo.png").toString());
            return new ImageIcon(ClassLoader.getSystemResource(name));
        } catch (Exception e) {
            LOGGER.severe(e.getClass().getName() + ": Image called " + name + " not found. " + e.getMessage());
        }
        return null;
    }

}
