package cbrcp.action;


/**
 * Thrown when a particular {@link javax.swing.Action} cannot be found while
 * en/disabling the {@link javax.swing.Action} in an {@link ActionHandler}.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.3 $, $Date: 2004/07/01 13:36:28 $, last change by: $Author: jens $
 */
public class ActionNotFoundException
extends Exception{

    /**
     * Constructs a {@link ActionNotFoundException} without a detail message.
     */
    public ActionNotFoundException() {
	    super();
    }

    /**
     * Constructs an {@link ActionNotFoundException} with a detail message.
     *
     * @param message the detail message.
     */
    public ActionNotFoundException(String message) {
	    super(message);
    }
}
