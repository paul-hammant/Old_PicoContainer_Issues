package cbrcp.action;

/**
 * An interface for components or objects managing {@link ActionHandler}s.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 * @deprecated
 */
public interface ActionHandlerManager {

    /**
     * Adds an {@link ActionHandler} to the component or object.
     * @param handler the {@link ActionHandler} to add
     * @throws DuplicateActionHandlerNameException thrown if the {@link ActionHandler}
     *         is already contained
     */
    public void addActionHandler(ActionHandler handler)
        throws DuplicateActionHandlerNameException;


    /**
     * Reactivates an {@link ActionHandler} from the component or object.
     * @param actionHandlerName identifies the {@link ActionHandler}
     * @throws ActionHandlerDoesNotExistException thrown if the an
     *         {@link ActionHandler} with the passed name is not managed
     */
    public void reactivateActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException;


    /**
     * Supends an {@link ActionHandler} from the component or object.
     * @param actionHandlerName identifies the {@link ActionHandler}
     * @throws ActionHandlerDoesNotExistException thrown if the an
     *         {@link ActionHandler} with the passed name is not managed
     */
    public void suspendActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException;


    /**
     * Removes an {@link ActionHandler} from the component or object.
     * @param actionHandlerName identifies the {@link ActionHandler}
     * @throws ActionHandlerDoesNotExistException thrown if the an
     *         {@link ActionHandler} with the passed name is not managed
     */
    public void removeActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException;
}
