package cbrcp.action;

import javax.swing.JMenu;
import javax.swing.Action;
import javax.swing.JToolBar;

import java.util.HashMap;
import java.awt.Component;
import java.beans.PropertyChangeListener;


/**
 * This handler interface for actions should be implemented by every component
 * defining any {@link Action}s.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.9 $, $Date: 2004/10/27 17:13:01 $, last change by: $Author: jens $
 */
public interface ActionHandler {

    /** Flag defining that this handler should be used for menubar and toolbar. */
    public static final int BOTH_MODE = 0;

    /** Flag defining that this handler should be used only for menubar. */
    public static final int MENU_MODE = 1;

    /** Flag defining that this handler should be used only for toolbar. */
    public static final int TOOL_MODE = 2;


    /*
     * Implement this to initialize all {@link Action}s and register
     * them in a {@link java.util.HashMap}<code>&lt;String, Action&gt;
     * </code> with their {@link Action#NAME}.
     * @see Action#NAME
     * @return
     */
 //   abstract HashMap<String, Action> initActions();


    /*
     * Implement this to initialize the {@link JMenu} containing all
     * {@link Action}s of this handler.
     */
 //   abstract JMenu initMenu();


    /*
     * Implement this to initialize the {@link JPanel} containing all
     * buttons with the {@link Action}s of this handler.
     */
 //   abstract JPanel initTool();

    /**
     * Enable or disable a specific {@link Action}.
     * @param nameKey name of the action
     * @param enabled
     * @throws ActionNotFoundException thrown if the sction is not found in this
     *         handler
     */
    public void setActionEnabled(String nameKey, boolean enabled)
            throws ActionNotFoundException;

    /**
     * Getter for {@link Action} with <code>nameKey</code>.
     * @param nameKey
     * @return
     * @throws ActionNotFoundException if action with <code>nameKey</code> does
     *         not exist
     */
    public Action getAction(String nameKey) throws ActionNotFoundException;


    /**
     * Adds a {@link java.beans.PropertyChangeListener}. Containers and attached components use
     * these methods to register interest in this Action object. When its enabled
     * state or other property changes, the registered listeners are informed of
     * the change.
     * @param nameKey
     * @param listener a {@link java.beans.PropertyChangeListener} object
     * @throws ActionNotFoundException
     */
    public void addPropertyChangeListenerForAction(String nameKey,
                                                   PropertyChangeListener listener)
            throws ActionNotFoundException;

    /**
     * Gets the {@link JMenu} containing all
     * {@link Action}s of this handler.
     * @return a {@link JMenu} for usage in a {@link javax.swing.JMenuBar}
     * @throws NullPointerException <code>if(menu == null && (mode == BOTH_MODE ||
     *                                                  mode == MENU_MODE))</code>
     */
    public JMenu getMenu() throws NullPointerException;


    /**
     * Gets the {@link javax.swing.JPanel} containing all
     * buttons with the {@link Action}s of this handler.
     * @return a {@link JToolBar}
     * @throws NullPointerException <code>if(tool == null && (mode == BOTH_MODE ||
     *                                                  mode == TOOL_MODE))</code>
     */
    public JToolBar getToolBar()  throws NullPointerException;


    /**
     * Sets the orientation of the tool bar. The orientation must have either the
     * value <code>HORIZONTAL</code> or <code>VERTICAL</code>. If orientation is
     * an invalid value, an exception will be thrown.
     * @param orientation the new orientation -- either <code>HORIZONTAL</code> or <code>VERTICAL</code>
     * @throws IllegalArgumentException if orientation is neither <code>HORIZONTAL</code> nor <code>VERTICAL</code>
     */
    public void setToolBarOrientation(int orientation) throws IllegalArgumentException;


    /**
     * Gets the mode for usage. Is one of:
     * <ul>
     *  <li>BOTH_MODE</li>
     *  <li>MENU_MODE</li>
     *  <li>TOOLBAR_MODE</li>
     * </ul>
     * @see #BOTH_MODE
     * @see #MENU_MODE
     * @see #TOOL_MODE
     */
    public int getMode();


    /**
     * Sets the mode for usage. Must be one of:
     * <ul>
     *  <li>BOTH_MODE</li>
     *  <li>MENU_MODE</li>
     *  <li>TOOLBAR_MODE</li>
     * </ul>
     * @see #BOTH_MODE
     * @see #MENU_MODE
     * @see #TOOL_MODE
     * @param mode
     */
    public void setMode(int mode);


    public int getIndex();


    public void setIndex(int index);


    /**
     * Gets the name of this handler.
     * @return handler's name
     */
    public String getName();


    public boolean isIndexReserved();


    public void setIndexReserved(boolean indexReserved);


    public HashMap<String, Action> getActions();


    public void setOwner(Component owner);

    public Component getOwner();
}
