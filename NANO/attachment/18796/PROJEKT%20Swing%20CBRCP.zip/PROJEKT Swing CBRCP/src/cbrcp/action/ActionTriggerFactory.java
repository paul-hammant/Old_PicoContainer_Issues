package cbrcp.action;

import javax.swing.JMenuItem;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.ComboBoxModel;
import javax.swing.Action;

import java.awt.Dimension;
import java.util.Vector;


/**
 * This factory class provides factory methods which deliver
 * different Swing trigger components for an action.
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.4 $, $Date: 2004/09/27 11:52:22 $, last change by: $Author: jens $
 */
public class ActionTriggerFactory {

    /**
     * Private constructor.
     */
    private ActionTriggerFactory(){
        // don't instantiate
    }


    public static JButton createButtonForAction(Action action){
        return new JButton(action);
    }

    public static JButton create16x16ImageButtonForAction(Action action){
        return createImageButtonForAction(action, new Dimension(16, 16));
    }


    public static JButton create24x24ImageButtonForAction(Action action){
        return createImageButtonForAction(action, new Dimension(24, 24));
    }


    public static JButton create32x32ImageButtonForAction(Action action){
        return createImageButtonForAction(action, new Dimension(32, 32));
    }


    public static JButton createImageButtonForAction(Action action, Dimension d){
        JButton button = new JButton(action);
        button.setText(null);
        button.setPreferredSize(d);
        button.setMinimumSize(d);
        button.setMaximumSize(d);
        return button;
    }


    public static JMenuItem createMenuItemForAction(Action action){
        return new JMenuItem(action);
    }


    public static JComboBox createComboBoxForAction(Action action, ComboBoxModel model){
        JComboBox comboBox = new JComboBox(model);
        comboBox.setAction(action);
        return comboBox;
    }

    public static JComboBox createComboBoxForAction(Action action, ComboBoxModel model, Object selectedItem){
        model.setSelectedItem(selectedItem);
        JComboBox comboBox = new JComboBox(model);
        comboBox.setAction(action);
        return comboBox;
    }


    public static JComboBox createComboBoxForAction(Action action, Object[] items){
        JComboBox comboBox = new JComboBox(items);
        comboBox.setAction(action);
        return comboBox;
    }


    public static JComboBox createComboBoxForAction(Action action, Object[] items, Object selectedItem){
        JComboBox comboBox = new JComboBox(items);
        comboBox.setSelectedItem(selectedItem);
        comboBox.setAction(action);
        return comboBox;
    }


    public static JComboBox createComboBoxForAction(Action action, Vector<?> items){
        JComboBox comboBox = new JComboBox(items);
        comboBox.setAction(action);
        return comboBox;
    }


    public static JComboBox createComboBoxForAction(Action action, Vector<?> items, Object selectedItem){
        JComboBox comboBox = new JComboBox(items);
        comboBox.setSelectedItem(selectedItem);
        comboBox.setAction(action);
        return comboBox;
    }


    public static JComboBox createEditableComboBoxForAction(Action action, ComboBoxModel model){
        JComboBox c = createComboBoxForAction(action, model);
        c.setEditable(true);
        return c;
    }

    public static JComboBox createEditableComboBoxForAction(Action action, ComboBoxModel model, Object selectedItem){
        JComboBox c = createComboBoxForAction(action, model, selectedItem);
        c.setEditable(true);
        return c;
    }

    public static JComboBox createEditableComboBoxForAction(Action action, Object[] items){
        JComboBox c = createComboBoxForAction(action, items);
        c.setEditable(true);
        return c;
    }

    public static JComboBox createEditableComboBoxForAction(Action action, Object[] items, Object selectedItem){
        JComboBox c = createComboBoxForAction(action, items, selectedItem);
        c.setEditable(true);
        return c;
    }

    public static JComboBox createEditableComboBoxForAction(Action action, Vector<?> items){
        JComboBox c = createComboBoxForAction(action, items);
        c.setEditable(true);
        return c;
    }

    public static JComboBox createEditableComboBoxForAction(Action action, Vector<?> items, Object selectedItem){
        JComboBox c = createComboBoxForAction(action, items, selectedItem);
        c.setEditable(true);
        return c;
    }


    public static JTextField createTextFieldForAction(Action action){
        JTextField field = new JTextField();
        field.setAction(action);
        return field;
    }


    public static JRadioButton createJRadioButtonForAction(Action action){
        return new JRadioButton(action);
    }


    public static JRadioButtonMenuItem createJRadioButtonMenuItemForAction(Action action){
        return new JRadioButtonMenuItem(action);
    }


    public static JCheckBox createJCheckBoxForAction(Action action){
        return new JCheckBox(action);
    }


    public static JCheckBoxMenuItem createJCheckBoxMenuItemForAction(Action action){
        return new JCheckBoxMenuItem(action);
    }
}
