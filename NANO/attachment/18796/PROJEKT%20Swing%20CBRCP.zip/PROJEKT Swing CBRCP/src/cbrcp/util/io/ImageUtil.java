package cbrcp.util.io;

import javax.swing.ImageIcon;
import javax.imageio.ImageIO;

import java.util.logging.Logger;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.MediaTracker;


/**
 * .
 *
 * @author Jens Krefeldt
 * @version $Revision: 1.3 $, $Date: 2006/01/19 14:35:04 $, last change by: $Author: jens $
 */
public class ImageUtil {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(ImageUtil.class.getName());

    private ImageUtil(){

    }


    public static ImageIcon getIconSystemResource(String name){
        try {
            //SystemEntity.out.println(ClassLoader.getSystemResource("logo.png").toString());
            return new ImageIcon(ClassLoader.getSystemResource(name));
        } catch (Exception e) {
            LOGGER.severe(e.getClass().getName() + ": Image called " + name + " not found. " + e.getMessage());
        }
        return null;
    }

    public static Image getImageSystemResource(String name){
        try {
            //SystemEntity.out.println(ClassLoader.getSystemResource("logo.png").toString());
            return ImageIO.read(ClassLoader.getSystemResourceAsStream(name));
        } catch (Exception e) {
            LOGGER.severe(e.getClass().getName() + ": Image called " + name + " not found. " + e.getMessage());
        }
        return null;
    }
}
