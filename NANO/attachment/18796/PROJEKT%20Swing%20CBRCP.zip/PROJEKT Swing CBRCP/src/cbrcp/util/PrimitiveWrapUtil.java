package cbrcp.util;

import java.util.logging.Logger;


/**
 * .
 *
 * @author Jens Krefeldt
 * @version @version $Revision$, $Date$, last change by: $Author$
 */
public class PrimitiveWrapUtil {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(PrimitiveWrapUtil.class.getName());

    public static int parseInt(String integerStr){
        try{
            return Integer.parseInt(integerStr);
        }catch(NumberFormatException e){
            LOGGER.severe("NumberFormatException: " + integerStr + " is not a valid integer string! Returning '0'...");
            return 0;
        }
    }

}
