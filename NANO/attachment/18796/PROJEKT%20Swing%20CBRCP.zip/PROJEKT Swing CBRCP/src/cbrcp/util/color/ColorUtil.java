package cbrcp.util.color;

import cbrcp.util.PrimitiveWrapUtil;

import java.awt.Color;

import java.util.logging.Logger;


/**
 * .
 *
 * @author <a href="mailto:j.krefeldt@gmx.de">Jens Krefeldt</a>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class ColorUtil {

    /** JDK logging. */
    private static Logger LOGGER = Logger.getLogger(ColorUtil.class.getName());

    
    /**
     *
     * @param colorStr
     * @return
     */
    public static Color parseColorStr(String colorStr){
        Color color = null;
        /*if(colorStr.equals("LIGHT_GRAY")){
            return Color.LIGHT_GRAY;
        }*/
        String[] result = colorStr.split(",");
        int r = 0;
        int g = 0;
        int b = 0;
        for (int i = 0; i < result.length; i++){
            switch (i){
                case 0:
                    r = PrimitiveWrapUtil.parseInt(result[i]);
                    break;
                case 1:
                    g = PrimitiveWrapUtil.parseInt(result[i]);
                    break;
                case 2:
                    b = PrimitiveWrapUtil.parseInt(result[i]);
                    break;
            }
        }

        try{
            color = new Color(r, g, b);
        }catch(IllegalArgumentException iae){
            LOGGER.severe("Exception in creating color by string: " + "\"" + colorStr + "\"" + "is an invalid RGB-value!");
        }
        return color;
    }

}
