package cbrcp.swing;

import javax.swing.Icon;

import java.awt.Component;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public interface ConfigurationSheet {

    /**
     * Shows if configuration has changed.
     * @return <code>true</code> if changed
     */
    public boolean isConfigurationChanged();

    /**
     * Save configration.
     */
    public void acceptConfigurationChange();

    /**
     *
     * @return the Swing {@link Component} containing configuration GUI
     */
    public Component getComponent();

    /**
     * Getter for the title of this sheet.
     * @return title of this sheet
     */
    public String getTitle();

    /**
     * Getter for the tooltip of this sheet. Can be <code>null</code>.
     * @return tooltip of this sheet
     */
    public String getToolTip();

    /**
     * Getter for the icon of this sheet. Can be <code>null</code>.
     * @return icon of this sheet
     */
    public Icon getIcon();

    /**
     * The position to insert this {@link ConfigurationSheet} in a tab.
     * @return  position in a tab
     */
    public int getIndex();




}
