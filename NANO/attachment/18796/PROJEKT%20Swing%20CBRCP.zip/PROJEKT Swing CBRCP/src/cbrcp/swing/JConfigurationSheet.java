package cbrcp.swing;

import info.clearthought.layout.TableLayout;

import javax.swing.Icon;
import javax.swing.JPanel;

import java.awt.Component;
import java.awt.LayoutManager;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public abstract class JConfigurationSheet extends JPanel implements ConfigurationSheet{

    private boolean configurationChanged;

    private String toolTip;

    private Icon icon;

    private String title;

    private int index;


    /**
     * Create a new buffered <code>JConfigurationSheet</code> with the specified
     * {@link LayoutManager}.
     *
     * @param layout the {@link LayoutManager} to use
     * @param title the title to be displayed in a tab
     * @param toolTip the tooltip to be displayed for a tab
     * @param icon the icon to be displayed in a tab
     * @param index the position to insert this a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(LayoutManager layout, String title, String toolTip, Icon icon, int index) throws NullPointerException{
        super(layout);
        if(title != null){
            this.title = title;
        }else{
            throw new NullPointerException("Parameter 'title' must not be null!");
        }
        this.toolTip = toolTip;
        this.icon = icon;
        this.index = index;
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with a
     * {@link TableLayout}.
     *
     * @param title the title to be displayed in a tab
     * @param toolTip the tooltip to be displayed for a tab
     * @param icon the icon to be displayed in a tab
     * @param index the position to insert this a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(String title, String toolTip, Icon icon, int index) throws NullPointerException {
        this(new TableLayout(), title, toolTip, icon, index);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with the specified
     * {@link LayoutManager}.
     *
     * @param layout the {@link LayoutManager} to use
     * @param title the title to be displayed in a tab
     * @param toolTip the tooltip to be displayed for a tab
     * @param icon the icon to be displayed in a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(LayoutManager layout, String title, String toolTip, Icon icon) throws NullPointerException {
        this(layout, title, toolTip, icon, 0);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with a
     * {@link TableLayout}.
     *
     * @param title the title to be displayed in a tab
     * @param toolTip the tooltip to be displayed for a tab
     * @param icon the icon to be displayed in a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(String title, String toolTip, Icon icon) throws NullPointerException {
        this(new TableLayout(), title, toolTip, icon, 0);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with the specified
     * {@link LayoutManager}.
     *
     * @param layout the {@link LayoutManager} to use
     * @param title the title to be displayed in a tab
     * @param toolTip the tooltip to be displayed for a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(LayoutManager layout, String title, String toolTip) throws NullPointerException {
        this(layout, title, toolTip, null, 0);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with a
     * {@link TableLayout}.
     *
     * @param title the title to be displayed in a tab
     * @param toolTip the tooltip to be displayed for a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(String title, String toolTip) throws NullPointerException {
        this(new TableLayout(), title, toolTip, null, 0);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with the specified
     * {@link LayoutManager}.
     *
     * @param layout the {@link LayoutManager} to use
     * @param title the title to be displayed in a tab
     * @param icon the icon to be displayed in a tab
     * @param index the position to insert this a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(LayoutManager layout, String title, int index, Icon icon) throws NullPointerException {
        this(layout, title, null, icon, index);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with a
     * {@link TableLayout}.
     *
     * @param title the title to be displayed in a tab
     * @param icon the icon to be displayed in a tab
     * @param index the position to insert this a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(String title, int index, Icon icon) throws NullPointerException {
        this(new TableLayout(), title, null, icon, index);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with the specified
     * {@link LayoutManager}.
     *
     * @param layout the {@link LayoutManager} to use
     * @param title the title to be displayed in a tab
     * @param icon the icon to be displayed in a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(LayoutManager layout, String title, Icon icon) throws NullPointerException {
        this(layout, title, null, icon, 0);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with a
     * {@link TableLayout}.
     *
     * @param title the title to be displayed in a tab
     * @param icon the icon to be displayed in a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(String title, Icon icon) throws NullPointerException {
        this(new TableLayout(), title, null, icon, 0);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with the specified
     * {@link LayoutManager}.
     *
     * @param layout the {@link LayoutManager} to use
     * @param title the title to be displayed in a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(LayoutManager layout, String title) throws NullPointerException {
        this(layout, title, null, null, 0);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with a
     * {@link TableLayout}.
     *
     * @param title the title to be displayed in a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(String title) throws NullPointerException{
        this(new TableLayout(), title, null, null, 0);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with the specified
     * {@link LayoutManager}.
     *
     * @param layout the {@link LayoutManager} to use
     * @param title the title to be displayed in a tab
     * @param index the position to insert this a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(LayoutManager layout, String title, int index) throws NullPointerException {
        this(layout, title, null, null, index);
    }

    /**
     * Create a new buffered <code>JConfigurationSheet</code> with a
     * {@link TableLayout}.
     *
     * @param title the title to be displayed in a tab
     * @param index the position to insert this a tab
     * @throws NullPointerException if title is <code>null<code>
     */
    protected JConfigurationSheet(String title, int index) throws NullPointerException {
        this(new TableLayout(), title, null, null, index);
    }


   /**
    * Shows if configuration has changed.
    *
    * @return <code>true</code> if changed
    */
    public boolean isConfigurationChanged() {
      return configurationChanged;
    }

    public void setConfigurationChanged(boolean configurationChanged) {
        this.configurationChanged = configurationChanged;
    }


    /**
     * @return the Swing {@link java.awt.Component} containing configuration
     *         GUI
     */
    public Component getComponent() {
        return this;
    }

    /**
     * Getter for the title of this sheet.
     *
     * @return title of this sheet
     */
    public String getTitle() {
        return title;
    }

    /**
     * Getter for the tooltip of this sheet. Can be <code>null</code>.
     *
     * @return tooltip of this sheet
     */
    public String getToolTip() {
        return toolTip;
    }

    /**
     * Getter for the icon of this sheet. Can be <code>null</code>.
     *
     * @return icon of this sheet
     */
    public Icon getIcon() {
        return icon;
    }

    /**
     * The position to insert this {@link cbrcp.swing.ConfigurationSheet} in a
     * tab.
     *
     * @return position in a tab
     */
    public int getIndex() {
        return index;
    }

}
