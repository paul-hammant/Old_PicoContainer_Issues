package cbrcp;

import java.util.logging.Logger;
import java.util.logging.LogManager;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.File;

import org.nanocontainer.script.ScriptedContainerBuilder;
import org.nanocontainer.script.xml.XMLContainerBuilder;
import org.nanocontainer.DefaultNanoContainer;
import org.picocontainer.defaults.ObjectReference;
import org.picocontainer.defaults.SimpleReference;
import org.picocontainer.PicoContainer;


/**
 * Starter class for Java Swing CBRCP. Initializes the {@link LogManager} and the
 * root container. Configuration for this is done in file './cbrcp-start.properties'.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.8 $, $Date: 2006/01/19 14:35:04 $, last change by: $Author: jens $
 */
public class CBRCPStarter {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(CBRCPStarter.class.getName());


    /**
     * Main method for starting application.
     * @param args has no effect: use './cbrcp-start.properties' to configure
     *        start properties
     * @see StarterProperties
     */
    public static void main(String[] args){
        StarterProperties starterProperties = new StarterProperties();
        setupLogging(starterProperties);
        setupContainer(starterProperties);
    }


    /**
     * Setup for JDK logging
     * @param starterProperties start properties handler for CBRCP
     * @see StarterProperties
     */
    private static void setupLogging(StarterProperties starterProperties){
        LogManager man = LogManager.getLogManager();
        try {
            man.readConfiguration(new FileInputStream(starterProperties.getProperty("logPropertiesFile")));
        } catch (FileNotFoundException e) {
            LOGGER.severe("FileNotFoundException: '" + starterProperties.getProperty("logPropertiesFile") +
                    "'" + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            LOGGER.severe("IOException: '" + starterProperties.getProperty("logPropertiesFile") +
                    "'" + e.getMessage());
            e.printStackTrace();
        }
    }


    /**
     * Setup and start of the root container.
     * @param starterProperties start properties handler for CBRCP
     * @see StarterProperties
     */
    private static void setupContainer(StarterProperties starterProperties){
        String containerSetupFile = starterProperties.getProperty("containerSetupFile");
        if(containerSetupFile != null && !containerSetupFile.equals("")){   // start by Nanocontainer script
            try{
                startByNanocontainer(containerSetupFile);
            }catch(FileNotFoundException e){
                LOGGER.severe("FileNotFoundException for '" + new File(containerSetupFile).getAbsolutePath() + "': " + e.getMessage());
                LOGGER.info("Trying to start by Picocontainer directly!");
                startByPicocontainer(starterProperties);
                return;
            }
        }else{  // start Picocontainer object
            startByPicocontainer(starterProperties);
        }
    }


    /**
     * Start by Nanocontainer directly.
     * @param containerSetupFile file name of container XML script
     * @throws FileNotFoundException if file with name <code>containerSetupFile
     *         </code> not found
     */
    private static void startByNanocontainer(String containerSetupFile) throws FileNotFoundException{
            // instantiate the reader, it should point to the script
            File script = new File(containerSetupFile);
            FileReader scriptReader = null;
            scriptReader = new FileReader(script);
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();

            // build the container from the XML script
            ScriptedContainerBuilder builder = new XMLContainerBuilder(scriptReader, classLoader);
            DefaultNanoContainer parentContainer = new DefaultNanoContainer(classLoader);

            // create the container reference and pass them to the builder
            ObjectReference containerRef = new SimpleReference();
            ObjectReference parentContainerRef = new SimpleReference();
            parentContainerRef.set(parentContainer);
            builder.buildContainer(containerRef, null, null, true);
          //  PicoContainer rootContainer = (PicoContainer) containerRef.get();
    }

    /**
     * Start by Picocontainer directly.
     * @param starterProperties start properties handler for CBRCP
     * @see StarterProperties
     */
    private static void startByPicocontainer(StarterProperties starterProperties){
        String containerClassName = starterProperties.getProperty("containerClass");
        try{
            Class containerClass = Class.forName(containerClassName);
            PicoContainer rootContainer = (PicoContainer) containerClass.newInstance();
            // start the root container, which inits all subcontainers and components
            rootContainer.start();
        }catch(ClassNotFoundException e){
            LOGGER.warning("ClassNotFoundException for picocontainer '"
                    + containerClassName + "', exiting CBRCP.");
        }catch(InstantiationException e){
            LOGGER.warning("InstantiationException for picocontainer '"
                    + containerClassName + "', exiting CBRCP.");
        }catch(IllegalAccessException e){
            LOGGER.warning("IllegalAccessException for picocontainer '"
                    + containerClassName + "', exiting CBRCP.");
        }
    }
}


/**
 * A start properties handler for CBRCP. Reads "./cbrcp-start.properties" and
 * provides acces to properties with method {@link #getProperty(String key)}.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author: jens $
 */
 class StarterProperties {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(StarterProperties.class.getName());

    /**
     * The name for the bundle properties file. Make sure this is unique
     * inside your application.
     */
    private static final String FILE_NAME = "./cbrcp-start.properties";//$NON-NLS-1$

    /** The start properties. */
    private Properties properties = new Properties();


    protected StarterProperties() {
        properties = new Properties();
        try {
            properties.load(new FileInputStream(new File(FILE_NAME)));
        }catch(IOException e) {
            LOGGER.severe("IOException while loading property file '" +
                    new File(FILE_NAME).getAbsolutePath() + "' !");
        }
    }

    /**
     * Getter for the start property value.
     *
     * @param key for the NLS property value
     * @return the NLS property value
     */
    protected final String getProperty(String key) {
        return properties.getProperty(key);
    }

}
