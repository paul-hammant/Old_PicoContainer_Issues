package cbrcp.component.lookandfeel;

/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class Plastic3DLookAndFeelProxy extends AbstractPlasticLookAndFeelProxy {

    private static final String PLASTIC_3D_L_AND_F =
            "com.jgoodies.looks.plastic.Plastic3DLookAndFeel";


    public Plastic3DLookAndFeelProxy() {
        super(PLASTIC_3D_L_AND_F);
    }
}
