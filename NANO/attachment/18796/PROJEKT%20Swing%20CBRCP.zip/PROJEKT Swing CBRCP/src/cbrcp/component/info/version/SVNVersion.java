package cbrcp.component.info.version;

import cbrcp.component.info.version.AbstractVersion;

import java.util.logging.Logger;


/**
 * This class wraps a SVN version string for an object. You can pass a String of
 * following format:
 * <P>
 * <PRE>    &#036;Rev: &lt;version number&gt; &#036;</PRE>
 * </P>
 * This String is parsed and checked for errors, if no errors occurs the version
 * number is extracted and saved in this object else a
 * {@link cbrcp.component.info.version.VersionNumberFormatException} is thrown.
 * <P>
 * You will receive a version {@link String} of following format with {@link #getVersionNumber()}:
 * <P>
 * <PRE>    &lt;major version number&gt;</PRE>
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class SVNVersion
extends AbstractVersion {

    /** Just for logging purposes. */
    private final static Logger LOGGER = Logger.getLogger(SVNVersion.class.getName());


    /**
     * Constructs a SVN version object.
     *
     * @param version the SVN version value
     */
    public SVNVersion(String version) {
        this(version, null);
    }


    /**
     * Constructs a SVN version object.
     *
     * @param version the SVN version value
     * @param owner class signed with this version
     */
    public SVNVersion(String version, Class owner) {
        super(version, owner);
    }


    /**
     * Copy constructor.
     *
     * @param version the version to copy
     */
    public SVNVersion(Version version){
        super(version);
    }


    protected String checkVersionString(String version) throws VersionNumberFormatException {
        if(!version.startsWith("\u0024Rev:") && !version.endsWith("\u0024")){   // \u0024 = $
            this.version = "1";
            throw new VersionNumberFormatException(version + " is not a correct SVN version string."
                                                  + "Correct syntax: "
                                                  + "\u0024Rev: <version number>. \u0024");
        }else{
            StringBuffer buffer = new StringBuffer(version);

            buffer.delete(0, 6); // remove "$Rev:"
            buffer.deleteCharAt(buffer.length() - 1); // remove "$" at end
            buffer.deleteCharAt(buffer.length() - 1); // " " at end
            try{
                Integer.parseInt(version);
                version = buffer.toString();
            }catch(NumberFormatException nfe){
                this.version = "1";
                throw new VersionNumberFormatException(version + " is not a correct SVN version number."
                                                      + "Correct syntax: "
                                                      + "<version number>.");
            }
        }

        return version;
    }


    /**
     * Creates and returns a copy of this object.
     *
     * @return a clone of this instance
     * @throws CloneNotSupportedException if the object's class does not support
     *                                    the Cloneable interface. Subclasses that
     *                                    override the clone method can also throw
     *                                    this exception to indicate that an instance
     *                                    cannot be cloned
     */
    public Object clone() throws CloneNotSupportedException{
        super.clone();
        return new SVNVersion(this);
    }

}
