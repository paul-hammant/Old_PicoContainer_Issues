package cbrcp.component.lookandfeel;

/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class CrossPlatformLookAndFeelProxy extends AbstractLookAndFeelProxy {


    public CrossPlatformLookAndFeelProxy() {
        super(LookAndFeelConfigurationModel.getCrossPlatformLookAndFeelClassName());
    }
}
