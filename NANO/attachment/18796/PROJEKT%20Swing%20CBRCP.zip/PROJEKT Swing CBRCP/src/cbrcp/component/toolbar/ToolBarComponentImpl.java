package cbrcp.component.toolbar;

import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.Action;
import javax.swing.AbstractAction;
import javax.swing.JToolBar;
import javax.swing.border.EmptyBorder;

import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Container;
import java.awt.Component;
import java.io.IOException;
import java.util.logging.Logger;

import cbrcp.component.CBRCPAbstractComponentWithOnlyConfigSupport;
import cbrcp.util.io.ImageUtil;
import cbrcp.util.PrimitiveWrapUtil;


/**
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.23 $, $Date: 2004/10/27 17:13:01 $, last change by: $Author$
 */
public class ToolBarComponentImpl extends CBRCPAbstractComponentWithOnlyConfigSupport
implements ToolBarComponent {

    /** Just for logging purposes. */
    private final static Logger LOGGER = Logger.getLogger(ToolBarComponentImpl.class.getName());

    private JKeyToIndexToolBar toolBar;

    private Container container;


    public ToolBarComponentImpl(String componentConfigFile){
        super(componentConfigFile);
    }


    /**
     * Component lifecycle method: disposes this component.
     */
    public void dispose(){
        super.dispose();
        //container.setVisible(false);
        toolBar = null;
        container = null;
    }


    public Component initToolBar(){
        int verticalSeparatorStyle = PrimitiveWrapUtil.parseInt(
                getProperty("verticalSeparatorStyle"));
        int horizontalSeparatorStyle = PrimitiveWrapUtil.parseInt(
                getProperty("horizontalSeparatorStyle"));
        container = new JPanel(new BorderLayout(0, 0));
        toolBar = new JKeyToIndexToolBar(verticalSeparatorStyle);
        toolBar.setBorder(new EmptyBorder(0, 0, 0 ,0));
        LOGGER.finest("PANEL IN TOOLBARIMPL 1 = " + toolBar);
        container.add(toolBar, BorderLayout.WEST);
        if(horizontalSeparatorStyle == TOP_HORIZONTAL_SEPARATOR){
            container.add(new JSeparator(), BorderLayout.NORTH);
        }else{
            if(horizontalSeparatorStyle == BOTTOM_HORIZONTAL_SEPARATOR){
                container.add(new JSeparator(), BorderLayout.SOUTH);
            }else{
                container.add(new JSeparator(), BorderLayout.NORTH);
                container.add(new JSeparator(), BorderLayout.SOUTH);
            }
        }
        if(Boolean.parseBoolean(getProperty("showAdvertisementButton"))){
            addAdvertisementButton(
                    ImageUtil.getIconSystemResource(
                            getProperty("advertisementButtonIcon")),
                            getProperty("advertisementButtonURL"));
        }

        return container;
    }


    public JPanel getToolBar(){
        LOGGER.finest("PANEL IN TOOLBARIMPL 2 = " + toolBar);
        return toolBar;
    }


    public void addTool(String nameKey, int desiredIndex, boolean indexReserved,
                        JToolBar tool){
        toolBar.addTool(nameKey, desiredIndex, indexReserved, tool);
        LOGGER.finest("adding MenuBarComponent in MBI = " + nameKey + ", desiredIndex = " + desiredIndex);
    }


    public void reactivateTool(String nameKey){
        toolBar.reactivateTool(nameKey);
    }


    public void suspendTool(String nameKey){
        toolBar.suspendTool(nameKey);
    }


    public void removeTool(String nameKey){
        LOGGER.finest("REMOVING TOOL WITH KEYNAME = " + nameKey);
        toolBar.removeTool(nameKey);
    }


    private void addAdvertisementButton(Icon icon, String url){
        Action advert = new ToolBarAdvertisementAction(icon, url);
        container.add(createAdvertisementButton(advert, url), BorderLayout.EAST);
        toolBar.validate();
    }


    private JButton createAdvertisementButton(Action a, String url){
        JRolloverButton advertButton = new JRolloverButton(a);
        if(!url.startsWith("http://")){
            url = "http://".concat(url);
        }
        advertButton.setToolTipText(url);
        advertButton.setOpaque(true);
        advertButton.setBackground(Color.WHITE);
        Icon icon = (Icon)a.getValue(Action.SMALL_ICON);
        advertButton.setPreferredSize(new Dimension(icon.getIconWidth() + 8, icon.getIconHeight()));
        advertButton.setMaximumSize(new Dimension(icon.getIconWidth() + 8, icon.getIconHeight()));
        advertButton.setMinimumSize(new Dimension(icon.getIconWidth() + 8, icon.getIconHeight()));
        return advertButton;
    }


    private class ToolBarAdvertisementAction
    extends AbstractAction{

        public ToolBarAdvertisementAction(Icon icon, String url){
            super("", icon);
            if(!url.startsWith("http://")){
                url = "http://".concat(url);
            }
            putValue(SHORT_DESCRIPTION, url);
        }

        public void actionPerformed(ActionEvent evt){
            String osName = System.getProperty("os.name", "def");
            String url = (String) getValue(SHORT_DESCRIPTION);
            try{
                if(osName.equals("Mac OS X") || osName.equals("Mac OS")){
                    Runtime.getRuntime().exec("open " + url);
                } else
                if(osName.toLowerCase().startsWith("windows")){
                    Runtime.getRuntime().exec("cmd.exe /c start /b " + url);
                } else{
                    Runtime.getRuntime().exec("netscape " + url);
                }
            }catch(IOException ioe){
                LOGGER.severe("");
            }
        }
    }

}
