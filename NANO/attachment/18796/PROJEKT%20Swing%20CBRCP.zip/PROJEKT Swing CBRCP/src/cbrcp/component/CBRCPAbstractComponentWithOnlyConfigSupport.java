package cbrcp.component;

import cbrcp.component.info.ComponentInfo;
import cbrcp.component.info.version.Version;
import cbrcp.component.info.version.DefaultVersion;

import java.util.Properties;
import java.util.logging.Logger;
import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;


/**
 * An abstract implementation for all components with component configuration
 * support. Provides a {@link cbrcp.component.info.ComponentInfo} object and its
 * initialization by the components config file or by overriding one of the
 * <code>initXXXInfo()</code> methods in your subclass, a {@link #toString()}
 * method for printing purposes, "empty" (only logging statements) lifecycle
 * methods (to overide in subclasses). It also provides built-in component
 * configuration for subclasses (in subclasses use {@link #getProperty(String)}).
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public abstract class CBRCPAbstractComponentWithOnlyConfigSupport
extends CBRCPAbstractComponent{

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(CBRCPAbstractComponentWithOnlyConfigSupport.class.getName());

    /** Configuration properties for this component. */
    protected ComponentConfigProperties properties;


    /**
     * Constructor for configuration support.
     * @param componentConfigFile config file
     */
    public CBRCPAbstractComponentWithOnlyConfigSupport(String componentConfigFile){
        super(new File(componentConfigFile), null);
    }


    /**
     * Initialize all info for this component encapsulated in a
     * {@link cbrcp.component.info.ComponentInfo} object, containing:
     * <OL>
     *  <LI>role,</LI>
     *  <LI>description,</LI>
     *  <LI>provider,</LI>
     *  <LI>author,</LI>
     * <LI>userDefined (optional),</LI>
     *  <LI>version.</LI>
     * </OL>
     *
     * @return all info for this component
     */
    protected ComponentInfo initComponentInfo(){
        properties = new ComponentConfigProperties(componentConfigFile);
        ComponentInfo componentInfo = new ComponentInfo(getClass());
        try{
            componentInfo.setRole(initRoleInfo() != null ? initRoleInfo() :
                    properties.getProperty("componentRole"));
            componentInfo.setDescription(initDescriptionInfo() != null ?
                    initDescriptionInfo() : properties.getProperty("componentDescription"));
            componentInfo.setProvider(initProviderInfo() != null ? initProviderInfo() :
                    properties.getProperty("componentDescription"));
            componentInfo.setAuthor(initAuthorInfo() != null ? initAuthorInfo() :
                    properties.getProperty("componentAuthor"));
            componentInfo.setVersion(initVersionInfo() != null ? initVersionInfo() :
                    new DefaultVersion(properties.getProperty("componentVersion"),
                            getClass()));
            componentInfo.setUserDefined(initRoleInfo() != null ? initRoleInfo() :
                    properties.getProperty("componentUserDefined"));
        }catch(NullPointerException e){
            LOGGER.severe("No component properties support for '" + getClass().getName() + "', override initXXXInfo()!");
        }
        return componentInfo;
    }


    /**
     * Inits the {@link cbrcp.component.info.ComponentInfo#role} info for this
     * component. Default returns null. Can be overridden in subclasses. If so
     * the values override these of the config file!
     */
    protected String initRoleInfo(){
        return null;
    }


    /**
     * Inits the {@link cbrcp.component.info.ComponentInfo#description} info for
     * this component. Default returns null. Can be overridden in subclasses. If so
     * the values override these of the config file!
     */
    protected String initDescriptionInfo(){
        return null;
    }


    /**
     * Inits the {@link cbrcp.component.info.ComponentInfo#provider} info for this
     *  component. Default returns null. Can be overridden in subclasses. If so
     * the values override these of the config file!
     */
    protected String initProviderInfo(){
        return null;
    }


    /**
     * Inits the {@link cbrcp.component.info.ComponentInfo#author} info for this
     *  component. Default returns null. Can be overridden in subclasses. If so
     * the values override these of the config file!
     */
    protected String initAuthorInfo(){
        return null;
    }


    /**
     * Inits the {@link cbrcp.component.info.ComponentInfo#version} info for this
     * component. Default returns null. Can be overridden in subclasses. If so
     * the values override these of the config file!
     */
    protected Version initVersionInfo(){
        return null;
    }


    /**
     * Inits the {@link cbrcp.component.info.ComponentInfo#userDefined} info for
     * this component. Default returns null. Can be overridden in subclasses. If so
     * the values override these of the config file!
     */
    protected Version initUserDefinedInfo(){
        return null;
    }


    /**
     * Built-in component configuration. Get a component property. For component
     * internal classes use only.
     * @param key for property
     * @return the wanted property
     */
    public String getProperty(String key){
        try{
            return properties.getProperty(key);
        }catch(NullPointerException e){
            if(properties == null){
                LOGGER.warning("NullPointerException: Configuration not supported by this component!");
            }else{
                if(key == null){
                    LOGGER.severe("NullPointerException:Property key must not be null!");
                }else{
                    LOGGER.severe("NullPointerException while accessing property: " + e.getMessage());
                }
            }
        }
        // if any error return empty string
        return "";
    }


    /**
     * Built-in component configuration. Get a component property. For component
     * internal classes use only.
     * @param key for property
     */
    public void setProperty(String key, String value){
        try{
            properties.setProperty(key, value);
        }catch(NullPointerException e){
            if(properties == null){
                LOGGER.warning("NullPointerException: Configuration not supported by this component!");
            }else{
                if(key == null){
                    LOGGER.severe("NullPointerException: Property key must not be null!");
                }else{
                    LOGGER.severe("NullPointerException: NullPointerException while setting property: " + e.getMessage());
                }
            }
        }
    }

}

