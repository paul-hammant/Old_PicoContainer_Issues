package cbrcp.component.menubar;

import javax.swing.JMenuBar;
import javax.swing.JMenu;


/**
 * The communication interface for the MenuBarComponent component.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.8 $, $Date: 2004/09/18 16:03:42 $, last change by: $Author$
 */
public interface MenuBarComponent {

    public static String ROLE = MenuBarComponent.class.getName();

    public JMenuBar getMenuBar();

    public void addMenu(String nameKey, int desiredIndex, boolean indexReserved,
                         JMenu menu);

    public void reactivateMenu(String nameKey);

    public void suspendMenu(String nameKey);

    public void removeMenu(String nameKey);

}
