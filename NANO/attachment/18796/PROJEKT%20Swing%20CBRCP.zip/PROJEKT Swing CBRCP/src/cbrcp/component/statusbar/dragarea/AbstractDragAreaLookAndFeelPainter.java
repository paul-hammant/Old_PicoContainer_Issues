package cbrcp.component.statusbar.dragarea;
import cbrcp.component.statusbar.dragarea.DragAreaPainter;

import java.awt.Graphics2D;
import java.awt.SystemColor;

/**
 * This abstract class paints a common raised or non raised drag area.
 *
 * @author  <A href="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:15 $, last change by: $Author: jens $
 */
public abstract class AbstractDragAreaLookAndFeelPainter implements DragAreaPainter {

    protected boolean raised = true;

    /**
     * Creates a default instance of <CODE>DragAreaXPLookAndFeelPainter</CODE>
     * with a non raised drag area.
     */
    public AbstractDragAreaLookAndFeelPainter() {
        this(false);
    }    
    

    /**
     * Creates a new instance of <CODE>DragAreaXPLookAndFeelPainter</CODE>.
     *
     * @param raised flag if the drag area is shown raised
     */
    public AbstractDragAreaLookAndFeelPainter(boolean raised) {
        this.raised = raised;
    }

    public void setRaised(boolean raised){
        this.raised = raised;
    }

    public boolean isRaised() {
        return raised;
    }
}
