package cbrcp.component.info.version;


/**
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public interface Version {

    public boolean isHigher(Version version);

    public boolean isLower(Version version);

    public boolean isEqual(Version version);

    public String getVersionNumber();

    public Class getOwner();

    public String toString();

}
