package cbrcp.component.lookandfeel;

import cbrcp.component.CBRCPAbstractComponentWithConfigAndNLS;
import cbrcp.component.frame.FrameComponent;
import cbrcp.component.config.ConfigComponent;
import cbrcp.swing.ConfigurationSheet;

import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.plaf.metal.MetalTheme;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.Frame;
import java.util.logging.Logger;
import java.io.File;

import com.jgoodies.looks.plastic.PlasticLookAndFeel;
import com.jgoodies.looks.plastic.PlasticTheme;

import com.incors.plaf.kunststoff.KunststoffLookAndFeel;
import com.incors.plaf.kunststoff.GradientTheme;
import com.l2fprod.gui.plaf.skin.SkinLookAndFeel;
import com.l2fprod.gui.plaf.skin.Skin;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version @version $Revision$, $Date$, last change by: $Author$
 */
public class LookAndFeelManagerComponentImpl extends CBRCPAbstractComponentWithConfigAndNLS
implements LookAndFeelManagerComponent{

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(LookAndFeelManagerComponentImpl.class.getName());

    private static final String NLS_PATH = "cbrcp/component/lookandfeel/nls/lookandfeel-NLS";

    private ConfigComponent configComponent;

    private FrameComponent frameComponent;


    /**
     * Constructor with configuration support and NLS.
     *
     * @param componentConfigFile config file
     */
    public LookAndFeelManagerComponentImpl(FrameComponent frameComponent,
                                           ConfigComponent configComponent,
                                           String componentConfigFile) {
        super(componentConfigFile, NLS_PATH);
        this.configComponent = configComponent;
        this.frameComponent = frameComponent;
    }


    /**
     * Component lifecycle method: starts this component. This method is called from the
     * super container's <CODE>start()</CODE> method. Creates the {@link LookAndFeelConfigurationSheet}
     * and adds it to the {@link ConfigComponent}.
     */
    public void start(){
        setLookAndFeel(getProperty("lookAndFeelClass"), getProperty("lookAndFeelThemeClass"));
        setDefaultLookAndFeelDecorated(Boolean.parseBoolean(getProperty("defaultLookAndFeelDecorated")));
        setDynamicLayout(Boolean.parseBoolean(getProperty("dynamicLayout")));
        super.start();  // log start
        LookAndFeelConfigurationModel configurationModel = new LookAndFeelConfigurationModel();
        ConfigurationSheet lAndFPanel = new LookAndFeelConfigurationSheet(this, configurationModel);
        configComponent.addConfigurationSheet(lAndFPanel);
    }


    void setDefaultLookAndFeelDecorated(boolean decoratedLAndF){
        JFrame.setDefaultLookAndFeelDecorated(decoratedLAndF);
    }

    void setDynamicLayout(boolean dynamicLayout){
        Toolkit.getDefaultToolkit().setDynamicLayout(dynamicLayout);
    }


    /**
     * Setup for L&F.
     */
    void setLookAndFeel(String lookAndFeelClassName, String lookAndFeelThemeClassName){
        Object lookAndFeelTheme = null;
        Class lookAndFeelThemeClass = null;

        // instantiate theme class
    /*    if(lookAndFeelThemeClassName != null && !lookAndFeelThemeClassName.equals("")){
            try{
                lookAndFeelThemeClass = Class.forName(lookAndFeelThemeClassName);
                lookAndFeelTheme = lookAndFeelThemeClass.newInstance();
            }catch(ClassNotFoundException e){
                LOGGER.warning("ClassNotFoundException for L&F theme classname '"
                        + lookAndFeelThemeClassName + "', theme not used.");
            }catch(InstantiationException e){
                LOGGER.warning("InstantiationException for L&F theme classname '"
                        + lookAndFeelThemeClassName + "', theme not used.");
            }catch(IllegalAccessException e){
                LOGGER.warning("IllegalAccessException for L&F theme classname '"
                        + lookAndFeelThemeClassName + "', theme not used.");
            }
        }  */
        if(lookAndFeelThemeClassName != null){
            ThemeProxy themeProxy = new ThemeProxy(lookAndFeelThemeClassName, null);
            lookAndFeelThemeClass = themeProxy.getLookAndFeelThemeClass();
            lookAndFeelTheme = themeProxy.newLookAndFeelThemeInstance();
        }
        // instantiate L&F
        LookAndFeel lookAndFeel = null;
        try{
            Class lookAndFeelClass = Class.forName(lookAndFeelClassName);
            if(lookAndFeelTheme != null){
                Class formParams[] = new Class[]{lookAndFeelThemeClass};
                Constructor con = null;
                try{
                    con = lookAndFeelClass.getConstructor(formParams[0]);
                    Object[] actParams = new Object[]{lookAndFeelTheme};
                    lookAndFeel = (LookAndFeel) con.newInstance(actParams);
                }catch(NoSuchMethodException e){
                    LOGGER.warning("NoSuchMethodException while passing L&F theme '" +
                            lookAndFeelThemeClassName + "' \ninto constructor of object '"
                    + lookAndFeelClassName + "', \nignoring theme or doing workaround for theme if possible...");
                    lookAndFeel = (LookAndFeel) lookAndFeelClass.newInstance();
                }catch(InvocationTargetException e){
                    LOGGER.warning("InvocationTargetException while passing L&F theme '" +
                            lookAndFeelThemeClassName + "' \ninto constructor of object '"
                    + lookAndFeelClassName + "', \nignoring theme or doing workaround for theme if possible...");
                    lookAndFeel = (LookAndFeel) lookAndFeelClass.newInstance();
                }
            }else{
                lookAndFeel = (LookAndFeel) lookAndFeelClass.newInstance();
            }
        }catch(ClassNotFoundException e){
            LOGGER.warning("ClassNotFoundException for L&F classname '"
                    + lookAndFeelClassName + "', switching to system L&F");
            setSystemLookAndFeel();
            return;
        }catch(InstantiationException e){
            LOGGER.warning("InstantiationException for L&F classname '"
                    + lookAndFeelClassName + "', switching to system L&F");
            setSystemLookAndFeel();
            return;
        }catch(IllegalAccessException e){
            LOGGER.warning("IllegalAccessException for L&F classname '"
                    + lookAndFeelClassName + "', switching to system L&F");
            setSystemLookAndFeel();
            return;
        }

        // last but not least set the L&F
        try{
            if(lookAndFeel instanceof PlasticLookAndFeel && lookAndFeelTheme != null){
                workAroundPlasticLAndF(lookAndFeelTheme);
            }
            if(lookAndFeel instanceof KunststoffLookAndFeel && lookAndFeelTheme != null){
                workAroundKunstoffLAndF(lookAndFeelTheme);
            }
            // TODO funzt noch nicht: SkinLookAndFeel
            if(lookAndFeel instanceof SkinLookAndFeel){
                workAroundSkinLAndF();
            }
            UIManager.setLookAndFeel(lookAndFeel);
            SwingUtilities.updateComponentTreeUI(frameComponent.getFrame());
            for ( Frame f : Frame.getFrames() ){
              SwingUtilities.updateComponentTreeUI( f );
              for ( Window w : f.getOwnedWindows()  )
                SwingUtilities.updateComponentTreeUI( w );
            }
        } catch (UnsupportedLookAndFeelException e) {
            LOGGER.warning("L&F '" + lookAndFeel.getClass().getName() + "' not " +
                    "supported by System, switching to system L&F!");
            setSystemLookAndFeel();
        }
    }


    // TODO: maybe this must be supported for other themes

    private static void workAroundSkinLAndF(){
        try{
            Skin theSkinToUse = SkinLookAndFeel.loadThemePack(new File("./core-lib/skinlf1.2.12-20051009-themepack-.zip").getAbsolutePath());
            SkinLookAndFeel.setSkin(theSkinToUse);
        }catch(Exception e){
            LOGGER.info("workAroundSkinLAndF(): " + e.getMessage());
        }
        LOGGER.info("...workaround for Skin themepack successful!");
    }

    /**
     * Workaround for JGoodies' "looks-1.3.2" L&F: it has no constructor to set
     * theme.
     * @param lookAndFeelTheme to workaround
     */
    private static void workAroundPlasticLAndF(Object lookAndFeelTheme){
        PlasticLookAndFeel.setMyCurrentTheme((PlasticTheme) lookAndFeelTheme);
        LOGGER.info("...workaround for theme '" + lookAndFeelTheme.getClass().getName() + "' successful!");
    }


    /**
     * Workaround for incors.org's "kunststoff-2.0.2" L&F: it has no constructor
     * to set theme.
     * @param lookAndFeelTheme to workaround
     */
    private static void workAroundKunstoffLAndF(Object lookAndFeelTheme){
        if(lookAndFeelTheme instanceof MetalTheme){
            KunststoffLookAndFeel.setCurrentTheme((MetalTheme) lookAndFeelTheme);
        }
        if(lookAndFeelTheme instanceof GradientTheme){
            KunststoffLookAndFeel.setCurrentGradientTheme((GradientTheme) lookAndFeelTheme);
        }
        LOGGER.info("...workaround for theme '" + lookAndFeelTheme.getClass().getName() + "' successful!");
    }


    /**
     * Loads System L&F.
     */
    private static void setSystemLookAndFeel(){
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }catch(ClassNotFoundException e){
            LOGGER.severe("ClassNotFoundException for classname '"
                    + UIManager.getSystemLookAndFeelClassName() + "', switching to default L&F");
        }catch(InstantiationException e){
            LOGGER.severe("InstantiationException for classname '"
                    + UIManager.getSystemLookAndFeelClassName() + "', switching to default L&F");
        }catch(IllegalAccessException e){
            LOGGER.severe("IllegalAccessException for classname '"
                    + UIManager.getSystemLookAndFeelClassName() + "', switching to default L&F");
        }catch (UnsupportedLookAndFeelException e) {
            LOGGER.severe("UnsupportedLookAndFeelException: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
