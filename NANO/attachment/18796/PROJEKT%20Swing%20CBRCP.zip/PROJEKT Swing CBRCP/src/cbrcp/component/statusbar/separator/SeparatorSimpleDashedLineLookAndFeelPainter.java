package cbrcp.component.statusbar.separator;

import java.awt.Graphics2D;
import java.awt.SystemColor;

/**
 * This class paints a Windows XP L&amp;F line separator.
 *
 * @author  <A href="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:15 $, last change by: $Author: jens $
 */
public class SeparatorSimpleDashedLineLookAndFeelPainter
extends AbstractSquareDotsSeparatorPainter {

    private static final int OFFSET = 1;

    /** Creates a new instance of <CODE>DragAreaXPLookAndFeelPainter</CODE>. */
    public SeparatorSimpleDashedLineLookAndFeelPainter() {
        super(OFFSET);
    }

    protected void drawDot(Graphics2D g2, int x, int y){
        g2.setColor(SystemColor.controlShadow);
        g2.drawLine(x, y, x, y);
    }

}
