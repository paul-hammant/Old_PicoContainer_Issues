package cbrcp.component;

import cbrcp.component.info.ComponentInfo;
import cbrcp.component.info.version.Version;

import java.util.logging.Logger;


/**
 * This basic abstract implementation for all components provides a
 * {@link cbrcp.component.info.ComponentInfo} object and its initialization by
 * implementing {@link #initComponentInfo()}, a {@link #toString()} method for
 * printing purposes, "empty" (only logging statements) lifecycle methods
 * (to overide in subclasses).
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public abstract class CBRCPAbstractComponentWithBasicInfoSupport extends CBRCPAbstractComponent{

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(CBRCPAbstractComponentWithBasicInfoSupport.class.getName());


    /**
     * Constructor for basic {@link ComponentInfo} support.
     */
    public CBRCPAbstractComponentWithBasicInfoSupport(){
        this(null);
    }


    /**
     * Constructor for NLS.
     * @param resourceBundleName full file path without (!) file ending
     */
    public CBRCPAbstractComponentWithBasicInfoSupport(String resourceBundleName){
        super(resourceBundleName);
    }


    /**
     * Initialize all info for this component encapsulated in a
     * {@link cbrcp.component.info.ComponentInfo} object, containing:
     * <OL>
     *  <LI>role,</LI>
     *  <LI>description,</LI>
     *  <LI>provider,</LI>
     *  <LI>author,</LI>
     * <LI>userDefined (optional),</LI>
     *  <LI>version.</LI>
     * </OL>
     *
     * @return all info for this component
     */
    protected ComponentInfo initComponentInfo(){
        ComponentInfo componentInfo = new ComponentInfo(getClass());
        componentInfo.setRole(initRoleInfo());
        componentInfo.setDescription(initDescriptionInfo());
        componentInfo.setProvider(initProviderInfo());
        componentInfo.setAuthor(initAuthorInfo());
        componentInfo.setVersion(initVersionInfo());
        componentInfo.setUserDefined(initRoleInfo());
        return componentInfo;
    }

}

