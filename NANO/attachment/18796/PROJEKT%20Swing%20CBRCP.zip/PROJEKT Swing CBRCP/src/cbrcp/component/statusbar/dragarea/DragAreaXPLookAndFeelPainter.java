package cbrcp.component.statusbar.dragarea;
import cbrcp.component.statusbar.dragarea.DragAreaPainter;

import java.awt.Graphics2D;
import java.awt.SystemColor;

/**
 * This class paints a Windows XP L&amp;F drag area (Six etched points in a triangle).
 *
 * @author  <A href="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:15 $, last change by: $Author: jens $
 */
public class DragAreaXPLookAndFeelPainter extends AbstractDragAreaLookAndFeelPainter{

    /**
     * Creates a default instance of <CODE>DragAreaXPLookAndFeelPainter</CODE>
     * with a non raised drag area.
     */
    public DragAreaXPLookAndFeelPainter() {
        this(false);
    }


    /**
     * Creates a new instance of <CODE>DragAreaXPLookAndFeelPainter</CODE>.
     *
     * @param raised flag if the drag area is shown raised
     */
    public DragAreaXPLookAndFeelPainter(boolean raised) {
        super(raised);
    }


    /**
     * Paints the custom drag area.  TODO: raised implementieren
     *
     * @param   g2      the graphics context for this painter
     * @param   width   the width of the statusbar, needed to know where to paint
     * @param   height  the height of the statusbar, needed to know where to paint
     */
    public void paint(Graphics2D g2, int width, int height){
        // first point line
        g2.setColor(SystemColor.controlLtHighlight);
        g2.drawLine(width - 3, height - 3, width - 2, height - 3);
        g2.drawLine(width - 3, height - 2, width - 2, height - 2);
        g2.setColor(SystemColor.controlShadow);
        g2.drawLine(width - 4, height - 4, width - 3, height - 4);
        g2.drawLine(width - 4, height - 3, width - 3, height - 3);

        g2.setColor(SystemColor.controlLtHighlight);
        g2.drawLine(width - 7, height - 3, width - 6, height - 3);
        g2.drawLine(width - 7, height - 2, width - 6, height - 2);
        g2.setColor(SystemColor.controlShadow);
        g2.drawLine(width - 8, height - 4, width - 7, height - 4);
        g2.drawLine(width - 8, height - 3, width - 7, height - 3);

        g2.setColor(SystemColor.controlLtHighlight);
        g2.drawLine(width - 11, height - 3, width - 10, height - 3);
        g2.drawLine(width - 11, height - 2, width - 10, height - 2);
        g2.setColor(SystemColor.controlShadow);
        g2.drawLine(width - 12, height - 4, width - 11, height - 4);
        g2.drawLine(width - 12, height - 3, width - 11, height - 3);

        // second point line
        g2.setColor(SystemColor.controlLtHighlight);
        g2.drawLine(width - 3, height - 7, width - 2, height - 7);
        g2.drawLine(width - 3, height - 6, width - 2, height - 6);
        g2.setColor(SystemColor.controlShadow);
        g2.drawLine(width - 4, height - 8, width - 3, height - 8);
        g2.drawLine(width - 4, height - 7, width - 3, height - 7);

        g2.setColor(SystemColor.controlLtHighlight);
        g2.drawLine(width - 7, height - 7, width - 6, height - 7);
        g2.drawLine(width - 7, height - 6, width - 6, height - 6);
        g2.setColor(SystemColor.controlShadow);
        g2.drawLine(width - 8, height - 8, width - 7, height - 8);
        g2.drawLine(width - 8, height - 7, width - 7, height - 7);

        // last point
        g2.setColor(SystemColor.controlLtHighlight);
        g2.drawLine(width - 3, height - 11, width - 2, height - 11);
        g2.drawLine(width - 3, height - 10, width - 2, height - 10);
        g2.setColor(SystemColor.controlShadow);
        g2.drawLine(width - 4, height - 12, width - 3, height - 12);
        g2.drawLine(width - 4, height - 11, width - 3, height - 11);
    }

}
