package cbrcp.component.config.action;

import javax.swing.ImageIcon;

import cbrcp.action.ActionHandler;
import cbrcp.action.AbstractHandledAction;
import cbrcp.component.config.ConfigComponentImpl;

import java.awt.event.ActionEvent;
import java.util.logging.Logger;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.7 $, $Date: 2006/01/19 19:58:38 $, last change by: $Author: jens $
 */
public class ShowConfigurationAction extends AbstractHandledAction  {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(ShowConfigurationAction.class.getName());

    public static final String ID = ShowConfigurationAction.class.getName();

    private ConfigComponentImpl config;

    public ShowConfigurationAction(ConfigComponentImpl config, ActionHandler handler, String name,
                                   ImageIcon icon, String desc, Integer mnemonic) {
        super(handler, name, icon, desc, mnemonic);
        this.config = config;
    }


    public void actionPerformed(ActionEvent evt) {
        config.showDialog(true);
    }
}
