package cbrcp.component.lookandfeel;

import cbrcp.swing.JConfigurationSheet;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import javax.swing.border.TitledBorder;

import info.clearthought.layout.TableLayout;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class LookAndFeelConfigurationSheet extends JConfigurationSheet {
      // TODO implement   LookAndFeelConfigurationSheet

    private LookAndFeelManagerComponentImpl lookAndFeelManager;

    private LookAndFeelConfigurationModel configurationModel;

    private JComboBox lookAndFeelsComboBox;

    private JComboBox lookAndFeelThemesComboBox;

    /**
     * Creates a new <code>JPanel</code> with a double buffer and a flow
     * layout.
     */
    public LookAndFeelConfigurationSheet(LookAndFeelManagerComponentImpl lookAndFeelManager, LookAndFeelConfigurationModel configurationModel) {
        super(lookAndFeelManager.getMessage("lookAndFeelConfigSheetTitle"),
              lookAndFeelManager.getMessage("lookAndFeelConfigSheetToolTip"));
        this.lookAndFeelManager = lookAndFeelManager;
        this.configurationModel = configurationModel;

        String lookAndFeelClassName = LookAndFeelConfigurationModel.getActualLookAndFeelClassName();
        String lookAndFeelThemeClassName = lookAndFeelManager.getProperty("lookAndFeelThemeClass");
        //String[] lookAndFeels = configurationModel.getLookAndFeelNames();
        lookAndFeelsComboBox = new JComboBox(configurationModel.getLookAndFeelProxies());//lookAndFeels);
        lookAndFeelsComboBox.setSelectedItem(configurationModel.getLookAndFeelProxy(lookAndFeelClassName));

        //String[] lookAndFeelThemes = configurationModel.getLookAndFeelThemeNames(lookAndFeelClassName);
        Vector<ThemeProxy> themeProxies = ((AbstractLookAndFeelProxy)lookAndFeelsComboBox.getSelectedItem()).
                        getThemeProxies();
        if(themeProxies != null){
            lookAndFeelThemesComboBox = new JComboBox(themeProxies);//lookAndFeelThemes);
        }else{
            lookAndFeelThemesComboBox = new JComboBox();
        }
        if(lookAndFeelThemesComboBox.getItemCount() == 0){
            lookAndFeelThemesComboBox.setEnabled(false);
        }
        if(lookAndFeelThemeClassName != null && !lookAndFeelThemeClassName.equals("")){
            ThemeProxy themeProxy = configurationModel.getLookAndFeelThemeProxy(lookAndFeelThemeClassName);
            if(themeProxy != null){
                lookAndFeelThemesComboBox.setSelectedItem(themeProxy);
            }
        }
        initLookAndFeelsComboBoxActionListener();

        double p = TableLayout.PREFERRED;
        double border = 10;

        double layoutSettings[][] = {{border, 50, p, border}, // columns
                                     {border, border}}; // rows
        TableLayout layout = new TableLayout(layoutSettings);
        setLayout(layout);
        layout.setVGap(2);
        layout.setHGap(5);

        JLabel landfLabel = new JLabel("L&F");
        JLabel landfThemesLabel = new JLabel("Theme");

        layout.insertRow(1, p);
        add(landfLabel, "1, 1, 1, 1, RIGHT, CENTER");
        add(lookAndFeelsComboBox, "2, 1");

        layout.insertRow(2, p);
        add(landfThemesLabel, "1, 2, 1, 2, RIGHT, CENTER");
        add(lookAndFeelThemesComboBox, "2, 2");

        TitledBorder titled = BorderFactory.createTitledBorder("L&F/Themes");
        titled.setTitleFont(new Font("Sans-Serif", Font.PLAIN, 11));
        setBorder(titled);

    }


    private void initLookAndFeelsComboBoxActionListener() {
        lookAndFeelsComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                lookAndFeelsComboBoxActionPerformed();
            }
        });
    }


    private void lookAndFeelsComboBoxActionPerformed(){
        if(lookAndFeelThemesComboBox.getItemCount() == 0){
            lookAndFeelThemesComboBox.setEnabled(true);
        }else{
            lookAndFeelThemesComboBox.removeAllItems();    // TODO hier gehen proxies verloren Memory Leak?
        }
        Vector<ThemeProxy> themeProxies = ((AbstractLookAndFeelProxy)
                lookAndFeelsComboBox.getSelectedItem()).getThemeProxies();//lookAndFeelThemes);    // TODO hier gehen proxies verloren
        if(themeProxies != null && themeProxies.size() > 0){
            for(ThemeProxy proxy : themeProxies){
                lookAndFeelThemesComboBox.addItem(proxy);
            }
            setConfigurationChanged(true);

            String lookAndFeelThemeClassName = lookAndFeelManager.getProperty("lookAndFeelThemeClass");
            if(lookAndFeelThemeClassName != null && !lookAndFeelThemeClassName.equals("")){
                ThemeProxy themeProxy = configurationModel.getLookAndFeelThemeProxy(lookAndFeelThemeClassName);
                if(themeProxy != null && themeProxy.getLookAndFeelProxyOwner().equals(
                        ((ThemeProxy)lookAndFeelThemesComboBox.getSelectedItem()).getLookAndFeelProxyOwner())){
                    lookAndFeelThemesComboBox.setSelectedItem(themeProxy);
                }
            }

        }else{
            lookAndFeelThemesComboBox.setEnabled(false);
        }
    }




    /**
     * Save configration.
     */
    public void acceptConfigurationChange() {

        String lookAndFeelClassName = ((AbstractLookAndFeelProxy)lookAndFeelsComboBox.getSelectedItem()).getLookAndFeelClassName();
        ThemeProxy themeProxy = ((ThemeProxy)lookAndFeelThemesComboBox.getSelectedItem());
        String lookAndFeelThemeClassName = "";
        if(themeProxy != null){
            lookAndFeelThemeClassName = themeProxy.getLookAndFeelThemeClassName();
        }


        lookAndFeelManager.setLookAndFeel(lookAndFeelClassName, lookAndFeelThemeClassName);


        lookAndFeelManager.setProperty("lookAndFeelClass", lookAndFeelClassName);
        lookAndFeelManager.setProperty("lookAndFeelThemeClass", lookAndFeelThemeClassName);
    }
}
