package cbrcp.component.config;

import cbrcp.swing.ConfigurationSheet;

import javax.swing.Icon;

import java.awt.Component;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version @version $Revision$, $Date$, last change by: $Author$
 */
public interface ConfigComponent {

    /** Role name for the component. */
    public static final String ROLE = ConfigComponent.class.getName();


    /**
     * Removes the specified {@link cbrcp.swing.ConfigurationSheet} from the {@link ConfigComponent}.
     * @param sheet the {@link cbrcp.swing.ConfigurationSheet} to remove from the {@link ConfigComponent}
     */
    public void removeConfigurationSheet(ConfigurationSheet sheet);

    /**
     * Adds a {@link ConfigurationSheet} to the configuration.
     */
    public void addConfigurationSheet(ConfigurationSheet sheet);

}