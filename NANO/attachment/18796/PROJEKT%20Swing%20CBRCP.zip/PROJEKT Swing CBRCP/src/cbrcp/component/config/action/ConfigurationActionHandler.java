package cbrcp.component.config.action;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;

import java.awt.event.KeyEvent;

import java.util.logging.Logger;

import cbrcp.action.AbstractActionHandler;
import cbrcp.component.frame.FrameComponent;
import cbrcp.component.frame.action.ExitAction;
import cbrcp.component.config.ConfigComponentImpl;


/**
 * @author <A HREF="mailto:jens.krefeldt@informatik.uni-oldenburg.de">Jens Krefeldt</A>
 * @version $Revision: 1.9 $, $Date: 2006/01/19 19:58:38 $, last change by: $Author: jens $
 */
public class ConfigurationActionHandler extends AbstractActionHandler {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(ConfigurationActionHandler.class.getName());

    public final static String ID = ConfigurationActionHandler.class.getName();

    public final static String EXIT_ACTION_NAME = ExitAction.ID;

    protected Action showConfigurationAction;

    public ConfigurationActionHandler(ConfigComponentImpl config, FrameComponent frame){
        super(config.getMessage("configurationActionHandlerName"), MENU_MODE, frame.getFrame());
        initActions(config, frame);
        initMenu();
    }

    protected void initActions(ConfigComponentImpl config, FrameComponent frame){
        ImageIcon showConfigurationIcon = getIconSystemResource(config.getProperty("showConfigurationActionImage"));
        showConfigurationAction = new ShowConfigurationAction(config, this, config.getMessage("showConfigActionName"),
                showConfigurationIcon, config.getMessage("showConfigurationActionTooltip"), new Integer(KeyEvent.VK_E));

        actions.put(ExitAction.ID, showConfigurationAction);
        showConfigurationAction.setEnabled(true);
    }


    protected void initMenu(){
        menu.setMnemonic(KeyEvent.VK_E);
        menu.add(new JSeparator());
        menu.add(showConfigurationAction);
    }

}
