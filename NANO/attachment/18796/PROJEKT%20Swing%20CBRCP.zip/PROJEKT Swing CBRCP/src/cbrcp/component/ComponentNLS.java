package cbrcp.component;

import java.util.ResourceBundle;
import java.util.MissingResourceException;
import java.util.Locale;
import java.util.logging.Logger;


/**
 * A messages handler for NLS (Native Language Support, <CODE>i18n</CODE>) used
 * by a {@link CBRCPComponent}.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:16 $, last change by: $Author: jens $
 */
class ComponentNLS {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(ComponentNLS.class.getName());

    /** The resource bundle. */
    private ResourceBundle resourceBundle;

    /** {@link CBRCPComponent} which is supported by NLS. */
    private Class owner;

    /**
     * Constructor.
     */
    protected ComponentNLS(String resourceBundleName, Class owner) {
        this.owner = owner;
        try{
            resourceBundle = ResourceBundle.getBundle(resourceBundleName);
        } catch (MissingResourceException e) {
            LOGGER.warning("MissingResourceException for CBRCP component '" + owner.getName() + "': " + e.getMessage());
        }
    }

    /**
     * Getter for the NLS property value.
     *
     * @param key for the NLS property value
     * @return the NLS property value
     */
    protected String getMessage(String key) {
        try {
            return resourceBundle.getString(key);
        } catch (MissingResourceException e) {
            String message = "Missing NLS for key '" + key + "' and locale '" + Locale.getDefault() + "'!";
            LOGGER.warning("MissingResourceException  for CBRCP component '" + owner.getName() + "': " + message);
            return message;
        }
    }
}
