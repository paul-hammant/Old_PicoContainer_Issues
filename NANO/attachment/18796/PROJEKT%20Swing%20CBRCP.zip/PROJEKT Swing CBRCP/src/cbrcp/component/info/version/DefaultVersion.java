package cbrcp.component.info.version;

import cbrcp.component.info.version.AbstractVersion;

import java.util.StringTokenizer;
import java.util.logging.Logger;


/**
 * This class wraps a common numeric version string for an object. You can pass a String of
 * following format:
 * <P>
 * <PRE>    &lt;major version number&gt;.&lt;minor version number&gt;.&lt;build version number&gt;</PRE>
 * </P>
 * such as version 2.4.13.
 * <P>
 * This String is parsed and checked for errors, if no errors occurs the version
 * number is extracted and saved in this object else a
 * {@link cbrcp.component.info.version.VersionNumberFormatException} is thrown.
 * <P>
 * You will receive a version {@link String} of following format with {@link #getVersionNumber()}:
 * <P>
 * <PRE>    &lt;major version number&gt;.&lt;minor version number&gt;.&lt;build version number&gt;</PRE>
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class DefaultVersion
extends AbstractVersion
implements Cloneable {

    /** Just for logging purposes. */
    private final static Logger LOGGER = Logger.getLogger(DefaultVersion.class.getName());

    /** The real version value. */
    protected String version = null;


    /**
     * Constructs a version object.
     *
     * @param version the version value
     */
    public DefaultVersion(String version){
        this(version, null);
    }


    /**
     * Constructs a version object.
     *
     * @param version the version value
     * @param owner class signed with this version
     */
    public DefaultVersion(String version, Class owner){
        super(version, owner);
    }


    /**
     * Copy constructor.
     *
     * @param version the version to copy
     */
    public DefaultVersion(Version version){
        super(version);
    }


    /**
     * Checks if the passed String is a valid version value.
     * Override this method to provide your own specific checking algorithm.
     * Remember that you call <CODE>super.checkVersionString()</CODE> at the end
     * of your own method!
     *
     * @return the checked string
     * @throws cbrcp.component.info.version.VersionNumberFormatException if the format is not a valid version
     *         number
     */
    protected String checkVersionString(String version)
            throws VersionNumberFormatException {
        StringTokenizer versionNumbers = new StringTokenizer(version, ".");
        String numberToken = null;
        while(versionNumbers.hasMoreTokens()){
            numberToken = versionNumbers.nextToken();
            try{
                Integer.parseInt(numberToken);
            }catch(NumberFormatException nfe){
                this.version = "0.0.1";
                throw new VersionNumberFormatException(version + " is not a correct version number."
                                                      + "Correct syntax: "
                                                      + "<major version number>."
                                                      + "<minor version number>."
                                                      + "<build version number>");
            }
        }
        return version;
    }


    /**
     * Creates and returns a copy of this object.
     *
     * @return a clone of this instance
     * @throws CloneNotSupportedException if the object's class does not support
     *                                    the Cloneable interface. Subclasses that
     *                                    override the clone method can also throw
     *                                    this exception to indicate that an instance
     *                                    cannot be cloned
     */
    public Object clone() throws CloneNotSupportedException{
        super.clone();
        return new DefaultVersion(this);
    }
}
