package cbrcp.component.lookandfeel;

import java.util.logging.Logger;
import java.io.File;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class SkinLookAndFeelProxy extends AbstractLookAndFeelProxy {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(SkinLookAndFeelProxy.class.getName());

    private static final String SKIN_L_AND_F =
            "com.l2fprod.gui.plaf.skin.SkinLookAndFeel";


    public SkinLookAndFeelProxy(){// throws OSNotSupportedByLookAndFeelException{
        super(SKIN_L_AND_F);
        try{
            System.load(new File("core-lib/nativeskinwin32.dll").getAbsolutePath());

            //System.load(new File("core-lib/awt.dll").getAbsolutePath());
            LOGGER.info(System.getProperty("java.library.path"));
            System.load(new File("core-lib/nativeskinwin32JAWT.dll").getAbsolutePath());
            LOGGER.info(System.getProperty("java.library.path"));
        }catch(Exception e){
            LOGGER.warning(e.getMessage());
            Class skinClass = null;
            try{
                skinClass = Class.forName(SKIN_L_AND_F);
            }catch(ClassNotFoundException cnfe){
                LOGGER.warning("ClassNotFoundException for L&F theme classname '"
                        + SKIN_L_AND_F + "'.");
                //throw new OSNotSupportedByLookAndFeelException(skinClass);
            }
        }
    }
}
