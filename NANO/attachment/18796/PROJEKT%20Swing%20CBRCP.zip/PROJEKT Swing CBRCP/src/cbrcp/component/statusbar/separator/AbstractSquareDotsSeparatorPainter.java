package cbrcp.component.statusbar.separator;

import cbrcp.component.statusbar.separator.SeparatorPainter;

import java.awt.Graphics2D;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:15 $, last change by: $Author: jens $
 */
public abstract class AbstractSquareDotsSeparatorPainter implements SeparatorPainter {

    private int offset;

    public AbstractSquareDotsSeparatorPainter(int offset) {
        this.offset = offset;
    }

    /**
     * Paints the separator.
     *
     * @param   g2      the graphics context for this painter
     * @param   width   the width of the statusbar, needed to know where to paint
     * @param   height  the height of the statusbar, needed to know where to paint
     */
    public void paint(Graphics2D g2, int width, int height){
        int x = getFirstX(width);
        int y = getFirstY(height);

        while (y + offset < height){
            drawDot(g2, x, y);
            y = y + offset + 1;
        }
    }

    public int getRequiredWidth(){
        return offset;
    }

    private int getFirstX(int width){
        int x = 0;
        if(width % 2 == 0){
            x = width / 2 - offset / 2;
        }else{
            x = width / 2 + 1 - offset / 2;
        }
        return x;
    }

    private int getFirstY(int height){
        int y = 0;
        if(height % 2 == 0){
            y = (height / (height / offset)) + 1 ;
        }else{
            y = (height % (height / offset)) + 1 ;
            //y = height / 2 + 1 - offset / 2;
        }
        return y;
    }

    protected abstract void drawDot(Graphics2D g2, int x, int y);
}
