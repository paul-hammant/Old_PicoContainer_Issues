package cbrcp.component.statusbar.separator;

import java.awt.Graphics2D;

/**
 * The interface every custom {@link SeparatorPainter} object hast to implement. There
 * is only one method: <CODE>paint(...)</CODE> to do the painting work for the
 * separator.
 *
 * @author  <A href="mailto:jens.krefeldt@informatik.uni-oldenburg.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:15 $, last change by: $Author: jens $
 */
public interface SeparatorPainter {

    /**
     * Paints the custom drag area.
     *
     * @param   g2      the graphics context for this painter
     * @param   width   the width of the statusbar, needed to know where to paint
     * @param   height  the height of the statusbar, needed to know where to paint
     */
    public void paint(Graphics2D g2, int width, int height);

    public int getRequiredWidth();

}
