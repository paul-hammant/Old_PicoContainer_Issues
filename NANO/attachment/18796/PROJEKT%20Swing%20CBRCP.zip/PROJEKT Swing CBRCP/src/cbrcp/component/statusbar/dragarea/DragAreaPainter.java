package cbrcp.component.statusbar.dragarea;

import java.awt.Graphics2D;

/**
 * The interface every custom {@link DragAreaPainter} object has to implement.<P>
 *
 * To write your own just implement the {@link DragAreaPainter#paint} method
 * and set it into the {@link cbrcp.component.statusbar.JStatusBar} with its
 * {@link cbrcp.component.statusbar.JStatusBar#setDragAreaPainter} method.
 *
 * @author  <A href="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:15 $, last change by: $Author: jens $
 */
public interface DragAreaPainter {

    /**
     * Paints the custom drag area.
     *
     * @param   g2      the graphics context for this painter
     * @param   width   the width of the statusbar, needed to know where to paint
     * @param   height  the height of the statusbar, needed to know where to paint
     */
    public void paint(Graphics2D g2, int width, int height);

    public void setRaised(boolean raised);

}
