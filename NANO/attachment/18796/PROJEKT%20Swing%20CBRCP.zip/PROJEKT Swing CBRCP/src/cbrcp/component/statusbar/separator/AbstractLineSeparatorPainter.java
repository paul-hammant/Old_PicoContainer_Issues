package cbrcp.component.statusbar.separator;

import cbrcp.component.statusbar.separator.SeparatorPainter;

import java.awt.Graphics2D;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:15 $, last change by: $Author: jens $
 */
public abstract class AbstractLineSeparatorPainter implements SeparatorPainter {

    private int lineThickness;

    private boolean bevel;

    private boolean raised;

    public AbstractLineSeparatorPainter(int lineThickness) {
        this(lineThickness, false);
    }

    public AbstractLineSeparatorPainter(int lineThickness, boolean bevel) {
        this(lineThickness, bevel, false);

    }

    public AbstractLineSeparatorPainter(int lineThickness, boolean bevel, boolean raised) {
        this.lineThickness = lineThickness;
        this.bevel = bevel;
        this.raised = raised;
    }

    /**
     * Paints the separator.
     *
     * @param   g2      the graphics context for this painter
     * @param   width   the width of the statusbar, needed to know where to paint
     * @param   height  the height of the statusbar, needed to know where to paint
     */
    public void paint(Graphics2D g2, int width, int height){
        int x = getFirstX(width);
        int y = getFirstY(height);

        while (y + lineThickness < height){
            drawLine(g2, x, y);
            y = y + lineThickness + 1;
        }
    }

    public int getRequiredWidth(){
        return lineThickness;
    }

    private int getFirstX(int width){
        int x = 0;
        if(width % 2 == 0){
            x = width / 2 - lineThickness / 2;
        }else{
            x = width / 2 + 1 - lineThickness / 2;
        }
        return x;
    }

    private int getFirstY(int height){
        int y = 0;
        if(height % 2 == 0){
            y = (height / (height / lineThickness)) + 1 ;
        }else{
            y = (height % (height / lineThickness)) + 1 ;
            //y = height / 2 + 1 - offset / 2;
        }
        return y;
    }

    protected abstract void drawLine(Graphics2D g2, int x, int y);
}
