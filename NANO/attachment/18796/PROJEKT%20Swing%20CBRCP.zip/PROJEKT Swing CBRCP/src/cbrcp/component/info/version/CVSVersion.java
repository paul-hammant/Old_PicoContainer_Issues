package cbrcp.component.info.version;

import cbrcp.component.info.version.AbstractVersion;

import java.util.logging.Logger;
import java.util.StringTokenizer;


/**
 * This class wraps a CVS version string for an object. You can pass a String of
 * following format:
 * <P>
 * <PRE>    &#036;Revision: &lt;version number&gt; &#036;</PRE>
 * </P>
 * This String is parsed and checked for errors, if no errors occurs the version
 * number is extracted and saved in this object else a
 * {@link cbrcp.component.info.version.VersionNumberFormatException} is thrown.
 * <P>
 * You will receive a version {@link String} of following format with {@link #getVersionNumber()}:
 * <P>
 * <PRE>    &lt;major version number&gt;.&lt;minor version number&gt;.&lt;...&gt;</PRE>
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class CVSVersion
extends AbstractVersion {

    /** Just for logging purposes. */
    private final static Logger LOGGER = Logger.getLogger(CVSVersion.class.getName());


    /**
     * Constructs a CVS version object.
     *
     * @param version the cvs version value
     */
    public CVSVersion(String version) {
        this(version, null);
    }


    /**
     * Constructs a CVS version object.
     *
     * @param version the cvs version value
     * @param owner class signed with this version
     */
    public CVSVersion(String version, Class owner) {
        super(version, owner);
    }


    /**
     * Copy constructor.
     *
     * @param version the version to copy
     */
    public CVSVersion(Version version){
        super(version);
    }


    protected String checkVersionString(String version)
            throws VersionNumberFormatException {
        StringBuffer buffer = null;
        if(!version.startsWith("\u0024Revision:") && !version.endsWith("\u0024")){        // \u0024 = $
            //LOGGER.info("version.startsWith(\u0024Revision) = " + version.startsWith("\u0024Revision:"));
            //LOGGER.info("version.endsWith(\u0024) = " + version.endsWith("\u0024"));
            this.version = "1.1";
            throw new VersionNumberFormatException(version + " is not a correct CVS version string."
                                                  + "Correct syntax: "
                                                  + "\u0024Revision: <major version number>."
                                                  + "<minor version number> \u0024");
        }else{
            buffer = new StringBuffer(version);
            buffer.delete(0, 11); // remove "$Revision:"
            buffer.deleteCharAt(buffer.length() - 1); // remove "$"
            buffer.deleteCharAt(buffer.length() - 1); // " "

            StringTokenizer versionNumbers = new StringTokenizer(buffer.toString(), ".");
            String numberToken = null;
            while(versionNumbers.hasMoreTokens()){
                numberToken = versionNumbers.nextToken();
                try{
                    //LOGGER.info("Parsing NumberToken = " + numberToken);
                    Integer.parseInt(numberToken);
                }catch(NumberFormatException nfe){
                    this.version = "1.1";
                    throw new VersionNumberFormatException(version + " is not a correct CVS version number."
                                                          + "Correct syntax: "
                                                          + "<major version number>."
                                                          + "<minor version number>");
                }
            }
        }
        return buffer.toString();
    }


    /**
     * Creates and returns a copy of this object.
     *
     * @return a clone of this instance
     * @throws CloneNotSupportedException if the object's class does not support
     *                                    the Cloneable interface. Subclasses that
     *                                    override the clone method can also throw
     *                                    this exception to indicate that an instance
     *                                    cannot be cloned
     */
    public Object clone() throws CloneNotSupportedException{
        super.clone();
        return new CVSVersion(this);
    }

}
