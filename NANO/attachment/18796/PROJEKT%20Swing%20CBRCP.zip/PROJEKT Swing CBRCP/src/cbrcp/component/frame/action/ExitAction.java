package cbrcp.component.frame.action;

import javax.swing.ImageIcon;

import cbrcp.action.ActionHandler;
import cbrcp.action.AbstractHandledAction;
import cbrcp.component.frame.FrameComponentImpl;

import java.awt.event.ActionEvent;
import java.util.logging.Logger;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.7 $, $Date: 2006/01/19 19:58:38 $, last change by: $Author: jens $
 */
public class ExitAction extends AbstractHandledAction  {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(ExitAction.class.getName());

    public static final String ID = ExitAction.class.getName();

    private FrameComponentImpl frame;

    public ExitAction(FrameComponentImpl frame, ActionHandler handler, String name,
                                 ImageIcon icon, String desc, Integer mnemonic) {
        super(handler, name, icon, desc, mnemonic);
        this.frame = frame;
    }


    public void actionPerformed(ActionEvent evt) {
        frame.exitCBRCP();        
    }
}
