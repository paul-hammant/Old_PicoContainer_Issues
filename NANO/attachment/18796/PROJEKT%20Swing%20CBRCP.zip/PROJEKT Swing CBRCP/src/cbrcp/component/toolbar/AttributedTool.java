package cbrcp.component.toolbar;

import javax.swing.JPanel;

import java.awt.Container;


/**
* @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
* @version $Revision: 1.3 $, $Date: 2004/07/10 13:19:25 $, last change by: $Author$
*/
class AttributedTool{

    private String nameKey;

    private int desiredIndex;

    private boolean indexReserved;

    private Container tool;


    public AttributedTool(String nameKey, int desiredIndex, boolean indexReserved,
                          Container tool){
        this.nameKey = nameKey;
        this.desiredIndex = desiredIndex;
        this.indexReserved = indexReserved;
        this.tool = tool;
    }


    public String getNameKey() {
        return nameKey;
    }


    public int getDesiredIndex() {
        return desiredIndex;
    }


    public boolean isIndexReserved() {
        return indexReserved;
    }


    public Container getTool() {
        return tool;
    }
}
