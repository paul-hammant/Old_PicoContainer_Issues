package cbrcp.component.frame.action;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;

import java.awt.event.KeyEvent;

import java.util.logging.Logger;

import cbrcp.action.AbstractActionHandler;
import cbrcp.component.frame.FrameComponentImpl;


/**
 * @author <A HREF="mailto:jens.krefeldt@informatik.uni-oldenburg.de">Jens Krefeldt</A>
 * @version $Revision: 1.9 $, $Date: 2006/01/19 19:58:38 $, last change by: $Author: jens $
 */
public class FileActionHandler extends AbstractActionHandler {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(FileActionHandler.class.getName());

    public final static String ID = FileActionHandler.class.getName();

    public final static String EXIT_ACTION_NAME = ExitAction.ID;

    protected Action exitAction;

    public FileActionHandler(FrameComponentImpl frame){
        super(frame.getMessage("fileActionHandlerName"), BOTH_MODE, frame.getFrame());
        initActions(frame);
        initMenu();
    }

    protected void initActions(FrameComponentImpl frame){
        ImageIcon exitIcon = getIconSystemResource(frame.getProperty("exitActionImage"));
        exitAction = new ExitAction(frame, this, frame.getMessage("exitActionName"),
                exitIcon, frame.getMessage("exitActionTooltip"), new Integer(KeyEvent.VK_E));

        actions.put(ExitAction.ID, exitAction);
        exitAction.setEnabled(true);
    }


    protected void initMenu(){
        menu.setMnemonic(KeyEvent.VK_E);
        menu.add(new JSeparator());
        menu.add(exitAction);
    }

}
