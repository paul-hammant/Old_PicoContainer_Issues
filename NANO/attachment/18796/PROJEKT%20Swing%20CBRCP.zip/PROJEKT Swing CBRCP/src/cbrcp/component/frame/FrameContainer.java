package cbrcp.component.frame;

import org.picocontainer.defaults.ComponentAdapterFactory;
import org.picocontainer.defaults.DefaultComponentAdapterFactory;
import org.picocontainer.defaults.CachingComponentAdapter;
import org.picocontainer.defaults.ConstructorInjectionComponentAdapter;
import org.picocontainer.defaults.ConstantParameter;
import org.picocontainer.ComponentAdapter;
import org.picocontainer.PicoContainer;
import org.picocontainer.Parameter;
import org.picocontainer.alternatives.CachingPicoContainer;

import java.util.logging.Logger;

import cbrcp.component.statusbar.StatusBarComponent;
import cbrcp.component.statusbar.StatusBarComponentImpl;
import cbrcp.component.toolbar.ToolBarComponentImpl;
import cbrcp.component.toolbar.ToolBarComponent;
import cbrcp.component.menubar.MenuBarComponent;
import cbrcp.component.menubar.MenuBarComponentImpl;
import cbrcp.container.CBRCPCachingComponentAdapter;


/**
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.3 $, $Date: 2004/11/08 19:33:15 $, last change by: $Author$
 * @deprecated
 */
class FrameContainer
extends CachingPicoContainer{

    /** Just for logging purposes. */
    private final static Logger LOGGER = Logger.getLogger(FrameContainer.class.getName());


    /**
     * Creates a new container with a (caching) DefaultComponentAdapterFactory
     * and no parent container.
     */
    public FrameContainer(){
        this(new DefaultComponentAdapterFactory(), null);
    }


    /**
     * Creates a new container with a (caching) DefaultComponentAdapterFactory
     * and a parent container.
     *
     * @param parent
     */
    public FrameContainer(PicoContainer parent){
        this(new DefaultComponentAdapterFactory(), parent);
    }


    /**
     * Creates a new container with a custom ComponentAdapterFactory and no
     * parent container.
     *
     * @param componentAdapterFactory
     */
    public FrameContainer(ComponentAdapterFactory componentAdapterFactory){
        this(componentAdapterFactory, null);
    }


    /**
     * Creates a new container with a custom ComponentAdapterFactory and a
     * parent container.
     *
     * @param componentAdapterFactory
     * @param parent
     */
    public FrameContainer(ComponentAdapterFactory componentAdapterFactory,
                          PicoContainer parent){
        super(componentAdapterFactory, parent);
        ComponentAdapter statusBarAdapter = new CBRCPCachingComponentAdapter(
                StatusBarComponent.ROLE, StatusBarComponentImpl.class,
                new Parameter[]{new ConstantParameter("./component-config/statusbar-component.properties")});
        registerComponent(statusBarAdapter);
        ComponentAdapter menuBarAdapter = new CBRCPCachingComponentAdapter(
                MenuBarComponent.ROLE, MenuBarComponentImpl.class,
                new Parameter[]{new ConstantParameter("./component-config/menubar-component.properties")});
        registerComponent(menuBarAdapter);
        ComponentAdapter toolBarAdapter = new CBRCPCachingComponentAdapter(
                ToolBarComponent.ROLE, ToolBarComponentImpl.class,
                new Parameter[]{new ConstantParameter("./component-config/toolbar-component.properties")});
        registerComponent(toolBarAdapter);
    }
}
