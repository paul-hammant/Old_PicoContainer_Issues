package cbrcp.component.statusbar;

import cbrcp.component.CBRCPComponent;

import javax.swing.*;
import java.util.Collection;
import java.awt.*;


/**
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.3 $, $Date: 2004/07/13 22:55:39 $, last change by: $Author$
 */
public interface StatusBarComponent{

    /** Role name for the StatusBarComponent component. */
    public static final String ROLE = StatusBarComponent.class.getName();

    public final int DRAG_AREA_DEFAULT_L_AND_F = 0;

    public final int DRAG_AREA_XP_L_AND_F = 1;

    public JStatusBar getStatusBar();

     public Component initStatusBar();

    // TODO raus
    public Component initStatusBar(Collection<Component> fields);

    // TODO raus
    public Component initStatusBar(Collection<Component> fields, boolean raisedDragArea);

    // TODO raus
    public void setDragAreaLAndF(int lookAndFeel);


    /*
     * Creates a new empty instance of <CODE>JStatusBarField</CODE> used for
     * dummy fields.
     */
/*    public JPanel createStatusBarField();                                                */


    /*
     * Creates a new empty instance of <CODE>JStatusBarField</CODE> with a fixed
     * width used for dummy fields. The field has a <CODE>TinyBevelBorder</CODE>.
     */
/*    public JPanel createStatusBarField(int fixedWidth);                                  */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE>with default fonts.
     * It contains of a <CODE>JLabel</CODE> for the appropiate content. The
     * field has a <CODE>TinyBevelBorder</CODE>.
     *
     * @param content Holds the value for the content the field provides .
     */
/*    public JPanel createStatusBarField(String content);                                   */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE> with default
     * fonts. It consists of two horizontal aligned Sections: <P> <OL> <LI>a
     * <CODE>JLabel</CODE> with a label for the content and an icon</LI> <LI>the
     * <CODE>JLabel</CODE> for the appropiate content.</LI> </OL> </P> The field
     * has a <CODE>TinyBevelBorder</CODE>.
     *
     * @param label      Holds the string value for the label.
     * @param labelColor Defines the color for the label.
     * @param content    Holds the value for the content the field provides .
     */
/*    public JPanel createStatusBarField(String label, Color labelColor, String content);   */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE> with default
     * fonts. It consists of two horizontal aligned Sections: <P> <OL> <LI>a
     * <CODE>JLabel</CODE> with a label for the content and an icon</LI> <LI>the
     * <CODE>JLabel</CODE> for the appropiate content.</LI> </OL> </P> The field
     * has a <CODE>TinyBevelBorder</CODE>.
     *
     * @param label               Holds the string value for the label.
     * @param img                 Holds the icon for the field.
     * @param horizontalAlignment For the icon: one of the following constants
     *                            defined in <CODE>SwingConstants</CODE>: LEFT,
     *                            CENTER, RIGHT, LEADING or TRAILING.
     * @param labelColor          Defines the color for the label.
     * @param content             Holds the value for the content the field
     *                            provides .
     */
/*    public JPanel createStatusBarField(String label, ImageIcon img,
                                       int horizontalAlignment, Color labelColor,
                                       String content);                                    */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE>. It contains of a
     * <CODE>JLabel</CODE> for the appropiate content. The field has a
     * <CODE>TinyBevelBorder</CODE>.
     *
     * @param content     Holds the value for the content the field provides .
     * @param contentFont Holds the font value the content has.
     */
/*    public JPanel createStatusBarField(String content, Font contentFont);


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE>. It consists of
     * two  horizontal aligned Sections: <P> <OL> <LI>a <CODE>JLabel</CODE> with
     * a label for the content and an icon</LI> <LI>the <CODE>JLabel</CODE> for
     * the appropiate content.</LI> </OL> </P> The field has a
     * <CODE>TinyBevelBorder</CODE>.
     *
     * @param label       Holds the string value for the label.
     * @param labelColor  Defines the color for the label.
     * @param content     Holds the value for the content the field provides .
     * @param labelFont   Holds the font value the label has.
     * @param contentFont Holds the font value the content has.
     */
/*    public JPanel createStatusBarField(String label, Color labelColor, String content,
                                       Font labelFont, Font contentFont);                    */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE>. It consists of
     * two horizontal aligned Sections: <P> <OL> <LI>a <CODE>JLabel</CODE> with
     * a label for the content and an icon</LI> <LI>the <CODE>JLabel</CODE> for
     * the appropiate content.</LI> </OL> </P> The field has a
     * <CODE>TinyBevelBorder</CODE>.
     *
     * @param label               Holds the string value for the label.
     * @param img                 Holds the icon for the field.
     * @param horizontalAlignment For the icon: one of the following constants
     *                            defined in <CODE>SwingConstants</CODE>: LEFT,
     *                            CENTER, RIGHT, LEADING or TRAILING.
     * @param labelColor          Defines the color for the label.
     * @param content             Holds the value for the content the field
     *                            provides .
     * @param labelFont           Holds the font value the label has.
     * @param contentFont         Holds the font value the content has.
     */
/*    public JPanel createStatusBarField(String label, ImageIcon img,
                                       int horizontalAlignment, Color labelColor,
                                       String content, Font labelFont, Font contentFont);    */

}
