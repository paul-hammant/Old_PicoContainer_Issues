package cbrcp.component.toolbar;

import javax.swing.JButton;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * This class extends a <CODE>JButton</CODE> which has a permanent rollover
 * effect in any L&F.
 *
 * @author <A HREF="mailto:jens.krefeldt@informatik.uni-oldenburg.de">Jens Krefeldt</A>
 * @version $Revision: 1.3 $, $Date: 2004/07/01 15:56:38 $
 */
public class JRolloverButton extends JButton{

    /**
     * Creates a button with no set text or icon.
     */
    public JRolloverButton(){
        this(null, null);
    }

    /**
     * Creates a button where properties are taken from the Action supplied.
     *
     * @param a
     */
    public JRolloverButton(Action a){
        super(a);
        setBorder(new EmptyBorder(0,0,0,0));
        addMouseListener(new RolloverMouseAdapter(this));
    }

    /**
     * Creates a button with an icon.
     *
     * @param icon
     */
    public JRolloverButton(Icon icon){
        this(null, icon);
    }

    /**
     * Creates a button with text.
     *
     * @param text
     */
    public JRolloverButton(String text){
        this(text, null);
    }

    /**
     * Creates a button with initial text and an icon.
     *
     * @param text
     * @param icon
     */
    public JRolloverButton(String text, Icon icon){
        super(text, icon);
        setBorder(new EmptyBorder(0,0,0,0));
        addMouseListener(new RolloverMouseAdapter(this));
    }


    /**
     * Overwritten. Returns always true.
     *
     * @return <CODE>true</CODE>
     */
    public boolean isRolloverEnabled(){
        return true;
    }


    /**
     * Overwritten. No implementation.
     * @param b
     */
    public void setRolloverEnabled(boolean b){

    }


    private class RolloverMouseAdapter
    extends MouseAdapter{

        private JButton b;


        public RolloverMouseAdapter(JButton b){
            this.b = b;
        }


        /**
         * Invoked when the mouse enters a component.
         *
         * @param e
         */
        public void mouseEntered(MouseEvent e){
            if(b.isEnabled()){
                b.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
            }
        }


        /**
         * Invoked when the mouse exits a component.
         *
         * @param e
         */
        public void mouseExited(MouseEvent e){
            b.setBorder(new EmptyBorder(0,0,0,0));
        }

    }

}
