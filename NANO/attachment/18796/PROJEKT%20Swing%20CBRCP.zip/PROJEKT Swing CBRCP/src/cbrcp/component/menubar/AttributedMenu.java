package cbrcp.component.menubar;

import javax.swing.JMenu;


/**
* @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
* @version $Revision: 1.2 $, $Date: 2004/07/02 16:48:10 $, last change by: $Author$
*/
class AttributedMenu{

    private String nameKey;

    private int desiredIndex;

    private boolean indexReserved;

    private JMenu menu;


    public AttributedMenu(String nameKey, int desiredIndex, boolean indexReserved, JMenu menu){
        this.nameKey = nameKey;
        this.desiredIndex = desiredIndex;
        this.indexReserved = indexReserved;
        this.menu = menu;
    }


    public String getNameKey() {
        return nameKey;
    }


    public int getDesiredIndex() {
        return desiredIndex;
    }


    public boolean isIndexReserved() {
        return indexReserved;
    }


    public JMenu getMenu() {
        return menu;
    }
}
