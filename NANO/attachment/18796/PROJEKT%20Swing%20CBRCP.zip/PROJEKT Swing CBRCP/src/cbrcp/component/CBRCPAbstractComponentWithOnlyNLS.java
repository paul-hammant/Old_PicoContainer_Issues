package cbrcp.component;

import cbrcp.component.info.ComponentInfo;
import cbrcp.component.info.version.Version;
import cbrcp.component.info.version.DefaultVersion;

import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.logging.Logger;
import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;


/**
 * An abstract implementation for all components with NLS. Provides a
 * {@link cbrcp.component.info.ComponentInfo}
 * object and its initialization by the components config file or by overriding
 * one of the <code>initXXXInfo()</code> methods in your subclass,
 * a {@link #toString()} method for printing purposes, "empty" (only logging
 * statements) lifecycle methods (to overide in subclasses). It also provides
 * built-in NLS (Native Language Support, in subclasses use
 * {@link #getMessage(String)}).
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public abstract class CBRCPAbstractComponentWithOnlyNLS
extends CBRCPAbstractComponentWithBasicInfoSupport{

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(CBRCPAbstractComponentWithOnlyNLS.class.getName());

    /** Native Language Support (NLS) for this component. */
    private ComponentNLS nls;


    /**
     * Constructor for NLS.
     * @param resourceBundleName full file path without (!) file ending
     */
    public CBRCPAbstractComponentWithOnlyNLS(String resourceBundleName){
        super(resourceBundleName);
    }


    /**
     * Initialize all info for this component encapsulated in a
     * {@link ComponentInfo} object, containing:
     * <OL>
     *  <LI>role,</LI>
     *  <LI>description,</LI>
     *  <LI>provider,</LI>
     *  <LI>author,</LI>
     * <LI>userDefined (optional),</LI>
     *  <LI>version.</LI>
     * </OL>
     *
     * @return all info for this component
     */
    protected ComponentInfo initComponentInfo(){
        nls = new ComponentNLS(resourceBundleName, getClass());
        return super.initComponentInfo();
    }


    /**
     * Built-in NLS. Get a component NLS message. For internal component classes
     * use only.
     * @param key for message
     * @return the wanted property
     */
    public String getMessage(String key){
        try{
            return nls.getMessage(key);
        }catch(NullPointerException e){
            if(nls == null){
                LOGGER.warning("NLS not supported by this component!");
            }else{
                if(key == null){
                    LOGGER.severe("Property key must not be null!");
                }else{
                    LOGGER.severe("NullPointerException while accessing message: " + e.getMessage());
                }
            }
        }
        // if any error return empty string
        return "";
    }

}

