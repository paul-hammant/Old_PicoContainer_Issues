package cbrcp.component.config;

import cbrcp.component.CBRCPAbstractComponentWithConfigAndNLS;
import cbrcp.component.action.ActionHandlerManagerComponent;
import cbrcp.component.config.action.ConfigurationActionHandler;
import cbrcp.component.frame.FrameComponent;
import cbrcp.swing.JCenteredDialog;
import cbrcp.swing.ConfigurationSheet;
import cbrcp.action.DuplicateActionHandlerNameException;

import javax.swing.JTabbedPane;
import javax.swing.JButton;

import java.awt.Component;
import java.awt.Frame;
import java.awt.HeadlessException;
import java.awt.Dimension;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.logging.Logger;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version @version $Revision$, $Date$, last change by: $Author$
 */
public class ConfigComponentImpl extends CBRCPAbstractComponentWithConfigAndNLS
implements ConfigComponent{

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(ConfigComponentImpl.class.getName());

    private FrameComponent frameComponent;

    private ConfigSheetDialog configSheetDialog;

    private JTabbedPane sheetTabbedPane;

    private ActionHandlerManagerComponent actionHandlerMangerComponent;

    /**
     *
     * @param frameComponent
     * @param componentConfigFile
     */
    public ConfigComponentImpl(FrameComponent frameComponent,
                               ActionHandlerManagerComponent actionHandlerMangerComponent,
                               String componentConfigFile){
        super(componentConfigFile, "cbrcp/component/config/nls/config-NLS");
        this.frameComponent = frameComponent;
        this.actionHandlerMangerComponent = actionHandlerMangerComponent;
    }


    /**
     * Component lifecycle method: starts this component. This method is called
     * from the super container's <CODE>start()</CODE> method.
     */
    public void start(){
        super.start();  // log start
        configSheetDialog = new ConfigSheetDialog(frameComponent.getFrame(), getMessage("configSheetTitle"), false);
        ConfigurationActionHandler configActionHandler = new ConfigurationActionHandler(this, frameComponent);

        try{
            actionHandlerMangerComponent.addActionHandler(configActionHandler);
        }catch(DuplicateActionHandlerNameException e){

        }

        //configSheetDialog.setVisible(true);
    }


    public void showDialog(boolean show){
        configSheetDialog.setVisible(show);
    }


    /**
     * Component lifecycle method: stops this component.
     */
    public void stop(){
        super.stop();
        configSheetDialog.setVisible(false);
    }


    /**
     * Component lifecycle method: disposes this component.
     */
    public void dispose(){
        super.dispose();
        stop();
        sheetTabbedPane.removeAll();
        configSheetDialog.remove(sheetTabbedPane);
        sheetTabbedPane = null;
        configSheetDialog.dispose();
    }


    /**
     * Removes the specified {@link ConfigurationSheet} from the {@link ConfigComponent}.
     * @param sheet the {@link ConfigurationSheet} to remove from the {@link ConfigComponent}
     */
    public void removeConfigurationSheet(ConfigurationSheet sheet){
        sheetTabbedPane.remove(sheet.getComponent());
    }


    /**
     * Adds a {@link ConfigurationSheet} to the configuration.
     */
    public void addConfigurationSheet(ConfigurationSheet sheet){
        Component c = sheet.getComponent();
        c.setName(sheet.getTitle());
        int index = sheet.getIndex();
        sheetTabbedPane.add(c, index);
        sheetTabbedPane.setIconAt(index, sheet.getIcon());
        sheetTabbedPane.setToolTipTextAt(index, sheet.getToolTip());

        // resize // TODO funzt noch nicht
        int maxWidth  = (int) Math.max(configSheetDialog.getPreferredSize().getWidth(), c.getPreferredSize().getWidth());
        int maxHeight  = (int) Math.max(configSheetDialog.getPreferredSize().getHeight(), c.getPreferredSize().getHeight());
        configSheetDialog.setPreferredSize(new Dimension(maxWidth, maxHeight));
    }



    private class ConfigSheetDialog extends JCenteredDialog {

        private JButton okJButton;

        private JButton cancelJButton;

        private JButton acceptJButton;

        /**
         * Creates a modal dialog with the specified title and the
         * specified owner <code>Frame</code>.  If <code>owner</code> is
         * <code>null</code>, a shared, hidden frame will be set as the owner of
         * this dialog.  All constructors defer to this one.
         * <p/>
         * NOTE: Any popup components (<code>JComboBox</code>,
         * <code>JPopupMenu</code>, <code>JMenuBar</code>) created within a modal
         * dialog will be forced to be lightweight.
         * <p/>
         * This constructor sets the component's locale property to the value
         * returned by <code>JComponent.getDefaultLocale</code>.
         *
         * @param owner the <code>Frame</code> from which the dialog is displayed
         * @param title the <code>String</code> to display in the dialog's title
         *              bar
         * @throws java.awt.HeadlessException if GraphicsEnvironment.isHeadless()
         *                                    returns true.
         * @see java.awt.GraphicsEnvironment#isHeadless
         * @see javax.swing.JComponent#getDefaultLocale
         */
        public ConfigSheetDialog(Frame owner, String title) throws HeadlessException {
            this(owner, title, true);
        }

        /**
         * Creates a modal or non-modal dialog with the specified title and the
         * specified owner <code>Frame</code>.  If <code>owner</code> is
         * <code>null</code>, a shared, hidden frame will be set as the owner of
         * this dialog.  All constructors defer to this one.
         * <p/>
         * NOTE: Any popup components (<code>JComboBox</code>,
         * <code>JPopupMenu</code>, <code>JMenuBar</code>) created within a modal
         * dialog will be forced to be lightweight.
         * <p/>
         * This constructor sets the component's locale property to the value
         * returned by <code>JComponent.getDefaultLocale</code>.
         *
         * @param owner the <code>Frame</code> from which the dialog is displayed
         * @param title the <code>String</code> to display in the dialog's title
         *              bar
         * @param modal true for a modal dialog, false for one that allows other
         *              windows to be active at the same time
         * @throws java.awt.HeadlessException if GraphicsEnvironment.isHeadless()
         *                                    returns true.
         * @see java.awt.GraphicsEnvironment#isHeadless
         * @see javax.swing.JComponent#getDefaultLocale
         */
        public ConfigSheetDialog(Frame owner, String title, boolean modal) throws HeadlessException {
            super(owner, title, modal);
        }

        protected void init(){
            setResizable(true);
            setLayout(new BorderLayout());
            setMaximumSize(new Dimension(frameComponent.getFrameWidth() - 50,
                                         frameComponent.getFrameHeight() - 50));

            sheetTabbedPane = new JTabbedPane();
            sheetTabbedPane.setPreferredSize(new Dimension(640, 480));
            add(sheetTabbedPane, BorderLayout.CENTER);

            okJButton = new JButton(getMessage("configDialogOKButton"));
            cancelJButton = new JButton(getMessage("configDialogCancelButton"));
            acceptJButton = new JButton(getMessage("configDialogAcceptButton"));

            Container buttonContainer = new Container();
            buttonContainer.setLayout(new FlowLayout());
            // Activate ok, accept and cancel buttons
            buttonContainer.add(okJButton);
            buttonContainer.add(acceptJButton);
            buttonContainer.add(cancelJButton);
            // set ok, accept and cancel buttons to same width
            int firstWidth = (int) Math.max(okJButton.getPreferredSize().width,
                                          cancelJButton.getPreferredSize().width);
            int maxWidth = (int) Math.max(firstWidth,
                                          acceptJButton.getPreferredSize().width);
            okJButton.setPreferredSize(new Dimension(maxWidth,
                                     (int) okJButton.getPreferredSize().height));
            cancelJButton.setPreferredSize(new Dimension(maxWidth,
                                     (int) cancelJButton.getPreferredSize().height));
            acceptJButton.setPreferredSize(new Dimension(maxWidth,
                                     (int) acceptJButton.getPreferredSize().height));
            add(buttonContainer, BorderLayout.SOUTH);
            initButtonActionListeners();
        }


        private void initButtonActionListeners() {
            //Setting the ActionListeners
            okJButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    okActionPerformed();
                }
            });

            cancelJButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    cancelActionPerformed();
                }
            });

            acceptJButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    acceptActionPerformed();
                }
            });
        }


        public void okActionPerformed(){
            acceptActionPerformed();
            setVisible(false);
        }


        public void cancelActionPerformed(){
            setVisible(false);
        }


        public void acceptActionPerformed(){
            int tabCount = sheetTabbedPane.getTabCount();
            for(int i = 0; i < tabCount; i++){
                ConfigurationSheet sheet = (ConfigurationSheet) sheetTabbedPane.getComponentAt(i);
                if(sheet.isConfigurationChanged()){
                    sheet.acceptConfigurationChange();
                }
            }
        }
    }

}
