package cbrcp.component.statusbar;

import cbrcp.component.statusbar.separator.SeparatorPainter;
import cbrcp.component.statusbar.separator.SeparatorXPLookAndFeelPainter;
import cbrcp.component.statusbar.dragarea.DragAreaDefaultLookAndFeelPainter;
import cbrcp.component.statusbar.dragarea.DragAreaPainter;

import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Component;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.JSeparator;

import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.logging.Logger;


/**
 * This leightweight Swing component builds a commonly known statusbar for
 * applications. You can define certain fields which have an icon and/or a label
 * and/or text content and/or fields (also of a fixed size) which acts as simple
 * spacer between the various fields. You can resize your application window by
 * a mouse drag area in the right corner of the statusbar.
 * <p/>
 * <P>Here is an example for implementing an application which has a
 * <CODE>JStatusBar </CODE> with a field containing an icon plus a label plus
 * text content, two fixed spacer fields and the mouse drag area. </P>
 * <p/>
 * <P> <PRE> public class JStatusBarDemo extends ...</PRE> ...(for example a
 * <CODE>JFrame</CODE>). <P> Create a new instance of the application. </P>
 * <PRE> public JStatusBarDemo() {
 * <p/>
 * setSize(600, 300); getContentPane().setLayout(new BorderLayout());
 * setTitle("JStatusBarDemo"); addWindowListener(new WindowAdapter() { public
 * void windowClosing(java.awt.event.WindowEvent evt) { SystemEntity.exit(0); }
 * });</PRE> Define a list for the fields. <PRE> Collection fieldCollection  =
 * new ArrayList(); </PRE> Define a test icon. <PRE> ImageIcon img = new
 * ImageIcon("./resources/images/VIS.gif");</PRE> Construct a new field with
 * icon, label and content with default font. <PRE> JStatusBarField fileField =
 * new JStatusBarField("Filelabel (in blue with image icon):", img,
 * SwingConstants.LEFT, Color.blue, "C:\\ACertainFile.xml");</PRE> Constructing
 * a dummy field (of an fixed size) as spacer calling the default constructor.
 * <PRE> JStatusBarField dummyField1 = new JStatusBarField(50); ...   </PRE>
 * Another one... <PRE> JStatusBarField dummyField2 = new JStatusBarField(70);
 * ...   </PRE> Adding the field(s) to the Collection in the order from left to
 * right. <PRE> fieldCollection.add(fileField); fieldCollection.add(dummyField1);
 * fieldCollection.add(dummyField2); ...</PRE> Adding a dummy panel to the
 * center of the demo application's <CODE>JFrame</CODE>. <PRE> JPanel dummy =
 * new JPanel(); dummy.setBorder(new BevelBorder(BevelBorder.LOWERED));
 * getContentPane().add(dummy, BorderLayout.CENTER);</PRE> Adding the
 * <CODE>JStatusBar</CODE> to the south of the demo application's
 * <CODE>JFrame</CODE>. <PRE> JStatusBar statusBar = new
 * JStatusBar(fieldCollection); getContentPane().add(statusBar,
 * BorderLayout.SOUTH); </PRE> If you want you can add your custom painted drag
 * area to override the default drag area (e.g. take a look to the XP L&amp;F
 * painter class). <PRE> statusBar.setDragAreaPainter(new
 * DragAreaXPLookAndFeelPainter()); }</PRE> Starting the demo. <PRE> public
 * static void main(String[] args) { new JStatusBarDemo().show(); } } </PRE>
 * Ready!
 *
 * @author <A href="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @author <A HREF="mailto:mig-o@mig-o.de">Migo</A>
 * @version $Revision: 1.3 $, $Date: 2006/01/19 14:35:04 $, last change by: $Author: jens $
 */
public class JStatusBar extends JPanel
implements MouseListener, MouseMotionListener {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(JStatusBar.class.getName());

    /* Holds the width of the <CODE>JStatusBar</CODE>. */
    //private int width;

    /** Holds the height of the <CODE>JStatusBar</CODE>. Default is 18 pixels. */
    private int height = 19;

    /** Gap between statusbar and rest of window. */
    private int gap = 2;

    /**
     * This cursor type is used if this panel's drag bound is entered with the
     * mouse. It is <CODE>Cursor.SE_RESIZE_CURSOR</CODE>.
     */
    private Cursor seResizeCursor = new Cursor(Cursor.SE_RESIZE_CURSOR);

    /**
     * This cursor type is used if this panel's bound left with the mouse. It is
     * <CODE>Cursor.DEFAULT_CURSOR</CODE>.
     */
    private Cursor defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);

    /** Holds the point from which the mouse is dragged first for resizing. */
    private Point dragStartPoint;

    /**
     * Holds the bounds of the parent to resize as a rectangle before a resizing
     * action.
     */
    private Rectangle dragStartRect;

    /** Holds the <CODE>Window</CODE> component containing the <CODE>JStatusBar</CODE>. */
    private Window w;

    /** The custom painter object. */
    private DragAreaPainter dap;

    private JPanel container;

    private DragJPanel dragPanel;

    private SeparatorPainter sep;


    /**
     * Creates a new instance of JStatusBar with a minimum height of 18 pixels.
     * On the left side exists a field panel with the fields in the order from
     * left to right and on the right side there is the area to resize the
     * parent component.
     */
    public JStatusBar() {
        this(null, false);
    }

    /**
     * Creates a new instance of JStatusBar with a minimum height of 18 pixels.
     * On the left side exists a field panel with the fields in the order from
     * left to right and on the right side there is the area to resize the
     * parent component.
     *
     * @param fields The <CODE>Collection</CODE> holding the <CODE>JStatusBarField
     *               </CODE>s.
     */
    public JStatusBar(Collection<Component> fields) {
        this(fields, false);
    }


    public JStatusBar(boolean raisedDragArea) {
        this(new ArrayList<Component>(), new DragAreaDefaultLookAndFeelPainter(raisedDragArea));
    }

    /**
     * Creates a new instance of JStatusBar with a minimum height of 18 pixels
     * and either a raised or etched painting of the drag area. On the left side
     * exists a field panel with the fields in the order from left to right and
     * on the right side there is the area to resize the parent component.
     *
     * @param fields         the <CODE>Collection</CODE> holding the
     *                       <CODE>JStatusBarField </CODE>s
     * @param raisedDragArea indicates if the drag area is painted as raised or
     *                       etched area
     */
    public JStatusBar(Collection<Component> fields, boolean raisedDragArea) {
        this(fields, new DragAreaDefaultLookAndFeelPainter(raisedDragArea));
    }

    public JStatusBar(Collection<Component> fields, DragAreaPainter dap) {
        this(fields, dap, new SeparatorXPLookAndFeelPainter());
    }

    public JStatusBar(DragAreaPainter dap, SeparatorPainter sep) {
        this(new ArrayList<Component>(), dap, sep);
    }

    public JStatusBar(Collection<Component> fields, DragAreaPainter dap, SeparatorPainter sep) {
        container = new JPanel(new BorderLayout(0, 0));
        this.dap = dap;
        this.sep = sep;
        initStatusBar(fields);
    }


    /**
     * Sets a custom painter object for the drag area. The default painting will
     * not be executed if this object is not equal <CODE>null</CODE>.
     *
     * @param painter the custom painter object
     */
    public void setDragAreaPainter(DragAreaPainter painter) {
        dap = painter;
        dragPanel.repaint();
    }


    /**
     * Initializes the layout and components.
     *
     * @param fields The <CODE>Collection</CODE> holding the <CODE>JStatusBarField
     *               </CODE>s.
     */
    private void initStatusBar(Collection<Component> fields) {
        setPreferredSize(new Dimension(this.getPreferredSize().width, height + gap));
        Container fieldsContainer = new Container();
        //setDoubleBuffered(true);

        //Setting Layout for complete StatusBarComponent
        setLayout(new BorderLayout());
        // TODO das muss auch gemakelt werden, wenn man fields nachtr�glich setzt!
        // Es muss eh ein eigener LAyoutmanager geschrieben werden
        fieldsContainer.setLayout(new GridLayout(1, fields.size()));//  new FlowLayout(FlowLayout.LEFT, gap, gap)); //

        if(fields != null){
            for (Iterator<Component> iter = fields.iterator(); iter.hasNext();) {
                Component field =  iter.next();
                Container fieldContainer = new Container();
                fieldContainer.setLayout(new BorderLayout());
                fieldContainer.add(field, BorderLayout.CENTER);
                if (iter.hasNext()) {
                    fieldContainer.add(createSeparator(), BorderLayout.EAST);
                }

                fieldsContainer.add(fieldContainer);
                //Setting the correct height (the height of the statusbar) for every field
                fieldsContainer.setPreferredSize(new Dimension((int) field.getPreferredSize().getWidth(), height));
            }
        }
        dragPanel = new DragJPanel();
        container.add(dragPanel, BorderLayout.EAST);
        //Adding the FieldJPanel to the StatusBarComponent
        container.add(fieldsContainer, BorderLayout.CENTER);

        add(container, BorderLayout.CENTER);


        //Registrating the mouse listeners
        addMouseListener(this);
        addMouseMotionListener(this);
        //w = SwingUtilities.windowForComponent(this);
    }


    /**
     * @return
     */
    private JPanel createSeparator() {
        JPanel separator = null;
        if(sep != null){
            separator = new SeparatorJPanel();
        }else{
            separator = new JPanel(new BorderLayout(2, 1));
            separator.add(new JSeparator(JSeparator.VERTICAL), BorderLayout.WEST);
        }
        //separator.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        return separator;
    }


    //FUNZT NOCH NICHT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! Die event Quelle haut nicht hin
    /*
     * Setter for the height.
     *
     * @param height The value for the new height.
     */
 /*   public void setHeight(int height) {
        setPreferredSize(new Dimension(width, height));
        //new ComponentEvent(this, ComponentEvent.COMPONENT_RESIZED);
        //validate();
        //repaint();
    }  */


    /**
     * Not used.
     */
    public void mouseClicked(MouseEvent e) {
    }


    /**
     * Not used.
     */
    public void mouseEntered(MouseEvent e) {
    }


    /**
     * Not used.
     */
    public void mouseExited(MouseEvent e) {
    }


    /**
     * If mouse is pressed get the first point for dragging.
     *
     * @param e The mouse event invoked when mouse is dragged inside
     *          <CODE>this</CODE>' drag area.
     */
    public void mousePressed(MouseEvent e) {
        Point p = e.getPoint();
        if (p.x > getSize().width - 15) {
            dragStartPoint = p;
            SwingUtilities.convertPointToScreen(p, this);
            w = SwingUtilities.windowForComponent(this);
            dragStartRect = w.getBounds();
        }
    }


    /**
     * If the mouse is released the drag starting point is set to
     * <CODE>null</CODE>.
     *
     * @param	e The mouse event invoked when mouse is released.
     */
    public void mouseReleased(MouseEvent e) {
        dragStartPoint = null;
        // dragging is finished, validate the whole component and repaint it
        // -> supresses flickering of frame content during dragging
        //w = SwingUtilities.windowForComponent(this);
        //w.validate();
        //w.repaint();
        //The whole parent component is validated and repainted. This is done at this
        //moment to supress flickering of frame content during dragging. Espcecially
        //useful due to performance reasons when repainting complex content.
    }


    /**
     * If the mouse is dragged inside the mouse drag area in the right corner of
     * the statusbar, <CODE>this</CODE> and its parent are triggered to resize.
     *
     * @param	e The mouse event invoked when mouse is dragged inside
     * <CODE>this</CODE>' drag area.
     */
    public void mouseDragged(MouseEvent e) {
        //If not in drag area do nothing...
        if (dragStartPoint == null) {
            return;
        }
        //...else resize
        Point p = e.getPoint();
        SwingUtilities.convertPointToScreen(p, this);
        p.x -= dragStartPoint.x;
        p.y -= dragStartPoint.y;

        //w = SwingUtilities.windowForComponent(this);
        if (w != null) {
            w.setSize(dragStartRect.width + p.x, dragStartRect.height + p.y);
            w.validate();
            w.repaint();
        }
    }


    /**
     * Converts the mouse cursor during moving to <CODE>Cursor.SE_RESIZE_CURSOR</CODE>
     * if the drag bound of this panel is entered.
     *
     * @param e The mouse event triggered when moving inside <CODE>this</CODE>'
     *          bounds.
     */
    public void mouseMoved(MouseEvent e) {
        Point p = e.getPoint();
        if (p.x > getSize().width - 15) {
            this.setCursor(seResizeCursor);
        } else {
            this.setCursor(defaultCursor);
        }
    }


    private class DragJPanel extends JPanel {

        //private int width = getWidth();
        //private int height = getHeight();

        public DragJPanel() {
            setPreferredSize(new Dimension(18, 30));
            setMinimumSize(new Dimension(30, 30));
            setMaximumSize(new Dimension(30, 30));
            //setBorder(new BevelBorder(BevelBorder.RAISED));

        }


        /**
         * Paints the component. If the custom drag area painter is
         * <CODE>null</CODE> as default four shadowed lines (etched or raised)
         * are painted from south to east at 45� in the lower right corner to
         * indicate that there is the drag area.
         *
         * @param g The <CODE>Graphic</CODE>s context.
         */
        public void paint(Graphics g) {
            super.paint(g);
            Graphics2D g2 = (Graphics2D) g;
            //width = getWidth();
            //height = getHeight();
            //Rectangle2D rect = new Rectangle2D.Float(width - 18, height- 18, 18, 18);
            //g2.setColor(g2.getBackground());
            //g2.fill(rect);
            dap.paint(g2, getWidth(), getHeight());
        }
    }


    private class SeparatorJPanel extends JPanel {

        //private int width = getWidth();
        //private int height = getHeight();

        public SeparatorJPanel() {
            int width = 7;
            if(sep != null){
                width = sep.getRequiredWidth() + 6;
            }

            setPreferredSize(new Dimension(width, 30));
            setMinimumSize(new Dimension(width, 30));
            setMaximumSize(new Dimension(width, 30));
            //setBorder(new BevelBorder(BevelBorder.RAISED));

        }


        /**
         * Paints the component. If the custom drag area painter is
         * <CODE>null</CODE> as default four shadowed lines (etched or raised)
         * are painted from south to east at 45� in the lower right corner to
         * indicate that there is the drag area.
         *
         * @param g The <CODE>Graphic</CODE>s context.
         */
        public void paint(Graphics g) {
            super.paint(g);
            Graphics2D g2 = (Graphics2D) g;
            //width = getWidth();
            //height = getHeight();
            //Rectangle2D rect = new Rectangle2D.Float(width - 18, height- 18, 18, 18);
            //g2.setColor(g2.getBackground());
            //g2.fill(rect);
            sep.paint(g2, getWidth(), getHeight());
        }
    }

}
