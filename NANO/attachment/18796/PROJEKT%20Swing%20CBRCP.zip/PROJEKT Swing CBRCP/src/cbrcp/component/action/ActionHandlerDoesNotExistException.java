package cbrcp.component.action;


/**
 * Thrown when a particular registered {@link cbrcp.action.ActionHandler} cannot be found
 * in an {@link cbrcp.action.ActionHandlerManager}.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2004/07/08 22:27:24 $, last change by: $Author: jens $
 */
public class ActionHandlerDoesNotExistException
extends Exception{


    /**
     * Constructs a <code>ActionNotFoundException</code> without a detail message.
     */
    public ActionHandlerDoesNotExistException() {
	    super();
    }

    /**
     * Constructs a <code>ActionNotFoundException</code> with a detail message.
     *
     * @param      s   the detail message.
     */
    public ActionHandlerDoesNotExistException(String s) {
	    super(s);
    }


    public static ActionHandlerDoesNotExistException createActionHandlerDoesNotExistException(
            String methodName, String actionHandlerName){
        return new ActionHandlerDoesNotExistException("Exception in " + methodName +
               "(...): ActionHandler name " + actionHandlerName + " does not exist!");
    }

}
