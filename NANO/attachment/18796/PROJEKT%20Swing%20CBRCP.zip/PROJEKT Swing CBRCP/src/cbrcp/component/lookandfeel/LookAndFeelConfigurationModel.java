package cbrcp.component.lookandfeel;

import javax.swing.UIManager;
import javax.swing.LookAndFeel;

import java.util.Vector;


/**
 * dynamicLayout=true
# a hint as to whether or not current look and feel should provide
# window decorations
defaultLookAndFeelDecorated=false
# fully qualified class name of L&F, supported external L&Fs:
#   - com.incors.plaf.kunststoff.KunststoffLookAndFeelProxy
#   - com.jgoodies.looks.plastic.PlasticLookAndFeelProxy
#   - com.jgoodies.looks.plastic.PlasticXPLookAndFeelProxy
#   - com.jgoodies.looks.plastic.Plastic3DLookAndFeelProxy
lookAndFeelClass=com.jgoodies.looks.plastic.PlasticXPLookAndFeelProxy
# fully qualified class name of L&F theme, support for external themes:
#   - com.incors.plaf.kunststoff.themes.KunststoffDesktopTheme
#   - com.incors.plaf.kunststoff.themes.KunststoffNotebookTheme
#   - com.incors.plaf.kunststoff.themes.KunststoffPresentationTheme
#   - com.jgoodies.looks.plastic.theme.BrownSugar
#   - com.jgoodies.looks.plastic.theme.DarkStar
#   - com.jgoodies.looks.plastic.theme.DesertBlue
#   - com.jgoodies.looks.plastic.theme.DesertBluer
#   - com.jgoodies.looks.plastic.theme.DesertGreen
#   - com.jgoodies.looks.plastic.theme.DesertRed
#   - com.jgoodies.looks.plastic.theme.DesertYellow
#   - com.jgoodies.looks.plastic.theme.ExperienceBlue
#   - com.jgoodies.looks.plastic.theme.ExperienceBlueDefaultFont
#   - com.jgoodies.looks.plastic.theme.ExperienceGreen
#   - com.jgoodies.looks.plastic.theme.InvertedColorTheme
#   - com.jgoodies.looks.plastic.theme.Silver
#   - com.jgoodies.looks.plastic.theme.SkyBlue
#   - com.jgoodies.looks.plastic.theme.SkyBluer
#   - com.jgoodies.looks.plastic.theme.SkyBluerTahoma
#   - com.jgoodies.looks.plastic.theme.SkyGreen
#   - com.jgoodies.looks.plastic.theme.SkyKrupp
#   - com.jgoodies.looks.plastic.theme.SkyPink
#   - com.jgoodies.looks.plastic.theme.SkyRed
#   - com.jgoodies.looks.plastic.theme.SkyYellow
lookAndFeelThemeClass=com.jgoodies.looks.plastic.theme.ExperienceBlue.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class LookAndFeelConfigurationModel {

    private Vector<AbstractLookAndFeelProxy> lookAndFeelProxies;


    LookAndFeelConfigurationModel() {
        //PlasticLookAndFeelProxy plastic = new PlasticLookAndFeelProxy();
        Plastic3DLookAndFeelProxy plastic3D = new Plastic3DLookAndFeelProxy();
        PlasticXPLookAndFeelProxy plasticXP = new PlasticXPLookAndFeelProxy();
        KunststoffLookAndFeelProxy kunststoff = new KunststoffLookAndFeelProxy();
        // TODO add more
        MotifLookAndFeelProxy motif = new MotifLookAndFeelProxy();
        SystemLookAndFeelProxy system = new SystemLookAndFeelProxy();
        CrossPlatformLookAndFeelProxy crossPlatfrom = new CrossPlatformLookAndFeelProxy();

        //SkinLookAndFeelProxy skin = new SkinLookAndFeelProxy();

        lookAndFeelProxies = new Vector<AbstractLookAndFeelProxy>();
        //addProxy(plastic);
        addProxy(plastic3D);
        addProxy(plasticXP);
        addProxy(kunststoff);
        //addProxy(skin);
        addProxy(motif);
        addProxy(system);
        addProxy(crossPlatfrom);
    }


    public final Vector<AbstractLookAndFeelProxy> getLookAndFeelProxies() {
        return lookAndFeelProxies;
    }

    public final ThemeProxy getLookAndFeelThemeProxy(String lookAndFeelThemeClassName) {
        for(int i = 0; i < lookAndFeelProxies.size(); i++ ){
            AbstractLookAndFeelProxy proxy = lookAndFeelProxies.elementAt(i);
            Vector<ThemeProxy> themeProxies = proxy.getThemeProxies();
            if(themeProxies != null){
                for(ThemeProxy themeProxy : themeProxies){
                    if(themeProxy.getLookAndFeelThemeClassName().equals(lookAndFeelThemeClassName)){
                        return themeProxy;
                    }
                }
            }
        }
        return null;
    }

    public final String[] getLookAndFeelThemeNames(String lookAndFeelClassName) {
        for(int i = 0; i < lookAndFeelProxies.size(); i++ ){
            AbstractLookAndFeelProxy proxy = lookAndFeelProxies.elementAt(i);
            if(proxy.getLookAndFeelClassName().equals(lookAndFeelClassName)){
                return proxy.getLookAndFeelThemeNames();
            }
        }
        return new String[]{};
    }

    protected final void addProxy(AbstractLookAndFeelProxy proxy){
        if(proxy != null){
            lookAndFeelProxies.add(proxy);
        }
    }


    public final String[] getLookAndFeelNames(){
        AbstractLookAndFeelProxy[] landfs = lookAndFeelProxies.toArray(new AbstractLookAndFeelProxy[0]);
        String[] landfStrings = new String[landfs.length];
        for(int i = 0; i < landfs.length; i++){
            landfStrings[i] = landfs[i].getLookAndFeelName();
        }
        return landfStrings;
    }



    public final String[] getLookAndFeelClassNames(){
        AbstractLookAndFeelProxy[] landfs = lookAndFeelProxies.toArray(new AbstractLookAndFeelProxy[0]);
        String[] landfStrings = new String[landfs.length];
        for(int i = 0; i < landfs.length; i++){
            landfStrings[i] = landfs[i].getLookAndFeelClassName();
        }
        return landfStrings;
    }


    public AbstractLookAndFeelProxy getLookAndFeelProxy(String lookAndFeelClassName){
        for(AbstractLookAndFeelProxy proxy : lookAndFeelProxies){
            if(proxy.getLookAndFeelClassName().equals(lookAndFeelClassName)){
                return proxy;
            }
        }
        return null;
    }

    public final String[] getLookAndFeelThemes(String lookAndFeelClassName){
        AbstractLookAndFeelProxy landf = getLookAndFeelProxy(lookAndFeelClassName);
        if(landf == null){
            return new String[]{};
        }else{
            return landf.getLookAndFeelThemeNames();
        }
    }




    static LookAndFeel getActualLookAndFeel(){
        return UIManager.getLookAndFeel();
    }

    static Class getActualLookAndFeelClass(){
        return getActualLookAndFeel().getClass();
    }

    static String getActualLookAndFeelName(){
        return getActualLookAndFeel().getName();
    }

    static String getActualLookAndFeelClassName(){
        return getActualLookAndFeelClass().getName();
    }

    static String getSystemLookAndFeelClassName(){
        return UIManager.getSystemLookAndFeelClassName();
    }

    static String getCrossPlatformLookAndFeelClassName(){
        return UIManager.getCrossPlatformLookAndFeelClassName();
    }

    static String getMotifLookAndFeelClassName(){
        return "com.sun.java.swing.plaf.motif.MotifLookAndFeel";
    }
}
