package cbrcp.component.action;


/**
 * Thrown when a particular registered <CODE>ActionHandler</CODE> name is already
 * registered in a cache.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2004/07/08 22:27:24 $, last change by: $Author: jens $
 */
public class DuplicateActionHandlerNameException
extends Exception{


    /**
     * Constructs a <code>ActionNotFoundException</code> without a detail message.
     */
    public DuplicateActionHandlerNameException() {
	    super();
    }

    /**
     * Constructs a <code>ActionNotFoundException</code> with a detail message.
     *
     * @param      s   the detail message.
     */
    public DuplicateActionHandlerNameException(String s) {
	    super(s);
    }

    public static DuplicateActionHandlerNameException createDuplicateActionHandlerNameException(
            String methodName, String actionHandlerName){
        return new DuplicateActionHandlerNameException("Exception in " + methodName +
               "(...): ActionHandler name " + actionHandlerName + " does not exist!");
    }
}
