package cbrcp.component.frame;

import javax.swing.Icon;
import javax.swing.JFrame;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.Dimension;

import org.picocontainer.PicoContainer;

import cbrcp.action.DuplicateActionHandlerNameException;
import cbrcp.action.ActionHandler;
import cbrcp.action.ActionHandlerDoesNotExistException;

/**
 * The component interface for the frame component.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.20 $, $Date: 2004/09/18 16:03:42 $, last change by: $Author$
 */
public interface FrameComponent {

    /** Role name for the component. */
    public static final String ROLE = FrameComponent.class.getName();


    public static final int NO_TOOLBAR_STYLE = 0;

    public static final int SPACE_TOOLBAR_STYLE = 1;

    public static final int JSEPARATOR_TOOLBAR_STYLE = 2;


    /*
     * Passthrough for setting the parent container of this subcontainer.
     *
     * @param parent    the parent container
     */
    //public void setParent(PicoContainer parent);

    public int handleOptionDialog(Object message, String title, int optionType,
                                  int messageType, Icon icon, Object[] options,
                                  Object initialValue);

    public JFrame getFrame();

    public int getFrameWidth();

    public int getFrameHeight();

    public Rectangle getBounds();

    public Dimension getDimension();

    public void setFrameTitle(String title);

    public void supplementFrameTitle(String choosableSection, String fileSection);

    public void addActionHandler(ActionHandler handler)
        throws DuplicateActionHandlerNameException;

    public void reactivateActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException;

    public void suspendActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException;

    public void removeActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException;

    //public void setFullFilePathInWindowTitleOption(boolean fullFilePathInWindowTitleOption);

    public void addContentComponent(Component c);

    public void removeContentComponent();

    public boolean frameHasContent();

    /**
     *
     * @return
     * @deprecated
     */
    public PicoContainer getContainer();
}
