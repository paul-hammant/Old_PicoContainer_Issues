package cbrcp.component.toolbar;

import javax.swing.JPanel;
import javax.swing.JToolBar;

import java.util.Vector;
import java.util.HashMap;
import java.util.Enumeration;
import java.util.logging.Logger;
import java.awt.FlowLayout;


/**
 *
 * @author  jens
 */
class JKeyToIndexToolBar
extends JPanel{

    /** Just for logging purposes. */
    private final static Logger LOGGER = Logger.getLogger(JKeyToIndexToolBar.class.getName());

    private Vector items;

    private HashMap cache;

    private int separatorStyle;


    public JKeyToIndexToolBar(){
        this(ToolBarComponent.JSEPARATOR_VERTICAL_TOOLBAR_STYLE);
    }


    /** Creates a new instance of JKeyToIndexToolBar. */
    public JKeyToIndexToolBar(int verticalSeparatorStyle) {
        setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
        separatorStyle = verticalSeparatorStyle;
        items = new Vector();
        cache = new HashMap();
    }


    public void addTool(String nameKey, int desiredIndex, boolean indexReserved,
                         JToolBar tool){

        JComponentAndSeparatorContainer container = null;
        if(separatorStyle == ToolBarComponent.JSEPARATOR_VERTICAL_TOOLBAR_STYLE){
            LOGGER.finest("Style == JSEPARATOR_VERTICAL_TOOLBAR_STYLE");
            container = new JComponentAndSeparatorContainer(tool,
                                     ToolBarComponent.JSEPARATOR_VERTICAL_TOOLBAR_STYLE);
        }else{
            LOGGER.finest("Style == SPACE_VERTICAL_TOOLBAR_STYLE");
            container = new JComponentAndSeparatorContainer(tool,
                                          ToolBarComponent.SPACE_VERTICAL_TOOLBAR_STYLE);
        }
        AttributedTool aTool = new AttributedTool(nameKey, desiredIndex,
                                                  indexReserved, container);
        int assignedIndex = getNextPossibleIndex(desiredIndex, indexReserved);
        LOGGER.finest("size == " + items.size());
        LOGGER.finest("assignedIndex = " + assignedIndex + " for nameKey = " + nameKey);
        items.insertElementAt(aTool, assignedIndex);

        refresh();
    }


    private void cache(int index){
        try{
            AttributedTool aTool = (AttributedTool) items.elementAt(index);
            items.remove(index);
            cache.put(aTool.getNameKey(), aTool);
        }catch(ArrayIndexOutOfBoundsException e){
            LOGGER.severe("ArrayIndexOutOfBoundsException in cache(...): " + e.getMessage());
            e.printStackTrace();
        }
    }


    public int suspendTool(String nameKey){
        int index = key2Index(nameKey);
        if(index > -1){
            remove(index);
            cache(index);
            refresh();
        }else{
            return -1;
        }
        return 1;
    }


    public int reactivateTool(String nameKey){
        if(cache.get(nameKey) != null){
            AttributedTool aTool = (AttributedTool) cache.remove(nameKey);
            addTool(aTool.getNameKey(), aTool.getDesiredIndex(), aTool.isIndexReserved(),
                (JToolBar)((JComponentAndSeparatorContainer)aTool.getTool()).getComp());
        }else{
            return -1;
        }
        return 1;
    }


    public int removeTool(String nameKey){
        LOGGER.finest("REMOVING TOOL WITH KEYNAME = " + nameKey);
        int index = key2Index(nameKey);
        LOGGER.finest("INDEX TO REMOVE = " + index);
        if(index > -1){
            remove(index);
            items.remove(index);
            refresh();
            LOGGER.finest("INDEX REMOVED = " + index);
            if(cache.get(nameKey) != null){
                cache.remove(nameKey);
            }
        }else{
            return -1;
        }
        return 1;
    }


    private int key2Index(String nameKey){
        items.trimToSize();
        for(int i = 0; i < items.size(); i++){
            AttributedTool aTool = (AttributedTool) items.elementAt(i);
            if(aTool.getNameKey().equals(nameKey)){
                return i;
            }
        }
        return -1;
    }


    private int relative2NormalIndex(int relative){
        if(relative < 0){
            int size = items.size();
            if(size + relative <= 0){
                return 0;
            }else{
                return size + relative;
            }
        }
        return relative;
    }


    private int getNextPossibleIndex(int desiredIndex, boolean indexReserved){
        try{
        AttributedTool tool = null;
        int size = items.size();
        int toolIndex;
        boolean toolReserved;
            if(desiredIndex > size){ // normal index (> 0) in any case, size >= 1
                LOGGER.finest("desiredIndex = " + desiredIndex + " > size = " + size);
                tool = (AttributedTool) items.elementAt(size - 1);
                toolIndex = tool.getDesiredIndex();
                if(toolIndex < desiredIndex){
                    return size;
                }else{
                    return size - 1;
                }
            }
            if(desiredIndex <= size){ // normal index (>= 0) or relative, size >= 1
                LOGGER.finest("desiredIndex = " + desiredIndex + " <= size = " + size);
                if(desiredIndex >= 0){ // normal index
                    LOGGER.finest("desiredIndex = " + desiredIndex + " >= 0");
                    if(size > 0){
                        tool = (AttributedTool) items.elementAt(desiredIndex);
                        toolIndex = tool.getDesiredIndex();
                        LOGGER.finest("toolIndex = " + toolIndex);
                    }else{
                        return 0;
                    }
                    if(toolIndex < desiredIndex){  // 1st index < 2nd index
                        LOGGER.finest("toolIndex = " + toolIndex + " < desiredIndex = " + desiredIndex);
                        if(toolIndex > 0){ // prefer an index>0 to an index<0
                            return desiredIndex + 1;
                        }else{
                            return desiredIndex;
                        }
                    }else{
                        if(toolIndex == desiredIndex){
                            toolReserved = tool.isIndexReserved();
                            if(toolReserved){
                                LOGGER.finest("toolReserved = " + toolReserved + ", returning desiredIndex = " + desiredIndex + " + 1");
                                return desiredIndex + 1;  // first one reserved
                            }
                            if(indexReserved){
                                LOGGER.finest("indexReserved = " + indexReserved);
                                return desiredIndex;      // second one reserved
                            }
                            LOGGER.finest("none reserved!");
                            return desiredIndex + 1;      // none reserved
                        }else{
                            LOGGER.finest("toolIndex = " + toolIndex + " > desiredIndex = " + desiredIndex);
                            return desiredIndex;   // 1st index > 2nd index
                        }
                    }
                }else{ // relative index ( < 0)
                    LOGGER.finest("desiredIndex < 0 (relative)");
                    desiredIndex = relative2NormalIndex(desiredIndex);
                    return getNextPossibleIndex(desiredIndex, indexReserved);
                }
            }
            LOGGER.finest("LAST!!!");
        }catch(ArrayIndexOutOfBoundsException aioobe){
            LOGGER.severe("ArrayIndexOutOfBoundsException in getNextPossibleIndex(...)");
            aioobe.printStackTrace();
        }
        return 0;
    }


    private void refresh(){
        LOGGER.finest("IN refresh()!");
        removeAll();
        int indexCounter = 0;
        for(Enumeration e = items.elements(); e.hasMoreElements(); indexCounter++){
            AttributedTool aTool = ((AttributedTool) e.nextElement());
            JComponentAndSeparatorContainer tool = (JComponentAndSeparatorContainer) aTool.getTool();
            LOGGER.finest(indexCounter + " == " + (items.size() - 1) + "= " + (indexCounter == items.size() - 1));
            if(indexCounter == items.size() - 1){
                tool.removeSeparator();//;setSeparator(false);
                LOGGER.finest("Removing SEPARATOR DUE TO LAST INDEX!");
            }else{
                if(separatorStyle == ToolBarComponent.JSEPARATOR_VERTICAL_TOOLBAR_STYLE){
                    LOGGER.finest("Adding SEPARATOR DUE TO not LAST INDEX!");
                    tool.addSeparator();//;setSeparator(true);
                }
            }
            LOGGER.finest("INSERTING MENU WITH name = " + aTool.getNameKey());
            add(tool);
        }
        validate();
        repaint();
    }

}
