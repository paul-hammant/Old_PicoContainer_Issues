package cbrcp.component.lookandfeel;

/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version @version $Revision$, $Date$, last change by: $Author$
 */
public interface LookAndFeelManagerComponent {

    /** Role name for the component. */
    public static final String ROLE = LookAndFeelManagerComponent.class.getName();

}
