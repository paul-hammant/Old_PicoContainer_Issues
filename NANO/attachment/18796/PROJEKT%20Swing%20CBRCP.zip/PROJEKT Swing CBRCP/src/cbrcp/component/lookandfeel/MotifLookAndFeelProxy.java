package cbrcp.component.lookandfeel;

/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class MotifLookAndFeelProxy extends AbstractLookAndFeelProxy {


    public MotifLookAndFeelProxy() {
        super(LookAndFeelConfigurationModel.getMotifLookAndFeelClassName());
    }
}
