package cbrcp.component.frame;

import javax.swing.Icon;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;

import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Component;
import java.awt.Container;
import java.awt.Rectangle;
import java.io.File;
import java.util.logging.Logger;

import org.picocontainer.PicoContainer;
import org.picocontainer.MutablePicoContainer;

import cbrcp.component.menubar.MenuBarComponent;
import cbrcp.component.toolbar.ToolBarComponent;
import cbrcp.component.statusbar.StatusBarComponent;
import cbrcp.component.CBRCPAbstractComponentWithConfigAndNLS;
import cbrcp.component.action.ActionHandlerManagerComponent;
import cbrcp.component.frame.action.FileActionHandler;
import cbrcp.action.ActionHandler;
import cbrcp.action.DuplicateActionHandlerNameException;
import cbrcp.action.ActionHandlerDoesNotExistException;
import cbrcp.util.io.ImageUtil;
import cbrcp.util.color.ColorUtil;
import cbrcp.util.PrimitiveWrapUtil;


/**
 *
 * This CBRCP GUI component manages the {@link JFrame} and the embedded CBRCP components
 * {@link MenuBarComponent},{@link ToolBarComponent} and {@link StatusBarComponent}.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class FrameComponentImpl extends CBRCPAbstractComponentWithConfigAndNLS
implements FrameComponent {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(FrameComponentImpl.class.getName());

    private JFrame frame;

    /** Holds the width of the main <CODE>JFrame</CODE>. */
    private int frameWidth;

    /** Holds the height of the main <CODE>JFrame</CODE>. */
    private int frameHeight;

    /** Holds the first part of the window title. */
    private String title = "";

    private Container contentContainer;

    private JPanel emptyPanel;

    private boolean fullFilePathInWindowTitleOption = true;

    private String choosableSection;

    private String fileSection;

    private Component contentCache;

    private FrameActionHandlerManager actionHandlerManager;

    private FrameContainer container;

    private static final String NLS_PATH = "cbrcp/component/frame/nls/frame-NLS";


    private ActionHandlerManagerComponent actionHandlerMangerComponent;

    /**
     * @param menuBarComponent
     * @param toolBarComponent
     * @param statusBarComponent
     */
    public FrameComponentImpl(MenuBarComponent menuBarComponent,
                              ToolBarComponent toolBarComponent,
                              StatusBarComponent statusBarComponent,
                              ActionHandlerManagerComponent actionHandlerMangerComponent,
                              String componentConfigFile){
        super(componentConfigFile, NLS_PATH);
        this.actionHandlerMangerComponent = actionHandlerMangerComponent;
        initSwingComponents();
    /*    actionHandlerManager = new FrameActionHandlerManager(
                this, menuBarComponent, toolBarComponent);   */

        addMenuBar(menuBarComponent);
        addToolBar(toolBarComponent);
        addStatusBar(statusBarComponent);



        if(Boolean.parseBoolean(getProperty("welcomeWindow"))){
            initWelcomeWindow();
        }
    }


    /**
     *
     * @param parent
     * @deprecated
     */
    public FrameComponentImpl(MutablePicoContainer parent, ActionHandlerManagerComponent actionHandlerMangerComponent, String componentConfigFile){
        super(componentConfigFile, NLS_PATH);
        this.actionHandlerMangerComponent = actionHandlerMangerComponent;
        initSwingComponents();

        if(parent != null){
            // container init must be done here because of race conditions with
            // ActionHandler registrations from other components
            container = new FrameContainer(parent);
            parent.registerComponentInstance(container);

          //  actionHandlerManager = new FrameActionHandlerManager(this);

            addToolBar();
            addMenuBar();
            addStatusBar();
            //container.start();
        }

        if(Boolean.parseBoolean(getProperty("welcomeWindow"))){
            initWelcomeWindow();
        }
    }


    /**
     * Inits all swing components used by {@link FrameComponentImpl#frame}.
     */
    private void initSwingComponents(){
        // dimension on screen
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int maxFrameWidth = (int) (screen.getWidth());
        int maxFrameHeight = (int) (screen.getHeight());
        int frameWidth = PrimitiveWrapUtil.parseInt(getProperty("frameWidth"));
        int frameHeight = PrimitiveWrapUtil.parseInt(getProperty("frameHeight"));
        if(frameWidth < 0 || frameWidth > maxFrameWidth){
            frameWidth = maxFrameWidth;
        }
        if(frameHeight < 0 || frameHeight > maxFrameHeight){
            frameHeight = maxFrameHeight;
        }

        boolean frameShowCentered = Boolean.parseBoolean(getProperty("frameShowCentered"));
        int x = PrimitiveWrapUtil.parseInt(getProperty("frameX"));
        int y = PrimitiveWrapUtil.parseInt(getProperty("frameY"));

        if(frameShowCentered){
            x = (maxFrameWidth - frameWidth) / 2;
            y = (maxFrameHeight - frameHeight) / 2;
        }


        // create panel for empty frame with no content
        emptyPanel = new JPanel();
       // emptyPanel.setBackground(Color.GRAY);
       // emptyPanel.setBorder(new BevelBorder(BevelBorder.RAISED));
        emptyPanel.setBorder(new LineBorder(Color.GRAY));
        emptyPanel.setToolTipText(getProperty("emptyPanelToolTipText"));

        // create container for content
        contentContainer = new Container();
        contentContainer.setPreferredSize(new Dimension(frameWidth, frameHeight));
        contentContainer.setLayout(new BorderLayout());
        //contentContainer.setBorder(new LineBorder(Color.GRAY));//0, 0, 0, 0));
        contentContainer.add(emptyPanel, BorderLayout.CENTER);

        // create main frame
        frame = new JFrame(getProperty("frameTitle"));
        frame.setMaximizedBounds(new Rectangle(0, 0, maxFrameWidth, maxFrameHeight));
        // set icon
        frame.setIconImage(ImageUtil.getImageSystemResource(getProperty("frameIcon")));
        frame.setSize(frameWidth, frameHeight);
        frame.setPreferredSize(new Dimension(frameWidth, frameHeight));
        frame.setBounds(x, y, frameWidth, frameHeight);
        frame.toBack();
        frame.add(contentContainer, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                exitCBRCP();
            }
        });
        JOptionPane.setRootFrame(frame);
    }


    /**
     * Exits CBRCP. Not part of the component interface {@link FrameComponent},
     * use only inside classes of package {@link cbrcp.component.frame}!
     */
    public void exitCBRCP(){
        int select = JOptionPane.showConfirmDialog(frame, getMessage("exitDialogMessage"),
                getMessage("exitDialogName"), JOptionPane.YES_NO_OPTION);
        if(select == JOptionPane.YES_OPTION){
            if(container != null){
                PicoContainer rootContainer = container.getParent();
                try{
                    rootContainer.dispose();
                }catch(UnsupportedOperationException uoe){
                    LOGGER.severe("UnsupportedOperationException: " + uoe.getMessage());
                    System.exit(1);
                }
            }else{
                System.exit(0);
            }
        }else{
            frame.setVisible(true);
        }
    }


    private void initWelcomeWindow(){
        WelcomeWindow welcome = new WelcomeWindow(frame,
                getProperty("welcomeWindowImage"));
        //welcome.setImage(properties.getProperty("welcomeWindowImage"));
        welcome.setBorderColor(ColorUtil.parseColorStr(
                getProperty("welcomeWindowBorderColor")));
        welcome.setTextColor(ColorUtil.parseColorStr(
                getProperty("welcomeWindowTextColor")));
        welcome.setTextTop(getProperty("welcomeWindowTextTop"));
        welcome.setTextBottom(getProperty("welcomeWindowTopTextBottom"));
        welcome.setTextCopyright(getProperty("welcomeWindowCopyright"));
        welcome.showWelcomeWindow(PrimitiveWrapUtil.parseInt(
                getProperty("welcomeWindowDuration")));
    }


    /**
     * Component lifecycle method: starts this component. Sets up all FrameComponent
     * subcomponents and add them to the frame. This method is called from the
     * super container's <CODE>start()</CODE> method.
     */
    public void start(){
        super.start();

        FileActionHandler fileActionHandler = new FileActionHandler(this);
        try{
            actionHandlerMangerComponent.addActionHandler(fileActionHandler);
        }catch(DuplicateActionHandlerNameException e){

        }

        if(container != null){
            container.start();
        }
        frame.pack();
        frame.setVisible(true);
        frame.toFront();
        //welcome.toFront();
      //  config.addConfigComponentPropertyChangeListener(this);
    }


    /**
     * Component lifecycle method: stops this component.
     */
    public void stop(){
        super.stop();
        frame.setVisible(false);
    }


    /**
     * Component lifecycle method: disposes this component.
     */
    public void dispose(){
        super.dispose();
        stop();
        frame.dispose();
    }


    public PicoContainer getContainer() {
        return container;
    }


    public void addActionHandler(ActionHandler handler){
        try{
            actionHandlerManager.addActionHandler(handler);
        }catch(DuplicateActionHandlerNameException dahe){}
    }


    public void reactivateActionHandler(String actionHandlerName){
        try{
            actionHandlerManager.reactivateActionHandler(actionHandlerName);
        }catch(ActionHandlerDoesNotExistException ahnee){}
    }


    public void suspendActionHandler(String actionHandlerName){
        try{
            actionHandlerManager.suspendActionHandler(actionHandlerName);
        }catch(ActionHandlerDoesNotExistException ahnee){}
    }


    public void removeActionHandler(String actionHandlerName){
        try{
            actionHandlerManager.removeActionHandler(actionHandlerName);
        }catch(ActionHandlerDoesNotExistException ahnee){}
    }


    private void addToolBar(ToolBarComponent toolBarComponent){
        Component toolBars = toolBarComponent.initToolBar();
        frame.add(toolBars, BorderLayout.NORTH);
    }


    private void addToolBar(){
        ToolBarComponent toolBarComponent = (ToolBarComponent) container.getComponentInstance(ToolBarComponent.ROLE);
        addToolBar(toolBarComponent);
    }


    private void addMenuBar(){
        MenuBarComponent menuBar = (MenuBarComponent) container.getComponentInstance(MenuBarComponent.ROLE);
        addMenuBar(menuBar);
    }

    private void addMenuBar(MenuBarComponent menuBar){
        JMenuBar bar = menuBar.getMenuBar();
        frame.setJMenuBar(bar);
    }


    private void addStatusBar(){
        StatusBarComponent statusBar = (StatusBarComponent) container.getComponentInstance(StatusBarComponent.ROLE);
        addStatusBar(statusBar);
    }

    private void addStatusBar(StatusBarComponent statusBar){
        //List for the fields
     //   Collection fieldCollection = new ArrayList();
        // TODO im FrameComponent M�glickeit beiten StatusBarFelder hinzuzuf�gen!
/*        ImageIcon img = new ImageIcon("./resources/images/VIS.gif");

        //Adding the field(s) to the Collection in the order from left to right
        fieldCollection.add(statusBar.createStatusBarField("", img, SwingConstants.LEFT,
                                                           Color.blue, "   "));
        fieldCollection.add(statusBar.createStatusBarField(50));
        fieldCollection.add(statusBar.createStatusBarField(50));
        fieldCollection.add(statusBar.createStatusBarField(150)); */

        Component c = statusBar.initStatusBar();
        //statusBar.setSize(10, this.getWidth());
    //    statusBar.setDragAreaLAndF(StatusBarComponent.DRAG_AREA_XP_L_AND_F);
        //Adding the JStatusBar to the south of the JFrame
        frame.add(c, BorderLayout.SOUTH);
    }


    public int handleOptionDialog(Object message, String title, int optionType,
                                  int messageType, Icon icon, Object[] options,
                                  Object initialValue){
        return JOptionPane.showOptionDialog(frame, message, title, optionType,
                                            messageType, icon, options, initialValue);
    }





    /**
     * Setter for bound property fullFilePathInWindowTitleOption.
     *
     * @param   fullFilePathInWindowTitleOption   new value of property
     *                                      fullFilePathInWindowTitleOption
     */
    public void setFullFilePathInWindowTitleOption(boolean fullFilePathInWindowTitleOption) {
        LOGGER.finest("IN setFullFilePathInWindowTitle(Boolean fullFilePathInWindowTitle)");
        this.fullFilePathInWindowTitleOption = fullFilePathInWindowTitleOption;
        supplementFrameTitle(choosableSection, fileSection);
    }


    /*
     * Invoked when the <CODE>Config</CODE> of the listener has changed a property.
     *
     * @param e a <CODE>configComponentMessageEvent</CODE> event
     */
/*    public void propertyChange(ConfigComponentPropertyChangeEvent e){
        LOGGER.finest("IN propertyChange(...)");
        int type = e.getPropertyType();
        switch(type){
            case Config.FULL_FILEPATH_IN_WINDOW_TITLE:
                this.fullFilePathInWindowTitleOption = ((Boolean)e.getChangedPropertyValue()).booleanValue();
                supplementFrameTitle(choosableSection, fileSection);
                break;
        }
    }      */



    public void supplementFrameTitle(String choosableSection, String fileSection){
        this.choosableSection = choosableSection;
        this.fileSection = fileSection;
        StringBuffer titleWithFilePathName = new StringBuffer(title);
        //String graphClass = dispatcher.getActiveType();
        //String pathName = dispatcher.getActiveFile();
        if(this.fileSection != null){// a file is opened
            titleWithFilePathName.append(" - ");
            titleWithFilePathName.append(this.choosableSection);
            //titleWithFilePathName.append(": ");
            //titleWithFilePathName.append(graphName);
            titleWithFilePathName.append(" [");
            if(fullFilePathInWindowTitleOption){
                titleWithFilePathName.append(this.fileSection);
            }else{
                titleWithFilePathName.append(new File(this.fileSection).getName());
                LOGGER.finest("FileName: " + new File(this.fileSection).getName());
            }
            titleWithFilePathName.append("]");
        }
        frame.setTitle(titleWithFilePathName.toString());
    }


    public JFrame getFrame(){
        return frame;
    }


    /**
     * Getter for property frameHeight.
     *
     * @return value of property frameHeight
     */
    public int getFrameHeight() {
        return frameHeight;
    }


    /**
     * Setter for property frameHeight.
     *
     * @param frameHeight new value of property frameHeight
     */
    public void setFrameHeight(int frameHeight) {
        this.frameHeight = frameHeight;
        frame.setSize(frameWidth, frameHeight);
        frame.validate();
    }


    /**
     * Getter for property frameWidth.
     *
     * @return value of property frameWidth
     */
    public int getFrameWidth() {
        return frameWidth;
    }


    /**
     * Setter for property frameWidth.
     *
     * @param frameWidth new value of property frameWidth
     */
    public void setFrameWidth(int frameWidth) {
        this.frameWidth = frameWidth;
        frame.setSize(frameWidth, frameHeight);
        frame.validate();
    }


    /**
     * Sets a application title string in the title of the <CODE>JFrame</CODE>.
     *
     * @param title the title of the application
     */
    public void setFrameTitle(String title){
        this.title = title;
        frame.setTitle(title);
    }


    public void addContentComponent(Component c){
        LOGGER.finest("ADDING CONTENT!!!");
        contentCache = c;
        contentContainer.remove(emptyPanel);
        contentContainer.add(contentCache, BorderLayout.CENTER);
        frame.validate();
        frame.repaint();
    }


    public void removeContentComponent(){
        LOGGER.finest("REMOVING CONTENT!!!");
        if(frameHasContent()){
            contentContainer.remove(contentCache);
            contentContainer.add(emptyPanel, BorderLayout.CENTER);
            frame.validate();
            frame.repaint();
        }
    }


    public boolean frameHasContent(){
        // TODO muss hier nicht true sein, wenn contentContainer contentCache beinhaltet?
        //LOGGER.finest("frameHasContent() = " + !(frame.getContentPane().getComponent(0).equals(emptyPanel)));
        Component[] comps = contentContainer.getComponents();
        for(int i = 0; i < comps.length; i++){
            if(comps[i].equals(emptyPanel)){
                return false;
            }
        }
        return true;//!(contentContainer.getComponent(0).equals(emptyPanel));
    }

    public Rectangle getBounds(){
        return frame.getBounds();
    }

    public Dimension getDimension(){
        return frame.getSize();
    }
}
