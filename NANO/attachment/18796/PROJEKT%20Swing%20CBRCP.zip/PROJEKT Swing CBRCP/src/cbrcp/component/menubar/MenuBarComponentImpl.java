package cbrcp.component.menubar;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.border.EmptyBorder;
import java.awt.Insets;

import java.util.logging.Logger;

import cbrcp.component.CBRCPAbstractComponentWithOnlyConfigSupport;


/**
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.11 $, $Date: 2004/10/27 17:13:01 $, last change by: $Author$
 */
public class MenuBarComponentImpl extends CBRCPAbstractComponentWithOnlyConfigSupport
implements MenuBarComponent {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(MenuBarComponentImpl.class.getName());

    private JKeyToIndexMenuBar menuBar;


    public MenuBarComponentImpl(String componentConfigFile){
        super(componentConfigFile);
        menuBar = new JKeyToIndexMenuBar();
        menuBar.setBorder(new EmptyBorder(new Insets(0, 0, 0, 0)));
    }


    public void addMenu(String nameKey, int desiredIndex, boolean indexReserved,
                        JMenu menu){
        menuBar.addMenu(nameKey, desiredIndex, indexReserved, menu);
        LOGGER.finest("adding MenuBarComponent in MBI = " + nameKey + ", desiredIndex = " + desiredIndex);
    }


    public void reactivateMenu(String nameKey){
        menuBar.reactivateMenu(nameKey);
    }


    public void suspendMenu(String nameKey){
        menuBar.suspendMenu(nameKey);
    }


    public void removeMenu(String nameKey){
        menuBar.removeMenu(nameKey);
    }


    public JMenuBar getMenuBar() {
        return menuBar;
    }

}
