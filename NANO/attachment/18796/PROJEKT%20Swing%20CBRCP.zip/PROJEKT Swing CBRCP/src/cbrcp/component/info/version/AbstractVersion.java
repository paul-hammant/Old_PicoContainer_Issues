package cbrcp.component.info.version;

import java.util.StringTokenizer;
import java.util.logging.Logger;


/**
 * This abstract class wraps a version string for an object. You can pass a String of
 * depending on the format of the required version.
 * This String has is parsed and checked for errors, if no errors occurs the version
 * number is extracted and saved in this object else a
 * {@link cbrcp.component.info.version.VersionNumberFormatException} is thrown.
 * <P>
 * You will receive a version {@link String} with {@link #getVersionNumber()}.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public abstract class AbstractVersion
implements Version {

    /** Just for logging purposes. */
    private final static Logger LOGGER = Logger.getLogger(AbstractVersion.class.getName());

    /** The real version value. */
    protected String version = null;

    /** The class signed with this version. */
    protected Class owner;

    /**
     * Constructs a version object.
     *
     * @param version the version value
     */
    public AbstractVersion(String version){
        this(version, null);
    }

    /**
     * Copy constructor.
     *
     * @param version the version to copy
     */
    public AbstractVersion(Version version){
        this(version.getVersionNumber(), version.getOwner());
    }

    /**
     * Constructs a version object.
     *
     * @param version the version value
     * @param owner class signed with this version
     */
    public AbstractVersion(String version, Class owner){
        try{
            //LOGGER.info("Version before checking = " + version);
            this.version = checkVersionString(version);
        }catch(VersionNumberFormatException vnfe){
            LOGGER.severe("VersionNumberFormatException: " + vnfe.getMessage());
            vnfe.printStackTrace();
        }
        //LOGGER.info("Version after checking = " + this.version);
        this.owner = owner;
        //LOGGER.info("Version owner = " + this.owner);
    }


    /**
     * Checks if the passed String is a valid version value.
     * Override this method to provide your own specific checking algorithm.
     *
     * @return the checked string
     * @throws VersionNumberFormatException thrown if the format is not a valid
     *         version number
     */
    protected abstract String checkVersionString(String version)
            throws VersionNumberFormatException;


    /**
     * Checks if this <CODE>Version</CODE>'s value is higher than another
     * <CODE>Version</CODE>'s value.
     *
     * @param version  the <CODE>Version</CODE> to be compared
     * @return true if higher else false
     */
    public boolean isHigher(Version version){
        StringTokenizer thisVersionNumbers = new StringTokenizer(getVersionNumber(), ".");
        LOGGER.info("thisVersionNumbers = " + thisVersionNumbers);
        StringTokenizer versionNumbers = new StringTokenizer(version.getVersionNumber(), ".");
        LOGGER.info("versionNumbers = " + versionNumbers);

        String thisNumberToken = null;
        String numberToken = null;
        while(versionNumbers.hasMoreTokens()){
            thisNumberToken = thisVersionNumbers.nextToken();
            numberToken = versionNumbers.nextToken();
            try{
                if(Integer.valueOf(thisNumberToken).intValue() > Integer.valueOf(numberToken).intValue()){
                    return true;
                }
            }catch(NumberFormatException nfe){
                //log.error("Error in comparing \"" + thisNumberToken + "\" > \"" + numberToken + "\"!");
            }
        }
        return false;
    }

    // TODO: die L�nge der tokenizer muss �berpr�ft werden

    /**
     * Checks if this <CODE>Version</CODE>'s value is lower than another
     * <CODE>Version</CODE>'s value.
     *
     * @param version  the <CODE>Version</CODE> to be compared
     * @return true if lower else false
     */
    public boolean isLower(Version version){
        StringTokenizer thisVersionNumbers = new StringTokenizer(getVersionNumber(), ".");
        LOGGER.info("thisVersionNumbers = " + thisVersionNumbers);
        StringTokenizer versionNumbers = new StringTokenizer(version.getVersionNumber(), ".");
        LOGGER.info("versionNumbers = " + versionNumbers);
        String thisNumberToken = null;
        String numberToken = null;
        while(versionNumbers.hasMoreTokens()){
            thisNumberToken = thisVersionNumbers.nextToken();
            numberToken = versionNumbers.nextToken();
            try{
                if(Integer.valueOf(thisNumberToken).intValue() < Integer.valueOf(numberToken).intValue()){
                    return true;
                }
            }catch(NumberFormatException nfe){
                LOGGER.severe("Error in comparing \"" + thisNumberToken + "\" < \"" + numberToken + "\"!");
            }
        }
        return false;
    }


    /**
     * Checks if this <CODE>Version</CODE>'s value is equal to another
     * <CODE>Version</CODE>'s value.
     * @param version
     * @return true if equal else false
     */
    public boolean isEqual(Version version){
        return this.version.equals(version.getVersionNumber());
    }


    /**
     * Compares this object to the specified object.
     *
     * @param obj the object to compare with
     * @return true if the objects are the same; false otherwise
     */
    public boolean equals(Object obj){
        if(!(obj instanceof Version)) return false;
        if(this != obj){
            return false;
        }
        // TODO: equals komplettieren
        return version.equals(((Version) obj).getVersionNumber()) &&
               owner.getClass().equals(((Version) obj).getOwner().getClass());
    }


    /**
     * Returns a String  representing this version's value.
     *
     * @return  a string representation of the value of this object
     */
    public String getVersionNumber(){
        return new String(version);
    }


    /**
     * Provides the owner of this version.
     *
     * @return the owner
     */
    public Class getOwner() {
        return owner;
    }

    /**
     * Returns a String object representing the version.
     *
     * @return  a string representation of the value of this object
     */
    public String toString(){
        if(owner == null){
            return "[Version = " + version + "]";
        }
        return "[Version of '" + owner.getName() + " = " + version + "']";
    }

}
