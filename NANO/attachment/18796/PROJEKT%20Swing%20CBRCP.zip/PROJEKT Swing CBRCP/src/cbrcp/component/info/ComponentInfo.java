package cbrcp.component.info;

import cbrcp.component.info.version.Version;
import cbrcp.component.info.version.DefaultVersion;


/**
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class ComponentInfo {

    /** Role name for a component. */
    protected String role = "";

    /** The type of a component. */
    protected String description = "";

    /** The provider of a component. */
    protected String provider = "";

    /** The author of a component. */
    protected String author = "";

    /** The version of a component. */
    protected Version version = new DefaultVersion("");

    /** An optional user defined info of a component. */
    protected String userDefined = "";

    /** The owner component of this info. */
    protected Class owner;


    /**
     * Default constructor.
     */
    public ComponentInfo() {
        this(null);
    }


    /**
     * Constructor.
     * @param owner owner component of this info
     */
    public ComponentInfo(Class owner) {
        this.owner = owner;
    }


    public String getRole() {
        return role;
    }


    public void setRole(String role) {
        this.role = role;
    }


    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }


    public String getProvider() {
        return provider;
    }


    public void setProvider(String provider) {
        this.provider = provider;
    }


    public String getAuthor() {
        return author;
    }


    public void setAuthor(String author) {
        this.author = author;
    }


    public Version getVersion() {
        return version;
    }


    public void setVersion(Version version) {
        this.version = version;
    }


    public String getUserDefined() {
        return userDefined;
    }

    public void setUserDefined(String userDefined) {
        this.userDefined = userDefined;
    }


    /**
     * Returns a string representation of the object.
     *
     * @return
     */
    public String toString(){
        return "[ComponentInfo" + (owner != null ? " for '" + owner.getName() + "'" : "") + ": "
               + "\n   role = [" + role
               + "],\n   description = [" + description
               + "],\n   provider = [" + provider
               + "],\n   author = [" + author
               + "],\n   version = " + version
               + ",\n   userDefined = [" + userDefined
               + "]\n]";
    }

}
