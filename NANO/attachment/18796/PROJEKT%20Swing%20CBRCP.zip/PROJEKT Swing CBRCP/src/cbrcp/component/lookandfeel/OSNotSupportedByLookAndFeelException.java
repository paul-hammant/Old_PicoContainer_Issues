package cbrcp.component.lookandfeel;



/**
 * Thrown when a particular L&F does not support Operating System.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2004/07/08 22:27:24 $, last change by: $Author: jens $
 */
class OSNotSupportedByLookAndFeelException
extends Exception{

    private static final String MESSAGE = System.getProperty("os.name") + " (" +
            System.getProperty("os.version") + ") is not Supported by ";

    /**
     * Constructs a <code>OSNotSupportedByLookAndFeelException</code>.
     * @param lookAndFeel class Name of L&F
     */
    public OSNotSupportedByLookAndFeelException(Class lookAndFeel) {
        super(MESSAGE + lookAndFeel.getSimpleName());
    }
}
