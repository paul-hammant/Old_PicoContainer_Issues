package cbrcp.component.statusbar;

import javax.swing.JComponent;

import java.util.Collection;
import java.util.logging.Logger;
import java.awt.Component;
import java.awt.Container;

import cbrcp.component.CBRCPAbstractComponentWithOnlyConfigSupport;
import cbrcp.component.statusbar.dragarea.DragAreaXPLookAndFeelPainter;
import cbrcp.component.statusbar.dragarea.DragAreaDefaultLookAndFeelPainter;
import cbrcp.component.statusbar.dragarea.DragAreaPainter;
import cbrcp.component.statusbar.separator.SeparatorPainter;
import cbrcp.component.statusbar.separator.SeparatorXPLookAndFeelPainter;


/**
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.5 $, $Date: 2004/10/27 17:13:01 $, last change by: $Author$
 */
public class StatusBarComponentImpl extends CBRCPAbstractComponentWithOnlyConfigSupport
implements StatusBarComponent{

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(StatusBarComponentImpl.class.getName());

    private JStatusBar statusBar;

    //private Collection fields;


    public StatusBarComponentImpl(String componentConfigFile){
        super(componentConfigFile);
        //this.fields = fields;
    }


    public JStatusBar getStatusBar() {
        return statusBar;
    }

// TODO make this work: collection in constructor etc

    /**
     * Component lifecycle method: stops this component.
     */
    public void stop(){
        super.stop();
        Container parent = statusBar.getParent();
        parent.remove(statusBar);
    }


    /**
     * Component lifecycle method: disposes this component.
     */
    public void dispose(){
        stop();
        super.dispose();
        componentInfo = null;
        statusBar = null;
    }


    public JStatusBar initStatusBar(){
        String separatorPainterClassName = getProperty("separatorPainterClass");
        String dragAreaPainterClassName = getProperty("dragAreaPainterClass");
        boolean raisedDragArea = Boolean.parseBoolean(getProperty("raisedDragArea"));
        SeparatorPainter separatorPainter = null;
        DragAreaPainter dragAreaPainter = null;
        try{
            Class separatorPainterClass = Class.forName(separatorPainterClassName);
            separatorPainter = (SeparatorPainter) separatorPainterClass.newInstance();
        }catch(ClassNotFoundException e){
            LOGGER.severe("ClassNotFoundException for separator painter classname '"
                    + separatorPainterClassName + ", switching to default painter");
            separatorPainter = new SeparatorXPLookAndFeelPainter();
        }catch(InstantiationException e){
            LOGGER.severe("InstantiationException for separator painter classname '"
                    + separatorPainterClassName + ", switching to default painter");
            separatorPainter = new SeparatorXPLookAndFeelPainter();
        }catch(IllegalAccessException e){
            LOGGER.severe("IllegalAccessException for separator painter classname '"
                    + separatorPainterClassName + ", switching to default painter");
            separatorPainter = new SeparatorXPLookAndFeelPainter();
        }
        try{
            Class dragAreaPainterClass = Class.forName(dragAreaPainterClassName);
            dragAreaPainter = (DragAreaPainter) dragAreaPainterClass.newInstance();
        }catch(ClassNotFoundException e){
            LOGGER.severe("ClassNotFoundException for dragrea painter classname '" +
                    dragAreaPainterClassName + ", switching to default painter");
            dragAreaPainter = new DragAreaDefaultLookAndFeelPainter(raisedDragArea);
        }catch(InstantiationException e){
            LOGGER.severe("InstantiationException for dragrea painter classname '" +
                    dragAreaPainterClassName + ", switching to default painter");
            dragAreaPainter = new DragAreaDefaultLookAndFeelPainter(raisedDragArea);
        }catch(IllegalAccessException e){
            LOGGER.severe("IllegalAccessException for dragrea painter classname '" +
                    dragAreaPainterClassName + ", switching to default painter");
            dragAreaPainter = new DragAreaDefaultLookAndFeelPainter(raisedDragArea);
        }
        statusBar = new JStatusBar(dragAreaPainter, separatorPainter);
        //statusBar.setVisible(true);
        return statusBar;
    }


    /**
     * Inits the leightweight Swing <CODE>JStatusBar</CODE> component with the
     * passed fields.
     *
     * @param fields    specified  custom fields contained  by the <CODE>JStatusBar</CODE>
     * @return the initialised <CODE>JStatusBar</CODE>
     */      // TODO private machen und fields extra setzen oder raus,    index f�r fields
    public JComponent initStatusBar(Collection<Component> fields){
        return initStatusBar(fields, true);
    }

               // TODO private machen und fields extra setzen oder raus,    index f�r fields
    public JComponent initStatusBar(Collection<Component> fields, boolean raisedDragArea){
        if(statusBar == null){
            statusBar = new JStatusBar(fields, Boolean.parseBoolean(
                    getProperty("raisedDragArea")));
        }
        return statusBar;
    }

             // TODO private machen und �ber config steuern   raus!
    public void setDragAreaLAndF(int lookAndFeel){
        switch(lookAndFeel){
            case DRAG_AREA_DEFAULT_L_AND_F:
                statusBar.setDragAreaPainter(new DragAreaDefaultLookAndFeelPainter());
                break;
            case DRAG_AREA_XP_L_AND_F:
                statusBar.setDragAreaPainter(new DragAreaXPLookAndFeelPainter());
                break;
            default:
                statusBar.setDragAreaPainter(new DragAreaDefaultLookAndFeelPainter());
                break;
        }
    }


    /*
     * Creates a new empty instance of <CODE>JStatusBarField</CODE> used for
     * dummy fields.
     */
/*    public JPanel createStatusBarField() {
        return new JStatusBarField();
    }  */


    /*
     * Creates a new empty instance of <CODE>JStatusBarField</CODE> with a fixed
     * width used for dummy fields. The field has a <CODE>TinyBevelBorder</CODE>.
     */
/*     public JPanel createStatusBarField(int fixedWidth) {
        return new JStatusBarField(fixedWidth);
    }  */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE>with default fonts.
     * It contains of a <CODE>JLabel</CODE> for the appropiate content. The
     * field has a <CODE>TinyBevelBorder</CODE>.
     *
     * @param content Holds the value for the content the field provides .
     */
/*     public JPanel createStatusBarField(String content) {
        return new JStatusBarField(content);
    }   */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE> with default
     * fonts. It consists of two horizontal aligned Sections: <P> <OL> <LI>a
     * <CODE>JLabel</CODE> with a label for the content and an icon</LI> <LI>the
     * <CODE>JLabel</CODE> for the appropiate content.</LI> </OL> </P> The field
     * has a <CODE>TinyBevelBorder</CODE>.
     *
     * @param label      Holds the string value for the label.
     * @param labelColor Defines the color for the label.
     * @param content    Holds the value for the content the field provides .
     */
/*     public JPanel createStatusBarField(String label, Color labelColor, String content) {
        return new JStatusBarField(label, labelColor, content);
    }  */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE> with default
     * fonts. It consists of two horizontal aligned Sections: <P> <OL> <LI>a
     * <CODE>JLabel</CODE> with a label for the content and an icon</LI> <LI>the
     * <CODE>JLabel</CODE> for the appropiate content.</LI> </OL> </P> The field
     * has a <CODE>TinyBevelBorder</CODE>.
     *
     * @param label               Holds the string value for the label.
     * @param img                 Holds the icon for the field.
     * @param horizontalAlignment For the icon: one of the following constants
     *                            defined in <CODE>SwingConstants</CODE>: LEFT,
     *                            CENTER, RIGHT, LEADING or TRAILING.
     * @param labelColor          Defines the color for the label.
     * @param content             Holds the value for the content the field
     *                            provides .
     */
/*     public JPanel createStatusBarField(String label, ImageIcon img,
                                       int horizontalAlignment, Color labelColor,
                                       String content) {
        return new JStatusBarField(label, img, horizontalAlignment, labelColor,
                                   content);
    }   */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE>. It contains of a
     * <CODE>JLabel</CODE> for the appropiate content. The field has a
     * <CODE>TinyBevelBorder</CODE>.
     *
     * @param content     Holds the value for the content the field provides .
     * @param contentFont Holds the font value the content has.
     */
/*     public JPanel createStatusBarField(String content, Font contentFont) {
        return new JStatusBarField(content, contentFont);
    }   */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE>. It consists of
     * two  horizontal aligned Sections: <P> <OL> <LI>a <CODE>JLabel</CODE> with
     * a label for the content and an icon</LI> <LI>the <CODE>JLabel</CODE> for
     * the appropiate content.</LI> </OL> </P> The field has a
     * <CODE>TinyBevelBorder</CODE>.
     *
     * @param label       Holds the string value for the label.
     * @param labelColor  Defines the color for the label.
     * @param content     Holds the value for the content the field provides .
     * @param labelFont   Holds the font value the label has.
     * @param contentFont Holds the font value the content has.
     */
/*     public JPanel createStatusBarField(String label, Color labelColor, String content,
                                       Font labelFont, Font contentFont) {
        return new JStatusBarField(label, labelColor, content, labelFont, contentFont);
    }   */


    /*
     * Creates a new instance of <CODE>JStatusBarField</CODE>. It consists of
     * two horizontal aligned Sections: <P> <OL> <LI>a <CODE>JLabel</CODE> with
     * a label for the content and an icon</LI> <LI>the <CODE>JLabel</CODE> for
     * the appropiate content.</LI> </OL> </P> The field has a
     * <CODE>TinyBevelBorder</CODE>.
     *
     * @param label               Holds the string value for the label.
     * @param img                 Holds the icon for the field.
     * @param horizontalAlignment For the icon: one of the following constants
     *                            defined in <CODE>SwingConstants</CODE>: LEFT,
     *                            CENTER, RIGHT, LEADING or TRAILING.
     * @param labelColor          Defines the color for the label.
     * @param content             Holds the value for the content the field
     *                            provides .
     * @param labelFont           Holds the font value the label has.
     * @param contentFont         Holds the font value the content has.
     */
/*     public JPanel createStatusBarField(String label, ImageIcon img,
                                       int horizontalAlignment, Color labelColor,
                                       String content, Font labelFont, Font contentFont) {
        return new JStatusBarField(label, img, horizontalAlignment, labelColor,
                                   content, labelFont, contentFont);
    }    */

}
