package cbrcp.component.toolbar;

import cbrcp.component.CBRCPComponent;

import javax.swing.JPanel;
import javax.swing.Icon;
import javax.swing.JToolBar;
import java.awt.Component;


/**
 * The communication interface for the ToolBarComponent component.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.12 $, $Date: 2004/09/18 16:03:42 $, last change by: $Author$
 */
public interface ToolBarComponent{

    public static String ROLE = ToolBarComponent.class.getName();

    public static final int TOP_HORIZONTAL_SEPARATOR = 0;

    public static final int BOTTOM_HORIZONTAL_SEPARATOR = 1;

    public static final int BOTH_HORIZONTAL_SEPARATOR = 2;

    public static final int NO_HORIZONTAL_SEPARATOR = 3;

    public static final int SPACE_VERTICAL_TOOLBAR_STYLE = 4;

    public static final int JSEPARATOR_VERTICAL_TOOLBAR_STYLE = 5;


    public Component initToolBar();

    public void addTool(String nameKey, int desiredIndex, boolean indexReserved,
                        JToolBar tool);

    public void reactivateTool(String nameKey);

    public void suspendTool(String nameKey);

    public void removeTool(String nameKey);

}
