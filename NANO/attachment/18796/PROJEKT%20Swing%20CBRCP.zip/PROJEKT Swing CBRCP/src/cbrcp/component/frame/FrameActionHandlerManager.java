package cbrcp.component.frame;

import java.util.HashMap;
import java.util.logging.Logger;

import org.picocontainer.PicoContainer;

import cbrcp.action.ActionHandler;
import cbrcp.action.DuplicateActionHandlerNameException;
import cbrcp.action.ActionHandlerDoesNotExistException;
import cbrcp.component.toolbar.ToolBarComponent;
import cbrcp.component.menubar.MenuBarComponent;

import javax.swing.JFrame;


/**
 *
 * @author  <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.1 $, $Date: 2004/10/27 17:13:01 $, last change by: $Author$
 * @deprecated
 */
class FrameActionHandlerManager {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(FrameActionHandlerManager.class.getName());

    private HashMap<String, ActionHandler> actionHandlers;

    private MenuBarComponent menuBarComponent;

    private ToolBarComponent toolBarComponent;

    private JFrame frame;


    public FrameActionHandlerManager(FrameComponentImpl frameComponent){
        frame = frameComponent.getFrame();
        actionHandlers = new HashMap<String, ActionHandler>();
        PicoContainer container = frameComponent.getContainer();
        menuBarComponent = (MenuBarComponent) container.getComponentInstance(MenuBarComponent.ROLE);
        toolBarComponent = (ToolBarComponent) container.getComponentInstance(ToolBarComponent.ROLE);
    }


    public FrameActionHandlerManager(FrameComponentImpl frameComponent,
                                     MenuBarComponent menuBarComponent,
                                     ToolBarComponent toolBarComponent){
        frame = frameComponent.getFrame();
        actionHandlers = new HashMap<String, ActionHandler>();
        this.menuBarComponent = menuBarComponent;
        this.toolBarComponent = toolBarComponent;
    }


    public void addActionHandler(ActionHandler handler)
        throws DuplicateActionHandlerNameException {
        String name = handler.getName();
        if(actionHandlers.containsKey(name)){
            throw DuplicateActionHandlerNameException.createDuplicateActionHandlerNameException(
                    "addActionHandler", name);
        }else{
            LOGGER.finest("handler index = " + handler.getIndex());
            int mode = handler.getMode();
            switch(mode){
                case ActionHandler.BOTH_MODE:
                    LOGGER.finest("both MODE in addActionHandler(...)");
                    addTools(handler);
                    addMenus(handler);
                    break;
                case ActionHandler.MENU_MODE:
                    LOGGER.finest("only menubar MODE in addActionHandler(...)");
                    addMenus(handler);
                    break;
                case ActionHandler.TOOL_MODE:
                    LOGGER.finest("only toolbar MODE in addActionHandler(...)");
                    addTools(handler);
                    break;
            }
            handler.setOwner(frame);
            actionHandlers.put(name, handler);
            frame.validate();
        }
    }


    public void reactivateActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException {
        if(!actionHandlers.containsKey(actionHandlerName)){
            throw ActionHandlerDoesNotExistException.createActionHandlerDoesNotExistException(
                    "reactivateActionHandler", actionHandlerName);
        }else{
            ActionHandler handler = (ActionHandler) actionHandlers.get(actionHandlerName);
            int mode = handler.getMode();
            switch(mode){
                case ActionHandler.BOTH_MODE:
                    LOGGER.finest("both MODE in reactivateActionHandler(...)");
                    toolBarComponent.reactivateTool(actionHandlerName);
                    menuBarComponent.reactivateMenu(actionHandlerName);
                    break;
                case ActionHandler.MENU_MODE:
                    LOGGER.finest("only menubar MODE in reactivateActionHandler(...)");
                    menuBarComponent.reactivateMenu(actionHandlerName);
                    break;
                case ActionHandler.TOOL_MODE:
                    LOGGER.finest("only toolbar MODE in reactivateActionHandler(...)");
                    toolBarComponent.reactivateTool(actionHandlerName);
                    break;
            }
            frame.validate();
        }
    }


    public void suspendActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException{
        if(!actionHandlers.containsKey(actionHandlerName)){
            throw ActionHandlerDoesNotExistException.createActionHandlerDoesNotExistException(
                    "suspendActionHandler", actionHandlerName);
        }else{
            ActionHandler handler = (ActionHandler) actionHandlers.get(actionHandlerName);
            int mode = handler.getMode();
            switch(mode){
                case ActionHandler.BOTH_MODE:
                    LOGGER.finest("both MODE in suspendActionHandler(...)");
                    toolBarComponent.suspendTool(actionHandlerName);
                    menuBarComponent.suspendMenu(actionHandlerName);
                    break;
                case ActionHandler.MENU_MODE:
                    LOGGER.finest("only menubar MODE in suspendActionHandler(...)");
                    menuBarComponent.suspendMenu(actionHandlerName);
                    break;
                case ActionHandler.TOOL_MODE:
                    LOGGER.finest("only toolbar MODE in suspendActionHandler(...)");
                    toolBarComponent.suspendTool(actionHandlerName);
                    break;
            }
            frame.validate();
        }
    }


    public void removeActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException{
        if(!actionHandlers.containsKey(actionHandlerName)){
            throw ActionHandlerDoesNotExistException.createActionHandlerDoesNotExistException(
                    "removeActionHandler", actionHandlerName);
        }else{
            ActionHandler handler = (ActionHandler) actionHandlers.get(actionHandlerName);
            int mode = handler.getMode();
            switch(mode){
                case ActionHandler.BOTH_MODE:
                LOGGER.finest("both MODE in removeActionHandler(...)");
                    toolBarComponent.removeTool(actionHandlerName);
                    menuBarComponent.removeMenu(actionHandlerName);
                    break;
                case ActionHandler.MENU_MODE:
                    LOGGER.finest("only menubar MODE in removeActionHandler(...)");
                    menuBarComponent.removeMenu(actionHandlerName);
                    break;
                case ActionHandler.TOOL_MODE:
                    LOGGER.finest("only toolbar MODE in removeActionHandler(...)");
                    toolBarComponent.removeTool(actionHandlerName);
                    break;
            }
            actionHandlers.remove(actionHandlerName);
            frame.validate();
        }
    }


    private void addTools(ActionHandler handler){
        LOGGER.finest("ADDING Tool IN FRAME WITH name = " + handler.getName());
        toolBarComponent.addTool(handler.getName(), handler.getIndex(),
                        handler.isIndexReserved(), handler.getToolBar());
    }


    private void addMenus(ActionHandler handler){
        LOGGER.finest("ADDING Menu IN FRAME WITH name = " + handler.getName());
        menuBarComponent.addMenu(handler.getName(), handler.getIndex(),
                        handler.isIndexReserved(), handler.getMenu());
    }

}
