package cbrcp.component.lookandfeel;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class SkinLinuxLookAndFeelProxy extends AbstractLookAndFeelProxy{

    public SkinLinuxLookAndFeelProxy() {
        super("com.l2fprod.gui.plaf.skin.LinuxLookAndFeel");
    }
}
