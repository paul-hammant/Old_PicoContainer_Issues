package cbrcp.component.statusbar.dragarea;

import java.awt.Graphics2D;
import java.awt.SystemColor;

/**
 * This class paints a default Windows L&amp;F drag area.
 *
 * @author  <A href="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:15 $, last change by: $Author: jens $
 */
public class DragAreaDefaultLookAndFeelPainter
extends AbstractDragAreaLookAndFeelPainter{


    /**
     * Creates a default instance of <CODE>DragAreaDefaultLookAndFeelPainter</CODE>
     * with a raised drag area.
     */
    public DragAreaDefaultLookAndFeelPainter() {
        this(false);
    }


    /**
     * Creates a new instance of <CODE>DragAreaDefaultLookAndFeelPainter</CODE>.
     *
     * @param raised flag if the drag area is shown raised
     */
    public DragAreaDefaultLookAndFeelPainter(boolean raised) {
        super(raised);
    }


    /**
     * Paints the custom drag area.
     *
     * @param   g2      the graphics context for this painter
     * @param   width   the width of the statusbar, needed to know where to paint
     * @param   height  the height of the statusbar, needed to know where to paint
     */
    public void paint(Graphics2D g2, int width, int height){
        if(raised){
            //First lines
            g2.setColor(SystemColor.controlShadow);
            g2.drawLine(width - 2, height - 2, width - 2, height - 2);
            g2.drawLine(width - 3, height - 2, width - 2, height - 3);

            g2.setColor(SystemColor.controlLtHighlight);
            g2.drawLine(width - 4, height - 2, width - 2, height - 4);

            //Second lines
            g2.setColor(SystemColor.menu);
            g2.drawLine(width - 5, height - 2, width - 2, height - 5);
            g2.setColor(SystemColor.controlShadow);
            g2.drawLine(width - 6, height - 2, width - 2, height - 6);
            g2.drawLine(width - 7, height - 2, width - 2, height - 7);

            g2.setColor(SystemColor.controlLtHighlight);
            g2.drawLine(width - 8, height - 2, width - 2, height - 8);

            //Third lines
            g2.setColor(SystemColor.menu);
            g2.drawLine(width - 9, height - 2, width - 2, height - 9);
            g2.setColor(SystemColor.controlShadow);
            g2.drawLine(width - 10, height - 2, width - 2, height - 10);
            g2.drawLine(width - 11, height - 2, width - 2, height - 11);

            g2.setColor(SystemColor.controlLtHighlight);
            g2.drawLine(width - 12, height - 2, width - 2, height - 12);

            //Fourth lines
            g2.setColor(SystemColor.menu);
            g2.drawLine(width - 13, height - 2, width - 2, height - 13);
            g2.setColor(SystemColor.controlShadow);
            g2.drawLine(width - 14, height - 2, width - 2, height - 14);
            g2.drawLine(width - 15, height - 2, width - 2, height - 15);

            g2.setColor(SystemColor.controlLtHighlight);
            g2.drawLine(width - 16, height - 2, width - 2, height - 16);
        }else{// etched
            //First lines
            g2.setColor(SystemColor.controlLtHighlight);
            g2.drawLine(width - 1, height - 1, width - 1, height - 1);
            g2.drawLine(width - 2, height - 1, width - 1, height - 2);

            g2.setColor(SystemColor.controlShadow);
            g2.drawLine(width - 3, height - 1, width - 1, height - 3);

            //Second lines
            g2.setColor(SystemColor.menu);
            g2.drawLine(width - 4, height - 1, width - 1, height - 4);
            g2.setColor(SystemColor.controlLtHighlight);
            g2.drawLine(width - 5, height - 1, width - 1, height - 5);
            g2.drawLine(width - 6, height - 1, width - 1, height - 6);

            g2.setColor(SystemColor.controlShadow);
            g2.drawLine(width - 7, height - 1, width - 1, height - 7);

            //Third lines
            g2.setColor(SystemColor.menu);
            g2.drawLine(width - 8, height - 1, width - 1, height - 8);
            g2.setColor(SystemColor.controlLtHighlight);
            g2.drawLine(width - 9, height - 1, width - 1, height - 9);
            g2.drawLine(width - 10, height - 1, width - 1, height - 10);

            g2.setColor(SystemColor.controlShadow);
            g2.drawLine(width - 11, height - 1, width - 1, height - 11);

            //Fourth lines
            g2.setColor(SystemColor.menu);
            g2.drawLine(width - 12, height - 1, width - 1, height - 12);
            g2.setColor(SystemColor.controlLtHighlight);
            g2.drawLine(width - 13, height - 1, width - 1, height - 13);
            g2.drawLine(width - 14, height - 1, width - 1, height - 14);

            g2.setColor(SystemColor.controlShadow);
            g2.drawLine(width - 15, height - 1, width - 1, height - 15);
        }
    }

}
