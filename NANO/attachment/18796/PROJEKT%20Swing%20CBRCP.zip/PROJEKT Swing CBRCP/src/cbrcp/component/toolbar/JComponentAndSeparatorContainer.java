package cbrcp.component.toolbar;

import javax.swing.JPanel;
import javax.swing.JComponent;
import javax.swing.JSeparator;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Container;
import java.util.logging.Logger;


/**
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.4 $, $Date: 2004/09/18 16:03:42 $, last change by: $Author$
 */
class JComponentAndSeparatorContainer
extends Container{

    /** Just for logging purposes. */
    private final static Logger LOGGER = Logger.getLogger(JComponentAndSeparatorContainer.class.getName());

    private JPanel sepPanel;

    private boolean separator;

    private JSeparator sep;

    private JComponent comp;

    private int separatorStyle;


    public JComponentAndSeparatorContainer(JComponent c){
        this(c, ToolBarComponent.JSEPARATOR_VERTICAL_TOOLBAR_STYLE);
    }


    public JComponentAndSeparatorContainer(JComponent c, int separatorStyle){
        setLayout(new BorderLayout());
        comp = c;
        this.separator = separator;
        sep = new JSeparator(JSeparator.VERTICAL);
        sepPanel = new JPanel(new BorderLayout());
        if(separatorStyle == ToolBarComponent.JSEPARATOR_VERTICAL_TOOLBAR_STYLE){
            sepPanel.add(sep, BorderLayout.CENTER);
        }else{
            sepPanel.setPreferredSize(new Dimension(
                    (int)sepPanel.getPreferredSize().getWidth() + 10,
                    (int)getPreferredSize().getHeight()));
        }
        add(comp, BorderLayout.CENTER);
        add(sepPanel, BorderLayout.EAST);
    }


    public JComponent getComp() {
        return comp;
    }


    public void addComp(JComponent comp) {
        this.comp = comp;
        add(comp, 0);
    }


    public boolean isSeparator() {
        return separator;
    }


    public void removeSeparator(){
        remove(sepPanel);
    }


    public void addSeparator(){
        add(sepPanel, BorderLayout.EAST);
    }


/*    public void setSeparator(boolean separator) {
        boolean oldSeparator = this.separator;
        this.separator = separator;
        if(separator && !oldSeparator){
            LOGGER.debug("Adding SEPARATOR!");
            sepPanel.add(sep, BorderLayout.CENTER);
        }else{
            LOGGER.debug("Removing SEPARATOR!");
            sepPanel.remove(sep);
        }
        validate();
        repaint();
    }     */

}
