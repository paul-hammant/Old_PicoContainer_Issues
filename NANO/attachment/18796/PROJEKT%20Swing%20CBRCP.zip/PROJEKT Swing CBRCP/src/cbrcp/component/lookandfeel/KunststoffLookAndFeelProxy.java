package cbrcp.component.lookandfeel;

import java.util.Vector;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class KunststoffLookAndFeelProxy extends AbstractLookAndFeelProxy {

    private static final String KUNSTSTOFF_L_AND_F=
            "com.incors.plaf.kunststoff.KunststoffLookAndFeel";

    private static final String[] KUNSTSTOFF_THEMES= new String[]{
            "com.incors.plaf.kunststoff.themes.KunststoffDesktopTheme",
            "com.incors.plaf.kunststoff.themes.KunststoffNotebookTheme",
            "com.incors.plaf.kunststoff.themes.KunststoffPresentationTheme"};

    private static Vector<ThemeProxy> THEME_PROXIES = new Vector<ThemeProxy>(KUNSTSTOFF_THEMES.length);

    static{
        for(int i = 0; i < KUNSTSTOFF_THEMES.length; i++ ){
            THEME_PROXIES.add(new ThemeProxy(KUNSTSTOFF_THEMES[i], KunststoffLookAndFeelProxy.class));
        }
    }


    public KunststoffLookAndFeelProxy() {
        super(KUNSTSTOFF_L_AND_F, THEME_PROXIES);
    }

}
