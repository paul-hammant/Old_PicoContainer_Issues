package cbrcp.component.lookandfeel;

import com.jgoodies.looks.plastic.PlasticLookAndFeel;
import com.jgoodies.looks.plastic.PlasticTheme;
import com.incors.plaf.kunststoff.KunststoffLookAndFeel;
import com.incors.plaf.kunststoff.GradientTheme;

import javax.swing.LookAndFeel;
import javax.swing.plaf.metal.MetalTheme;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.logging.Logger;
import java.util.Vector;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public abstract class AbstractLookAndFeelProxy {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(AbstractLookAndFeelProxy.class.getName());

    private String lookAndFeelClassName;

    private Vector<ThemeProxy> themeProxies;

    private Class lookAndFeelClass;

    private String lookAndFeelName;


    AbstractLookAndFeelProxy(String className){
        this(className, null);
    }

    AbstractLookAndFeelProxy(String className, Vector<ThemeProxy> themeProxies){
        lookAndFeelClassName = className;
        try{
            lookAndFeelClass = Class.forName(className);
        }catch(ClassNotFoundException e){
            LOGGER.warning("ClassNotFoundException for L&F classname '"
                    + lookAndFeelClassName + "': L&F not suported by CBRCB, add lib to classpath before starting!");
            return;
        }
        if(themeProxies != null){
            this.themeProxies = themeProxies;
        }else{
            this.themeProxies = new Vector<ThemeProxy>();
        }
        lookAndFeelName = getLookAndFeel().getName();
    }


    final String[] getLookAndFeelThemeNames(){
        String[] themeNames = themeNames = new String[themeProxies.size()];
        for(int i = 0; i < themeNames.length; i++ ){
            ThemeProxy themeProxy = themeProxies.elementAt(i);
            themeNames[i] = themeProxy.getLookAndFeelThemeName();
        }
        return themeNames;
    }

    public Vector<ThemeProxy> getThemeProxies() {
        return themeProxies;
    }

    public final String getLookAndFeelName(){
        return lookAndFeelName;
    }


    public final LookAndFeel getLookAndFeelWithTheme(String lookAndFeelThemeClassName){
        // instantiate theme class
        ThemeProxy themeProxy = new ThemeProxy(lookAndFeelThemeClassName, getClass());
        Class lookAndFeelThemeClass = themeProxy.getLookAndFeelThemeClass();
        Object lookAndFeelTheme = themeProxy.newLookAndFeelThemeInstance();

        // instantiate L&F
        LookAndFeel lookAndFeel = null;
        try{
            Class lookAndFeelClass = Class.forName(lookAndFeelClassName);
            if(lookAndFeelThemeClass != null){
                Class formParams[] = new Class[]{lookAndFeelThemeClass};
                Constructor con = null;
                try{
                    con = lookAndFeelClass.getConstructor(formParams[0]);
                    Object[] actParams = new Object[]{lookAndFeelTheme};
                    lookAndFeel = (LookAndFeel) con.newInstance(actParams);
                }catch(NoSuchMethodException e){
                    LOGGER.warning("NoSuchMethodException while passing L&F theme '" +
                            lookAndFeelThemeClassName + "' \ninto constructor of object '"
                    + lookAndFeelClassName + "', \nignoring theme or doing workaround for theme if possible...");
                    lookAndFeel = (LookAndFeel) lookAndFeelClass.newInstance();
                }catch(InvocationTargetException e){
                    LOGGER.warning("InvocationTargetException while passing L&F theme '" +
                            lookAndFeelThemeClassName + "' \ninto constructor of object '"
                    + lookAndFeelClassName + "', \nignoring theme or doing workaround for theme if possible...");
                    lookAndFeel = (LookAndFeel) lookAndFeelClass.newInstance();
                }
            }else{
                lookAndFeel = (LookAndFeel) lookAndFeelClass.newInstance();
            }
        }catch(ClassNotFoundException e){
            LOGGER.warning("ClassNotFoundException for L&F classname '"
                    + lookAndFeelClassName + "'");
            return null;
        }catch(InstantiationException e){
            LOGGER.warning("InstantiationException for L&F classname '"
                    + lookAndFeelClassName + "'");
            return null;
        }catch(IllegalAccessException e){
            LOGGER.warning("IllegalAccessException for L&F classname '"
                    + lookAndFeelClassName + "'");
            return null;
        }

        if(lookAndFeel instanceof PlasticLookAndFeel && lookAndFeelTheme != null){
            workAroundPlasticLAndF(lookAndFeelTheme);
        }
        if(lookAndFeel instanceof KunststoffLookAndFeel && lookAndFeelTheme != null){
            workAroundKunstoffLAndF(lookAndFeelTheme);
        }

        return lookAndFeel;
    }


    public final LookAndFeel getLookAndFeel(){
        // instantiate L&F
        LookAndFeel lookAndFeel = null;
        try{
            Class lookAndFeelClass = Class.forName(lookAndFeelClassName);
            lookAndFeel = (LookAndFeel) lookAndFeelClass.newInstance();
        }catch(ClassNotFoundException e){
            LOGGER.warning("ClassNotFoundException for L&F classname '"
                    + lookAndFeelClassName + "'");
        }catch(InstantiationException e){
            LOGGER.warning("InstantiationException for L&F classname '"
                    + lookAndFeelClassName + "'");
        }catch(IllegalAccessException e){
            LOGGER.warning("IllegalAccessException for L&F classname '"
                    + lookAndFeelClassName + "'");
        }
        return lookAndFeel;
    }


    public final String getLookAndFeelClassName(){
        return lookAndFeelClassName;
    }

    public final Class getLookAndFeelClass(){
        return lookAndFeelClass;
    }


    // TODO: maybe this must be supported for other themes

    /**
     * Workaround for JGoodies' "looks-1.3.2" L&F: it has no constructor to set
     * theme.
     * @param lookAndFeelTheme to workaround
     */
    private static void workAroundPlasticLAndF(Object lookAndFeelTheme){
        PlasticLookAndFeel.setMyCurrentTheme((PlasticTheme) lookAndFeelTheme);
        LOGGER.info("...workaround for theme '" + lookAndFeelTheme.getClass().getName() + "' successful!");
    }


    /**
     * Workaround for incors.org's "kunststoff-2.0.2" L&F: it has no constructor
     * to set theme.
     * @param lookAndFeelTheme to workaround
     */
    private static void workAroundKunstoffLAndF(Object lookAndFeelTheme){
        if(lookAndFeelTheme instanceof MetalTheme){
            KunststoffLookAndFeel.setCurrentTheme((MetalTheme) lookAndFeelTheme);
        }
        if(lookAndFeelTheme instanceof GradientTheme){
            KunststoffLookAndFeel.setCurrentGradientTheme((GradientTheme) lookAndFeelTheme);
        }
        LOGGER.info("...workaround for theme '" + lookAndFeelTheme.getClass().getName() + "' successful!");
    }


    public final String toString(){
        return getLookAndFeelName();
    }
}
