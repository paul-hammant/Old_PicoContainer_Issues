package cbrcp.component.lookandfeel;

/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class PlasticXPLookAndFeelProxy extends AbstractPlasticLookAndFeelProxy {

    private static final String PLASTIC_XP_L_AND_F =
            "com.jgoodies.looks.plastic.PlasticXPLookAndFeel";


    public PlasticXPLookAndFeelProxy() {
        super(PLASTIC_XP_L_AND_F);
    }
}
