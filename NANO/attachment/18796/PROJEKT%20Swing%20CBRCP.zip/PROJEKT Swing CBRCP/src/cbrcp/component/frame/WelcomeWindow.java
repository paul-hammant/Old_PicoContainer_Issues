package cbrcp.component.frame;

import cbrcp.util.io.ImageUtil;

import javax.swing.border.Border;
import javax.swing.Icon;
import javax.swing.JWindow;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.BorderFactory;
import javax.swing.Timer;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.logging.Logger;


/**
 * {@link WelcomeWindow} creates a centered welcome window during CBRCP start.
 *
 * @author <a href="mailto:j.krefeldt@gmx.de">Jens Krefeldt</a>
 * @version $Revision: 1.7 $, $Date: 2004/10/27 17:13:01 $, last change by: $Author$
 */
class WelcomeWindow extends JWindow implements ActionListener{

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(WelcomeWindow.class.getName());

    private Frame owner;

    private Icon icon;

    private Color backgroundColor;

    private Color borderColor;

    private Color textColor;

    private String textTop;

    private String textBottom;

    private String textCopyright;


    /**
     * Creates a new instance of <CODE>WelcomeWindow</CODE>.
     * @param owner
     * @param imagePath
     */
    public WelcomeWindow(Frame owner, String imagePath) {
        super(owner);
        this.owner = owner;
        //this.imagePath = imagePath;
        icon = ImageUtil.getIconSystemResource(imagePath);
        backgroundColor = Color.WHITE;
        borderColor = Color.BLACK;
        textColor = Color.BLACK;
    }


    /**
     * Shows the window for <code>duration</code> [msec].
     * @param duration
     */
    public void showWelcomeWindow(int duration) {
        JPanel content = (JPanel) getContentPane();

        JLabel iconLabel = new JLabel(icon);
        JPanel textContainer = new JPanel(new BorderLayout());
        JPanel textPanel = new JPanel(new GridLayout(3, 1));
        JLabel textLabelTop = new JLabel("", JLabel.CENTER);
        JLabel textLabelBottom = new JLabel("", JLabel.CENTER);

        JLabel crLabel = new JLabel("", JLabel.CENTER);
        crLabel.setForeground(textColor);

        textContainer.add(new JSeparator(), BorderLayout.NORTH);
        textPanel.setBackground(backgroundColor);
        textPanel.setForeground(textColor);
        textContainer.add(textPanel, BorderLayout.CENTER);

        textLabelTop.setForeground(textColor);
        textLabelTop.setFont(new Font("Arial", Font.BOLD, 20));
        textLabelBottom.setForeground(textColor);
        textLabelBottom.setFont(new Font("Arial", Font.BOLD, 20));

        textPanel.add(textLabelTop);
        textPanel.add(textLabelBottom);
        textPanel.add(crLabel);
        textLabelTop.setText(textTop);
        textLabelBottom.setText(textBottom);
        crLabel.setText(textCopyright);

        textLabelTop.setOpaque(false);
        textLabelBottom.setOpaque(false);
        crLabel.setOpaque(false);

        Border outLine = BorderFactory.createLineBorder(borderColor);

        content.add(iconLabel, BorderLayout.CENTER);
        content.add(textContainer, BorderLayout.SOUTH);
        content.setBorder(outLine);
        pack();
        setWindowBounds();
        setVisible(true);
        toFront();
        new Timer(duration, this).start();
    }


    public void actionPerformed(ActionEvent evt) {
        setVisible(false);
        dispose();
    }


    private void setWindowBounds() {
        // getting the bounds of parent
        Rectangle rect;
        if (owner == null) {
            rect = getOwner().getBounds();
        } else {
            rect = owner.getBounds();
        }

        // get the upper left corner of the parent as offset values for final
        // upper left point of this dialog
        int x = (int) rect.getX();
        int y = (int) rect.getY();

        // compute the upper left corner position
        int xFinal = x + (int) (rect.getWidth() - getPreferredSize().getWidth()) / 2;
        int yFinal = y + (int) (rect.getHeight() - getPreferredSize().getHeight()) / 2;

        // make sure dialog will not be hidden elsewhere, maybe the case if parent is null
        if (xFinal < 0) {
            xFinal = 0;
        }
        if (yFinal < 0) {
            yFinal = 0;
        }

        // ok, now we can set the bounds
        setBounds(xFinal, yFinal, (int) getPreferredSize().width,
                (int) getPreferredSize().height);
    }

    public void setBackgroundColor(Color backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public void setImage(Icon icon) {
        this.icon = icon;
    }

    public void setBorderColor(Color borderColor) {
        this.borderColor = borderColor;
    }

    public void setTextColor(Color textColor) {
        this.textColor = textColor;
    }

    public void setTextTop(String textTop) {
        this.textTop = textTop;
    }

    public void setTextBottom(String textBottom) {
        this.textBottom = textBottom;
    }

    public void setTextCopyright(String textCopyright) {
        this.textCopyright = textCopyright;
    }
}


