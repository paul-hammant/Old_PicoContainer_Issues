package cbrcp.component.lookandfeel;

/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 * @deprecated
 */
class PlasticLookAndFeelProxy extends AbstractPlasticLookAndFeelProxy {

    private static final String PLASTIC_L_AND_F =
            "com.jgoodies.looks.plastic.PlasticLookAndFeel";


    public PlasticLookAndFeelProxy() {
        super(PLASTIC_L_AND_F);
    }
}
