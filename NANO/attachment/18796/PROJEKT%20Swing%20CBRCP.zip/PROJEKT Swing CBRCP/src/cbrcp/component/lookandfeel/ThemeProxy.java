package cbrcp.component.lookandfeel;

import java.util.logging.Logger;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class ThemeProxy {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(ThemeProxy.class.getName());

    private String lookAndFeelThemeClassName;

    private Class lookAndFeelThemeClass;

    private String lookAndFeelThemeName;

    private Class lookAndFeelProxyOwner;


    ThemeProxy(ThemeProxy proxy){
        this.lookAndFeelProxyOwner = proxy.lookAndFeelProxyOwner;
        this.lookAndFeelThemeClassName = new String(proxy.lookAndFeelThemeClassName);
        try{
            lookAndFeelThemeClass = Class.forName(lookAndFeelThemeClassName);
        }catch(ClassNotFoundException e){
            LOGGER.warning("ClassNotFoundException for L&F theme classname '"
                    + this.lookAndFeelThemeClassName + "': L&F theme not suported by CBRCB, add lib to classpath before starting!");
            return;
        }
        lookAndFeelThemeName = lookAndFeelThemeClassName.substring(lookAndFeelThemeClassName.lastIndexOf('.') + 1);
    }

    ThemeProxy(String lookAndFeelThemeClassName, Class lookAndFeelProxyOwner) {
        this.lookAndFeelProxyOwner = lookAndFeelProxyOwner;
        this.lookAndFeelThemeClassName = lookAndFeelThemeClassName;
        try{
            lookAndFeelThemeClass = Class.forName(lookAndFeelThemeClassName);
        }catch(ClassNotFoundException e){
            LOGGER.warning("ClassNotFoundException for L&F theme classname '"
                    + lookAndFeelThemeClassName + "': L&F theme not suported by CBRCB, add lib to classpath before starting!");
            return;
        }
        lookAndFeelThemeName = lookAndFeelThemeClassName.substring(lookAndFeelThemeClassName.lastIndexOf('.') + 1);
    }


    public final Class getLookAndFeelThemeClass() {
        return lookAndFeelThemeClass;
    }

    public final String getLookAndFeelThemeClassName() {
        return lookAndFeelThemeClassName;
    }

    public final String getLookAndFeelThemeName() {
        return lookAndFeelThemeName;
    }


    public final String toString() {
        return lookAndFeelThemeName;
    }

    public Class getLookAndFeelProxyOwner() {
        return lookAndFeelProxyOwner;
    }

    public final Object newLookAndFeelThemeInstance(){
        try{
            return lookAndFeelThemeClass.newInstance();
        }catch(InstantiationException e){
            LOGGER.warning("InstantiationException for L&F theme classname '"
                    + lookAndFeelThemeClassName + "', theme not used.");
        }catch(IllegalAccessException e){
            LOGGER.warning("IllegalAccessException for L&F theme classname '"
                    + lookAndFeelThemeClassName + "', theme not used.");
        }
        return null;
    }

}
