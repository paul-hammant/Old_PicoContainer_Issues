package cbrcp.component.menubar;

import javax.swing.JMenuBar;
import javax.swing.JMenu;

import java.util.Vector;
import java.util.HashMap;
import java.util.Enumeration;
import java.util.logging.Logger;


/**
 *
 * @author  jens
 */
class JKeyToIndexMenuBar
extends JMenuBar{

    /** Just for logging purposes. */
    private final static Logger LOGGER = Logger.getLogger(JKeyToIndexMenuBar.class.getName());

    private Vector<AttributedMenu> items;

    private HashMap<String, AttributedMenu> cache;


    /** Creates a new instance. */
    public JKeyToIndexMenuBar() {
        items = new Vector<AttributedMenu>();
        cache = new HashMap<String, AttributedMenu>();
    }


    public void addMenu(String nameKey, int desiredIndex, boolean indexReserved,
                         JMenu menu){
        AttributedMenu aMenu = new AttributedMenu(nameKey, desiredIndex,
                                                  indexReserved, menu);
        int assignedIndex = getNextPossibleIndex(desiredIndex, indexReserved);
        LOGGER.finest("assignedIndex = " + assignedIndex + " for nameKey = " + nameKey);
        items.insertElementAt(aMenu, assignedIndex);

        refresh();
    }


    public int suspendMenu(String nameKey){
        int index = key2Index(nameKey);
        if(index > -1){
            remove(index);
            cache(index);
        }else{
            return -1;
        }
        return 1;
    }

    private void cache(int index){
        try{
            AttributedMenu aMenu = (AttributedMenu) items.elementAt(index);
            items.remove(index);
            cache.put(aMenu.getNameKey(), aMenu);
        }catch(ArrayIndexOutOfBoundsException e){
            LOGGER.severe("ArrayIndexOutOfBoundsException in cache(...): " + e.getMessage());
            e.printStackTrace();
        }
    }


    public int reactivateMenu(String nameKey){
        if(cache.get(nameKey) != null){
            AttributedMenu aMenu = (AttributedMenu) cache.remove(nameKey);
            addMenu(aMenu.getNameKey(), aMenu.getDesiredIndex(), aMenu.isIndexReserved(),
                aMenu.getMenu());
        }else{
            return -1;
        }
        return 1;
    }


    public int removeMenu(String nameKey){
        int index = key2Index(nameKey);
        if(index > -1){
            remove(index);
            if(cache.get(nameKey) != null){
                cache.remove(nameKey);
            }
        }else{
            return -1;
        }
        return 1;
    }


    private int key2Index(String nameKey){
        items.trimToSize();
        for(int i = 0; i < items.size(); i++){
            AttributedMenu aMenu = (AttributedMenu) items.elementAt(i);
            if(aMenu.getNameKey().equals(nameKey)){
                return i;
            }
        }
        return -1;
    }


    private int relative2NormalIndex(int relative){
        if(relative < 0){
            int size = items.size();
            if(size + relative <= 0){
                return 0;
            }else{
                return size + relative;
            }
        }
        return relative;
    }


    private int getNextPossibleIndex(int desiredIndex, boolean indexReserved){
        try{
            AttributedMenu menu = null;
            int size = items.size();
            int menuIndex;
            boolean menuReserved;
            if(desiredIndex > size){ // normal index (> 0) in any case, size >= 1
                LOGGER.finest("desiredIndex = " + desiredIndex + " > size = " + size);
                menu = (AttributedMenu) items.elementAt(size - 1);
                menuIndex = menu.getDesiredIndex();
                if(menuIndex < desiredIndex){
                    return size;
                }else{
                    return size - 1;
                }
            }
            if(desiredIndex <= size){ // normal index (>= 0) or relative, size >= 1
                LOGGER.finest("desiredIndex = " + desiredIndex + " <= size = " + size);
                if(desiredIndex >= 0){ // normal index
                    LOGGER.finest("desiredIndex = " + desiredIndex + " >= 0");
                    if(size > 0){
                        menu = (AttributedMenu) items.elementAt(desiredIndex);
                        menuIndex = menu.getDesiredIndex();
                        LOGGER.finest("menuIndex = " + menuIndex);
                    }else{
                        return 0;
                    }
                    if(menuIndex < desiredIndex){  // 1st index < 2nd index
                        LOGGER.finest("menuIndex = " + menuIndex + " < desiredIndex = " + desiredIndex);
                        if(menuIndex > 0){ // prefer an index>0 to an index<0
                            return desiredIndex + 1;
                        }else{
                            return desiredIndex;
                        }
                    }else{
                        if(menuIndex == desiredIndex){
                            menuReserved = menu.isIndexReserved();
                            if(menuReserved){
                                LOGGER.finest("menuReserved = " + menuReserved + ", returning desiredIndex = " + desiredIndex + " + 1");
                                return desiredIndex + 1;  // first one reserved
                            }
                            if(indexReserved){
                                LOGGER.finest("indexReserved = " + indexReserved);
                                return desiredIndex;      // second one reserved
                            }
                            LOGGER.finest("none reserved!");
                            return desiredIndex + 1;      // none reserved
                        }else{
                            LOGGER.finest("menuIndex = " + menuIndex + " > desiredIndex = " + desiredIndex);
                            return desiredIndex;   // 1st index > 2nd index
                        }
                    }
                }else{ // relative index ( < 0)
                    LOGGER.finest("desiredIndex < 0 (relative)");
                    desiredIndex = relative2NormalIndex(desiredIndex);
                    return getNextPossibleIndex(desiredIndex, indexReserved);
                }
            }
            LOGGER.finest("LAST!!!");
        }catch(ArrayIndexOutOfBoundsException aioobe){
            LOGGER.severe("ArrayIndexOutOfBoundsException in getNextPossibleIndex(...)");
            aioobe.printStackTrace();
        }
        return 0;
    }


    private void refresh(){
        removeAll();
        for(Enumeration e = items.elements(); e.hasMoreElements();){
            AttributedMenu aMenu = ((AttributedMenu) e.nextElement());
            JMenu menu = aMenu.getMenu();
            LOGGER.finest("INSERTING MENU WITH name = " + aMenu.getNameKey());
            add(menu);
        }
        validate();
        repaint();
    }

}
