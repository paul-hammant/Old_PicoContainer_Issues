package cbrcp.component.info.version;


/**
 * This exception is thrown if the syntax of a the version number of a
 * {@link cbrcp.component.info.version.Version} object does not match its criterias, e.g.
 * <P>
 * <PRE>    &lt;major version number&gt;.&lt;minor version number&gt;.&lt;build version number&gt;</PRE>
 * <P>
 * of class {@link cbrcp.component.info.version.DefaultVersion}.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class VersionNumberFormatException
extends Exception{

    /**
     * Constructor.
     *
     * @param message the detail message (which is saved for later retrieval by
     *                <CODE>the Throwable.getMessage()<CODE> method)
     */
    public VersionNumberFormatException(String message){
        super(message);
    }
}
