package cbrcp.component;

import cbrcp.component.info.ComponentInfo;
import cbrcp.component.info.version.Version;
import cbrcp.component.info.version.DefaultVersion;

import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.logging.Logger;
import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;


/**
 * This basic abstract implementation for all components provides a {@link ComponentInfo}
 * object and its initialization by overriding the <code>initXXXInfo()</code>
 * methods in your subclass, a {@link #toString()} method for printing purposes,
 * "empty" (only logging statements) lifecycle methods (to overide in subclasses).
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public abstract class CBRCPAbstractComponent implements CBRCPComponent{

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(CBRCPAbstractComponent.class.getName());

    /** Object containg all info info for this component. */
    protected ComponentInfo componentInfo;

    /** Name of ressource bundle for NLS support. */
    protected String resourceBundleName;

    /** File for the component configuration. */
    protected File componentConfigFile;


    /**
     * Constructor for basic {@link ComponentInfo} support.
     */
    public CBRCPAbstractComponent(){
        this(null, null);
    }


    /**
     * Constructor for NLS.
     * @param resourceBundleName full file path without (!) file ending
     */
    public CBRCPAbstractComponent(String resourceBundleName){
        this(null, resourceBundleName);
    }


    /**
     * Constructor for configuration support.
     * @param componentConfigFile config file
     */
    public CBRCPAbstractComponent(File componentConfigFile){
        this(componentConfigFile, null);
    }


    /**
     * Constructor for configuration support and NLS.
     * @param componentConfigFile config file
     * @param resourceBundleName full file path without (!) file ending
     */
    public CBRCPAbstractComponent(File componentConfigFile, String resourceBundleName){
        this.componentConfigFile = componentConfigFile;
        this.resourceBundleName = resourceBundleName;
        componentInfo = initComponentInfo();
    }


    /**
     * Initialize all info for this component encapsulated in a
     * {@link ComponentInfo} object, containing:
     * <OL>
     *  <LI>role,</LI>
     *  <LI>description,</LI>
     *  <LI>provider,</LI>
     *  <LI>author,</LI>
     * <LI>userDefined (optional),</LI>
     *  <LI>version.</LI>
     * </OL>
     *
     * @return all info for this component
     */
    protected abstract ComponentInfo initComponentInfo();


    /**
     * Inits the {@link ComponentInfo#role} info for this component. Has to be
     * overridden in subclasses.
     */
    protected abstract String initRoleInfo();


    /**
     * Inits the {@link ComponentInfo#description} info for this component. Has to be
     * overridden in subclasses.
     */
    protected abstract String initDescriptionInfo();


    /**
     * Inits the {@link ComponentInfo#provider} info for this component. Has to be
     * overridden in subclasses.
     */
    protected abstract String initProviderInfo();


    /**
     * Inits the {@link ComponentInfo#author} info for this component. Has to be
     * overridden in subclasses.
     */
    protected abstract String initAuthorInfo();


    /**
     * Inits the {@link ComponentInfo#version} info for this component. Has to be
     * overridden in subclasses.
     */
    protected abstract Version initVersionInfo();


    /**
     * Inits the {@link ComponentInfo#userDefined} info for this component.
     * Has to be overridden in subclasses.
     */
    protected abstract Version initUserDefinedInfo();


    /**
     * Provides all info for this component encapsulated in a
     * {@link ComponentInfo} object, containing:
     * <OL>
     *  <LI>type,</LI>
     *  <LI>role,</LI>
     *  <LI>description,</LI>
     *  <LI>provider,</LI>
     *  <LI>author,</LI>
     *  <LI>userDefined (optional),</LI>
     *  <LI>version.</LI>
     * </OL>
     *
     * @return meta info for this plugin component
     */
    public ComponentInfo getComponentInfo(){
        return componentInfo;
    }


    /*
     * Lyfecycle method: starting the component by the container.
     * Does nothing by default but logging start, override if necessary.
     */
    public void start(){
        LOGGER.info("Starting component '" + getClass().getName() +  "'!\n" +  toString());
    }


    /*
     * Lyfecycle method: stopping the component by the container.
     * Does nothing by default but logging stop, override if necessary.
     */
    public void stop(){
        LOGGER.info("Stopping component '" + getClass().getName() +  "'!\n");
    }


    /**
     * Lyfecycle method: component disposal trigger by the container during which
     * the component will release consumed resources.
     * Does nothing by default but logging dispose, override if necessary.
     */
    public void dispose() {
        LOGGER.info("Disposing component '" + getClass().getName() +  "'!\n");
    }


    /*
     * Enables or disables all {@link javax.swing.Action}s in an {@link cbrcp.action.ActionHandler}.
     * Does nothing by default, override if necessary.
     *
     * @param actionHandlerName identifier of the {@link cbrcp.action.ActionHandler}
     */
  //  public void enableActionHandler(String actionHandlerName, boolean enable){}


    /*
     * Enables or disables an {@link javax.swing.Action} in an {@link cbrcp.action.ActionHandler}.
     * Does nothing by default, override if necessary.
     *
     * @param actionName  identifier of the {@link javax.swing.Action}
     * @param actionHandlerName identifier of the {@link cbrcp.action.ActionHandler}
     * @param enable <CODE>true</CODE> for enabled, <CODE>false</CODE> for disabled
     * @throws ActionNotFoundException thrown if action not found in {@link cbrcp.action.ActionHandler}
     */
/*    public void enableActionInActionHandler(String actionName,
                                            String actionHandlerName, boolean enable)
            throws ActionNotFoundException {
        Action a = (Action) actions.get(nameKey);
        if(a != null){
            a.setEnabled(enabled);
        }else{
            throw new ActionNotFoundException("setActionEnabled(...): Action with name key\"" + nameKey + "\" not found.");
        }
    }  */


    /**
     * String representation of this component containin all component info.
     * @return info for this component
     * @see {@link ComponentInfo}
     */
    public String toString(){
        String info = "";
        if(componentInfo != null){
            info = componentInfo.toString();
        }
        return info;
    }
}

