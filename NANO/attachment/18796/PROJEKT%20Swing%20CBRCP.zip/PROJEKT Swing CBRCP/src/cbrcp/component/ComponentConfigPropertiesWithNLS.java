package cbrcp.component;

import java.io.File;


/**
 * A properties handler for a CBRCP component which takes a lookup for a property
 * a in NLS file if property starts with character '$' .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:16 $, last change by: $Author: jens $
 */
class ComponentConfigPropertiesWithNLS extends ComponentConfigProperties{

    /** The NLS handler. */
    private ComponentNLS nls;

    /**
     * Constructor.
     */
    protected ComponentConfigPropertiesWithNLS(File componentConfigFile, ComponentNLS nls) {
        super(componentConfigFile);
        this.nls = nls;
    }


    /**
     * Getter for the component property value.
     *
     * @param key for the component property value
     * @return the component property value
     */
    protected final String getProperty(String key) {
        String value = properties.getProperty(key);
        if(value.startsWith("$")){    // check if property is defined in NLS
            return nls.getMessage(value.substring(1));
        }else{
            return value;
        }
    }
}