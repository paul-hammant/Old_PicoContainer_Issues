package cbrcp.component.action;

import cbrcp.action.ActionHandler;
import cbrcp.action.DuplicateActionHandlerNameException;
import cbrcp.action.ActionHandlerDoesNotExistException;


/**
 * An interface for components or objects managing {@link cbrcp.action.ActionHandler}s.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public interface ActionHandlerManagerComponent {

    /** Role name for the component. */
    public static final String ROLE = ActionHandlerManagerComponent.class.getName();

    /**
     * Adds an {@link cbrcp.action.ActionHandler} to the component or object.
     * @param handler the {@link cbrcp.action.ActionHandler} to add
     * @throws cbrcp.action.DuplicateActionHandlerNameException thrown if the {@link cbrcp.action.ActionHandler}
     *         is already contained
     */
    public void addActionHandler(ActionHandler handler)
        throws DuplicateActionHandlerNameException;


    /**
     * Reactivates an {@link cbrcp.action.ActionHandler} from the component or object.
     * @param actionHandlerName identifies the {@link cbrcp.action.ActionHandler}
     * @throws cbrcp.action.ActionHandlerDoesNotExistException thrown if the an
     *         {@link cbrcp.action.ActionHandler} with the passed name is not managed
     */
    public void reactivateActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException;


    /**
     * Supends an {@link cbrcp.action.ActionHandler} from the component or object.
     * @param actionHandlerName identifies the {@link cbrcp.action.ActionHandler}
     * @throws cbrcp.action.ActionHandlerDoesNotExistException thrown if the an
     *         {@link cbrcp.action.ActionHandler} with the passed name is not managed
     */
    public void suspendActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException;


    /**
     * Removes an {@link cbrcp.action.ActionHandler} from the component or object.
     * @param actionHandlerName identifies the {@link cbrcp.action.ActionHandler}
     * @throws cbrcp.action.ActionHandlerDoesNotExistException thrown if the an
     *         {@link cbrcp.action.ActionHandler} with the passed name is not managed
     */
    public void removeActionHandler(String actionHandlerName)
        throws ActionHandlerDoesNotExistException;
}
