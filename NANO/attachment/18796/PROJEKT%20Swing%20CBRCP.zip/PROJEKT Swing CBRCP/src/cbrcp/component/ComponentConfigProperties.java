package cbrcp.component;

import java.util.Properties;
import java.util.logging.Logger;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.File;


/**
 * A configuration properties handler for a {@link CBRCPComponent}.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.2 $, $Date: 2006/01/19 12:32:16 $, last change by: $Author: jens $
 */
class ComponentConfigProperties {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(ComponentConfigProperties.class.getName());

    /** The component configuration properties. */
    protected Properties properties;

    /** The component's configuration {@link File}. */
    protected File componentConfigFile;


    /**
     * Constructor.
     */
    protected ComponentConfigProperties(File componentConfigFile) {
        properties = new Properties();
        this.componentConfigFile = componentConfigFile;
        try {
            properties.load(new FileInputStream(componentConfigFile));
        }catch(IOException e) {
            LOGGER.severe("IOException while loading config settings for component '" + getClass().getName() + "' !");
        }
    }


    /**
     * Getter for the component property value.
     *
     * @param key for the component property value
     * @return the component property value
     */
    protected String getProperty(String key) {
        return properties.getProperty(key);
    }

    /**
     * Setter for the component property value.
     *
     * @param key for the component property value
     * @param value the component property value
     */
    protected final void setProperty(String key, String value) {
        properties.setProperty(key, value);
        try{
            FileOutputStream out = new FileOutputStream(componentConfigFile);
            properties.store(out, null);
        }catch(IOException e){
            LOGGER.severe("IOException while saving config settings for component '" + getClass().getName() + "' !");
        }
    }
}
