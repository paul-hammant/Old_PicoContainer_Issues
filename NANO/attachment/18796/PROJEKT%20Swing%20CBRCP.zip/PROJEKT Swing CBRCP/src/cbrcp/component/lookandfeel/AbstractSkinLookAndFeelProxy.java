package cbrcp.component.lookandfeel;

import java.util.Vector;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class AbstractSkinLookAndFeelProxy extends AbstractLookAndFeelProxy{

    private static final String[] SKIN_THEMES= new String[]{
            "",
            ""
    };

    private static Vector<ThemeProxy> THEME_PROXIES = new Vector<ThemeProxy>(SKIN_THEMES.length);

    static{
        for(int i = 0; i < SKIN_THEMES.length; i++ ){
            THEME_PROXIES.add(new ThemeProxy(SKIN_THEMES[i], AbstractPlasticLookAndFeelProxy.class));
        }
    }

    public AbstractSkinLookAndFeelProxy(String name) {
        super(name, new Vector<ThemeProxy>(THEME_PROXIES));
    }
}
