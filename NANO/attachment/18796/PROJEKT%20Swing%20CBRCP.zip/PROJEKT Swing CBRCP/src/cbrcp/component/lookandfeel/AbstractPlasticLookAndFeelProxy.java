package cbrcp.component.lookandfeel;

import java.util.Vector;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class AbstractPlasticLookAndFeelProxy extends AbstractLookAndFeelProxy {

    private static final String[] LOOKS_THEMES= new String[]{
            "com.jgoodies.looks.plastic.theme.BrownSugar",
            "com.jgoodies.looks.plastic.theme.DarkStar",
            "com.jgoodies.looks.plastic.theme.DesertBlue",
            "com.jgoodies.looks.plastic.theme.DesertBluer",
            "com.jgoodies.looks.plastic.theme.DesertGreen",
            "com.jgoodies.looks.plastic.theme.DesertRed",
            "com.jgoodies.looks.plastic.theme.DesertYellow",
            "com.jgoodies.looks.plastic.theme.ExperienceBlue",
            "com.jgoodies.looks.plastic.theme.ExperienceBlueDefaultFont",
            "com.jgoodies.looks.plastic.theme.ExperienceGreen",
            "com.jgoodies.looks.plastic.theme.InvertedColorTheme",
            "com.jgoodies.looks.plastic.theme.Silver",
            "com.jgoodies.looks.plastic.theme.SkyBlue",
            "com.jgoodies.looks.plastic.theme.SkyBluer",
            "com.jgoodies.looks.plastic.theme.SkyBluerTahoma",
            "com.jgoodies.looks.plastic.theme.SkyGreen",
            "com.jgoodies.looks.plastic.theme.SkyKrupp",
            "com.jgoodies.looks.plastic.theme.SkyPink",
            "com.jgoodies.looks.plastic.theme.SkyRed",
            "com.jgoodies.looks.plastic.theme.SkyYellow"
    };

    private static Vector<ThemeProxy> THEME_PROXIES = new Vector<ThemeProxy>(LOOKS_THEMES.length);

    static{
        for(int i = 0; i < LOOKS_THEMES.length; i++ ){
            THEME_PROXIES.add(new ThemeProxy(LOOKS_THEMES[i], AbstractPlasticLookAndFeelProxy.class));
        }
    }

    public AbstractPlasticLookAndFeelProxy(String name) {
        super(name, makeDeepVectorCopy(THEME_PROXIES));
    }

    // TODO Wieder raus, scheint nciht zu bringen
    static Vector<ThemeProxy> makeDeepVectorCopy(Vector<ThemeProxy> toCopy){
        Vector<ThemeProxy> newVector = new Vector<ThemeProxy>(toCopy.size());
        for(ThemeProxy toCopyProxy : toCopy){
            newVector.add(new ThemeProxy(toCopyProxy));
        }
        return newVector;
    }
}
