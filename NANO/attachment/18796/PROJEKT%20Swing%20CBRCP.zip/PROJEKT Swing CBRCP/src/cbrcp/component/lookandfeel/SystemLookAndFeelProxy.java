package cbrcp.component.lookandfeel;

/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
class SystemLookAndFeelProxy extends AbstractLookAndFeelProxy {


    public SystemLookAndFeelProxy() {
        super(LookAndFeelConfigurationModel.getSystemLookAndFeelClassName());
    }
}
