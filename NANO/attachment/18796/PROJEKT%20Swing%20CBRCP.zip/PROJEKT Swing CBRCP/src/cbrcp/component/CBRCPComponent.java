package cbrcp.component;

import java.util.EventListener;

import org.picocontainer.Startable;
import org.picocontainer.Disposable;

import cbrcp.component.info.ComponentInfo;


/**
 * This is the interface for all components.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.8 $, $Date: 2004/10/27 17:13:01 $, last change by: $Author$
 */
public interface CBRCPComponent
extends EventListener, Startable, Disposable{


    /**
     * Provides all info for this component encapsulated in a
     * {@link ComponentInfo} object, containing:
     * <OL>
     *  <LI>role,</LI>
     *  <LI>description,</LI>
     *  <LI>provider,</LI>
     *  <LI>author,</LI>
     *  <LI>version.</LI>
     * </OL>
     *
     * @return info for this component
     */
    public ComponentInfo getComponentInfo();


    /*
     * Enables or disables all {@Action Action}s in an {@ActionHandler ActionHandler}.
     *
     * @param actionHandlerName identifier of the {@ActionHandler ActionHandler}
     */
//    public void enableActionHandler(String actionHandlerName, boolean enable);


    /*
     * Enables or disables an {@Action Action} in an {@ActionHandler ActionHandler}.
     *
     * @param actionName  identifier of the {@Action Action}
     * @param actionHandlerName identifier of the {@ActionHandler ActionHandler}
     * @param enable <CODE>true</CODE> for enabled, <CODE>false</CODE> for disabled
     * @throws ActionNotFoundException thrown if action not found in {@ActionHandler ActionHandler}
     */
/*    public void enableActionInActionHandler(String actionName,
                                            String actionHandlerName, boolean enable)
            throws ActionNotFoundException;    */

}
