package cbrcp.component.statusbar.separator;

import java.awt.Graphics2D;
import java.awt.SystemColor;

import java.util.logging.Logger;


/**
 * This class paints a Windows XP L&amp;F "line" separator (etched points).
 *
 * @author  <A href="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision: 1.3 $, $Date: 2006/01/19 14:35:04 $, last change by: $Author: jens $
 */
public class SeparatorXPLookAndFeelPainter extends AbstractLineSeparatorPainter {

    /** JDK logging. */
    private final static Logger LOGGER = Logger.getLogger(SeparatorXPLookAndFeelPainter.class.getName());

    private static final int OFFSET = 3;

    /** Creates a new instance of <CODE>DragAreaXPLookAndFeelPainter</CODE>. */
    public SeparatorXPLookAndFeelPainter() {
        super(OFFSET);
    }


    protected void drawLine(Graphics2D g2, int x, int y){
        g2.setColor(SystemColor.controlLtHighlight);
        g2.drawLine(x + 1, y + 1, x + 2, y + 1);
        g2.drawLine(x + 1, y + 2, x + 2, y + 2);
        g2.setColor(SystemColor.controlShadow);
        g2.drawLine(x, y, x + 1, y);
        g2.drawLine(x, y + 1, x + 1, y + 1);
    }
}
