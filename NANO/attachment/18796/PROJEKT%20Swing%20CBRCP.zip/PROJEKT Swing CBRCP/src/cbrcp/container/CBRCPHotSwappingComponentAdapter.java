package cbrcp.container;

import org.picocontainer.defaults.CachingComponentAdapter;
import org.picocontainer.defaults.ConstructorInjectionComponentAdapter;
import org.picocontainer.Parameter;
import org.picocontainer.ComponentAdapter;
import org.picocontainer.gems.adapters.HotSwappingComponentAdapter;


/**
 * {@link CBRCPHotSwappingComponentAdapter} is a {@link HotSwappingComponentAdapter} wrapping a
 * {@link CachingComponentAdapter} wrapping a {@link ConstructorInjectionComponentAdapter}.
 *
 * @author Jens Krefeldt
 * @version @version $Revision$, $Date$, last change by: $Author$
 */
public class CBRCPHotSwappingComponentAdapter extends HotSwappingComponentAdapter {

    /**
     * This constructor passes a {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory}
     * wrapping a {@link org.picocontainer.defaults.CachingComponentAdapter}
     * to super class {@link HotSwappingComponentAdapter}.
     * @see org.picocontainer.defaults.CachingComponentAdapter
     * @see org.picocontainer.defaults.ConstructorInjectionComponentAdapter
     * @see org.picocontainer.gems.adapters.HotSwappingComponentAdapterFactory
     */
    public CBRCPHotSwappingComponentAdapter(ComponentAdapter delegate) {
        super(delegate);
    }

    /**
     * This constructor passes a {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory}
     * wrapping a {@link org.picocontainer.defaults.CachingComponentAdapter}
     * to super class {@link HotSwappingComponentAdapter}.
     * @param componentKey the search key for this implementation
     * @param componentImplementation the concrete implementation
     * @see org.picocontainer.defaults.CachingComponentAdapter
     * @see org.picocontainer.defaults.ConstructorInjectionComponentAdapter
     * @see org.picocontainer.gems.adapters.HotSwappingComponentAdapterFactory
     */
    public CBRCPHotSwappingComponentAdapter(Object componentKey, Class componentImplementation) {
        this(componentKey, componentImplementation, null);
    }


    /**
     * This constructor passes a {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory}
     * wrapping a {@link org.picocontainer.defaults.CachingComponentAdapter}
     * to super class {@link HotSwappingComponentAdapter}.
     * @param componentKey the search key for this implementation
     * @param componentImplementation the concrete implementation
     * @param parameters the parameters to use for the initialization
     * @see org.picocontainer.defaults.CachingComponentAdapter
     * @see org.picocontainer.defaults.ConstructorInjectionComponentAdapter
     * @see org.picocontainer.gems.adapters.HotSwappingComponentAdapterFactory
     */
    public CBRCPHotSwappingComponentAdapter(Object componentKey, Class componentImplementation, Parameter[] parameters) {
        super(new CachingComponentAdapter(
                new ConstructorInjectionComponentAdapter(
                        componentKey, componentImplementation, parameters)));
    }
}
