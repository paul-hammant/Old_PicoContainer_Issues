package cbrcp.container;

import org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory;
import org.picocontainer.defaults.CachingComponentAdapterFactory;


/**
 * {@link cbrcp.container.CBRCPCachingComponentAdapterFactory} is a
 * {@link org.picocontainer.defaults.CachingComponentAdapterFactory}
 * wrapping a {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory}.
 *
 * @author Jens Krefeldt
 * @version @version $Revision$, $Date$, last change by: $Author$
 */
public class CBRCPCachingComponentAdapterFactory extends CachingComponentAdapterFactory {

    /**
     * Default constructor passes a {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory}
     * to super class {@link org.picocontainer.defaults.CachingComponentAdapterFactory}.
     * @see {@link org.picocontainer.defaults.CachingComponentAdapterFactory}
     * @see {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory}
     */
    public CBRCPCachingComponentAdapterFactory() {
        super(new ConstructorInjectionComponentAdapterFactory());
    }
}
