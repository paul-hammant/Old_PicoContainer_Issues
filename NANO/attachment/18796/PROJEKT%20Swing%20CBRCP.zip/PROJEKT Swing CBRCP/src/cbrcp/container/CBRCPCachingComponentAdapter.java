package cbrcp.container;

import org.picocontainer.defaults.CachingComponentAdapter;
import org.picocontainer.defaults.ConstructorInjectionComponentAdapter;
import org.picocontainer.Parameter;

/**
 * {@link cbrcp.container.CBRCPCachingComponentAdapter} is a
 * {@link org.picocontainer.defaults.CachingComponentAdapter} wrapping a
 * {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapter}.
 *
 * @author Jens Krefeldt
 * @version @version $Revision$, $Date$, last change by: $Author$
 */
public class CBRCPCachingComponentAdapter extends CachingComponentAdapter {

    /**
     * This constructor passes a {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory}
     * wrapping a {@link org.picocontainer.defaults.CachingComponentAdapter}
     * to super class {@link org.nanocontainer.proxytoys.HotSwappingComponentAdapter}.
     * @param componentKey the search key for this implementation
     * @param componentImplementation the concrete implementation
     * @see {@link org.picocontainer.defaults.CachingComponentAdapter}
     * @see {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapter}
     */
    public CBRCPCachingComponentAdapter(Object componentKey, Class componentImplementation) {
        this(componentKey, componentImplementation, null);
    }


    /**
     * This constructor passes a {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory}
     * wrapping a {@link org.picocontainer.defaults.CachingComponentAdapter}
     * to super class {@link org.nanocontainer.proxytoys.HotSwappingComponentAdapter}.
     * @param componentKey the search key for this implementation
     * @param componentImplementation the concrete implementation
     * @param parameters the parameters to use for the initialization
     * @see {@link org.picocontainer.defaults.CachingComponentAdapter}
     * @see {@link org.picocontainer.defaults.ConstructorInjectionComponentAdapter}
     */
    public CBRCPCachingComponentAdapter(Object componentKey, Class componentImplementation, Parameter[] parameters) {
        super(new ConstructorInjectionComponentAdapter(
                        componentKey, componentImplementation, parameters));
    }
}
