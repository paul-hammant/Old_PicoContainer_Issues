package cbrcp.container;

import org.picocontainer.defaults.ComponentAdapterFactory;
import org.picocontainer.PicoContainer;

import java.util.logging.Logger;


/**
 * The CBRCP default container class is dummy implementation to start only the
 * CBRCP core system.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class CBRCPDefaultContainer extends CBRCPAbstractContainer {

    /** JDK logging. */
    protected final static Logger LOGGER = Logger.getLogger(CBRCPDefaultContainer.class.getName());


    /**
     * Creates a new container with a (caching) DefaultComponentAdapterFactory
     * and no parent container.
     */
    public CBRCPDefaultContainer(){
        super();
    }


    /**
     * Creates a new container with a custom ComponentAdapterFactory and no
     * parent container.
     *
     * @param componentAdapterFactory
     */
    public CBRCPDefaultContainer(ComponentAdapterFactory componentAdapterFactory){
        this(componentAdapterFactory, null);
    }


    /**
     * Creates a new container with a (caching) DefaultComponentAdapterFactory
     * and a parent container.
     *
     * @param parent
     */
    public CBRCPDefaultContainer(PicoContainer parent){
        this(new CBRCPHotSwappingComponentAdapterFactory(), parent);
    }


    /**
     * Creates a new container with a custom ComponentAdapterFactory and a
     * parent container.
     *
     * @param componentAdapterFactory
     * @param parent
     */
    public CBRCPDefaultContainer(ComponentAdapterFactory componentAdapterFactory,
                                 PicoContainer parent){
        super(componentAdapterFactory, parent);
    }


    /**
     * Does nothing, so only core system is started.
     */
    public void setupUserDefinedComponents(){
        //
    }
}
