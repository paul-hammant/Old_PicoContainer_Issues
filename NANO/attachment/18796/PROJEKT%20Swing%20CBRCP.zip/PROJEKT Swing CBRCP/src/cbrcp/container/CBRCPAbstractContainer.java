package cbrcp.container;

import org.picocontainer.defaults.ComponentAdapterFactory;
import org.picocontainer.defaults.ConstantParameter;
import org.picocontainer.defaults.ComponentParameter;
import org.picocontainer.defaults.DefaultPicoContainer;
import org.picocontainer.ComponentAdapter;
import org.picocontainer.PicoContainer;
import org.picocontainer.Parameter;

import java.util.logging.Logger;

import cbrcp.component.frame.FrameComponent;
import cbrcp.component.frame.FrameComponentImpl;
import cbrcp.component.action.ActionHandlerManagerComponent;
import cbrcp.component.action.ActionHandlerManagerComponentImpl;
import cbrcp.component.menubar.MenuBarComponent;
import cbrcp.component.menubar.MenuBarComponentImpl;
import cbrcp.component.toolbar.ToolBarComponent;
import cbrcp.component.toolbar.ToolBarComponentImpl;
import cbrcp.component.statusbar.StatusBarComponent;
import cbrcp.component.statusbar.StatusBarComponentImpl;
import cbrcp.component.lookandfeel.LookAndFeelManagerComponent;
import cbrcp.component.lookandfeel.LookAndFeelManagerComponentImpl;
import cbrcp.component.config.ConfigComponent;
import cbrcp.component.config.ConfigComponentImpl;


/**
 * The CBRCP abstract container class organizes and setups its subcontainers and
 * its components. Subclasses have to implement {@link #setupUserDefinedComponents()}
 * to setup additional components.
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$, last change by: $Author$
 */
public abstract class CBRCPAbstractContainer extends DefaultPicoContainer {//CachingPicoContainer {

    /** JDK logging. */
    protected final static Logger LOGGER = Logger.getLogger(CBRCPAbstractContainer.class.getName());


    /**
     * Creates a new container with a {@link CBRCPHotSwappingComponentAdapterFactory}
     * and no parent container.
     */
    public CBRCPAbstractContainer(){
        this(new CBRCPHotSwappingComponentAdapterFactory());
    }


    /**
     * Creates a new container with a custom ComponentAdapterFactory and no
     * parent container.
     *
     * @param componentAdapterFactory
     */
    public CBRCPAbstractContainer(ComponentAdapterFactory componentAdapterFactory){
        this(componentAdapterFactory, null);
    }


    /**
     * Creates a new container with a {@link CBRCPHotSwappingComponentAdapterFactory}
     * and a parent container.
     *
     * @param parent
     */
    public CBRCPAbstractContainer(PicoContainer parent){
        this(new CBRCPHotSwappingComponentAdapterFactory(), parent);
    }


    /**
     * Creates a new container with a custom ComponentAdapterFactory and a
     * parent container.
     *
     * @param componentAdapterFactory
     * @param parent
     */
    public CBRCPAbstractContainer(ComponentAdapterFactory componentAdapterFactory,
                                  PicoContainer parent){
        super(componentAdapterFactory, parent);
    }


    /**
     * Starts this container. Called initially at the begin of the lifecycle. It
     * can be called again after a stop. Overridden to setup all user defined
     * components during start.
     * @see {@link org.picocontainer.Startable#start()}
     */
    public final void start(){
        setupCoreComponents();
        setupUserDefinedComponents();
        super.start();
    }


    /**
     * Sets up all CBRCP core components. This method is called
     * by the {@link #start()} method.
     */
    private void setupCoreComponents(){
        ComponentAdapter lookAndFeelManagerAdapter = new CBRCPCachingComponentAdapter(
                           LookAndFeelManagerComponent.ROLE,
                           LookAndFeelManagerComponentImpl.class, new Parameter[]{
                                new ComponentParameter(FrameComponent.ROLE),
                                new ComponentParameter(ConfigComponent.ROLE),
                                new ConstantParameter("./component-config/lookandfeel-component.properties")});
        registerComponent(lookAndFeelManagerAdapter);

        ComponentAdapter statusBarAdapter = new CBRCPCachingComponentAdapter(
                StatusBarComponent.ROLE, StatusBarComponentImpl.class,
                new Parameter[]{new ConstantParameter("./component-config/statusbar-component.properties")});
        registerComponent(statusBarAdapter);

        ComponentAdapter menuBarAdapter = new CBRCPCachingComponentAdapter(
                MenuBarComponent.ROLE, MenuBarComponentImpl.class,
                new Parameter[]{new ConstantParameter("./component-config/menubar-component.properties")});
        registerComponent(menuBarAdapter);
        
        ComponentAdapter toolBarAdapter = new CBRCPCachingComponentAdapter(
                ToolBarComponent.ROLE, ToolBarComponentImpl.class,
                new Parameter[]{new ConstantParameter("./component-config/toolbar-component.properties")});
        registerComponent(toolBarAdapter);

        ComponentAdapter frameAdapter = new CBRCPHotSwappingComponentAdapter(FrameComponent.ROLE,
                           FrameComponentImpl.class, new Parameter[]{
                                new ComponentParameter(MenuBarComponent.ROLE),
                                new ComponentParameter(ToolBarComponent.ROLE),
                                new ComponentParameter(StatusBarComponent.ROLE),
                                new ComponentParameter(ActionHandlerManagerComponent.ROLE),
                                new ConstantParameter("./component-config/frame-component.properties")});
        registerComponent(frameAdapter);
        ComponentAdapter actionHandlerManagerAdapter = new CBRCPHotSwappingComponentAdapter(
                           ActionHandlerManagerComponent.ROLE,
                           ActionHandlerManagerComponentImpl.class, new Parameter[]{
                                new ComponentParameter(FrameComponent.ROLE),
                                new ComponentParameter(MenuBarComponent.ROLE),
                                new ComponentParameter(ToolBarComponent.ROLE),
                                new ConstantParameter("./component-config/action-component.properties")});
        registerComponent(actionHandlerManagerAdapter);

        ComponentAdapter configAdapter = new CBRCPCachingComponentAdapter(
                                ConfigComponent.ROLE, ConfigComponentImpl.class,
                                new Parameter[]{
                                        new ComponentParameter(FrameComponent.ROLE),
                                        new ComponentParameter(ActionHandlerManagerComponent.ROLE),
                                        new ConstantParameter(
                                "./component-config/config-component.properties")});
        registerComponent(configAdapter);
    }


    /**
     * Sets up all user defined subcontainers and components used in CBRCP.
     * This method is called by the {@link #start()} method.
     */
    protected abstract void setupUserDefinedComponents();

}
