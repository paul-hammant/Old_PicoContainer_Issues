package cbrcp.container;

import org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory;
import org.picocontainer.defaults.CachingComponentAdapterFactory;
import org.picocontainer.gems.adapters.HotSwappingComponentAdapterFactory;


/**
 * {@link CBRCPHotSwappingComponentAdapterFactory} is a {@link HotSwappingComponentAdapterFactory}
 * wrapping a {@link CachingComponentAdapterFactory}
 * wrapping a {@link ConstructorInjectionComponentAdapterFactory}.
 *
 * @author Jens Krefeldt
 * @version @version $Revision$, $Date$, last change by: $Author$
 */
public class CBRCPHotSwappingComponentAdapterFactory extends HotSwappingComponentAdapterFactory {

    /**
     * Default constructor passes a{@link CachingComponentAdapterFactory}
     * wrapping a {@link ConstructorInjectionComponentAdapterFactory}
     * to super class {@link HotSwappingComponentAdapterFactory}.
     * @see org.picocontainer.defaults.CachingComponentAdapterFactory
     * @see org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory
     * @see org.picocontainer.gems.adapters.HotSwappingComponentAdapterFactory
     */
    public CBRCPHotSwappingComponentAdapterFactory() {
        super(new CachingComponentAdapterFactory(
                new ConstructorInjectionComponentAdapterFactory()));
    }
}
