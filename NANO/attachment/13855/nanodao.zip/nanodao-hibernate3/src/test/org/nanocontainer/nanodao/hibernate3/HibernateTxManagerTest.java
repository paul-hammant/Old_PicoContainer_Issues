package org.nanocontainer.nanodao.hibernate3;

import junit.framework.TestCase;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;
import org.nanocontainer.hibernate3.SessionDelegator;

/**
 * Test and shows the logic behind the HibernateTxManager.
 */
public class HibernateTxManagerTest extends MockObjectTestCase {

    public void testInnerTransaction() {

        Mock sessionMocker = mock(Session.class);
        ForTestingSakeSessionDelegator sessionDelegator = new ForTestingSakeSessionDelegator((Session) sessionMocker.proxy());

        // test the constructor which has to begin an transaction.
        sessionMocker.expects(once()).method("beginTransaction").will(returnValue(transactionThatWillBeRollbacked()));
        HibernateTxManager txManager = new HibernateTxManager(sessionDelegator);

        // Status: 1 transaction pending.

        // test begin
        sessionMocker.reset();
        sessionMocker.expects(once()).method("beginTransaction").will(returnValue(transactionThatWillBeRollbacked()));
        txManager.begin();

        // Status: 2 transactions pending.

        // test cancel() when it has a inner transaction
        sessionMocker.reset();
        txManager.cancel();

        // Status: 1 transaction pending

        // test cancel when it has no inner transaction. It must open a new
        // transaction since its canceling the last pending transaction.
        sessionMocker.reset();
        sessionMocker.expects(once()).method("beginTransaction").will(returnValue(transactionThatWillBeCommitted()));
        txManager.cancel();

        // Status: Still 1 transaction pending, since the last cancel() opened a
        // new transaction.

        // begin a new transaction in order to test root and inner transaction
        // end.
        sessionMocker.reset();
        sessionMocker.expects(once()).method("beginTransaction").will(returnValue(transactionThatWillBeCommitted()));
        txManager.begin();

        // Status: 2 transactions pending

        // test end() when it has a inner transaction
        sessionMocker.reset();
        txManager.end();

        // Status: 1 transaction pending

        // test end() when it has no inner transaction. It must open a new
        // transaction since its comminting the last pending transaction.
        sessionMocker.reset();
        sessionMocker.expects(once()).method("beginTransaction").will(returnValue(transactionThatWillBeCommitted()));
        txManager.end();

        // Status: Still 1 transaction pending, since the last end() opened a
        // new transaction.

        // Open some transaction and test stop() which should commit all pending
        // transactions.
        sessionMocker.reset();
        sessionMocker.expects(once()).method("beginTransaction").will(returnValue(transactionThatWillBeCommitted()));
        sessionMocker.expects(once()).method("beginTransaction").will(returnValue(transactionThatWillBeCommitted()));
        sessionMocker.expects(once()).method("beginTransaction").will(returnValue(transactionThatWillBeCommitted()));
        sessionMocker.expects(once()).method("beginTransaction").will(returnValue(transactionThatWillBeCommitted()));
        txManager.begin();
        txManager.begin();
        txManager.begin();
        txManager.begin();

        txManager.stop();
    }

    private Transaction transactionThatWillBeCommitted() {
        Mock transactionThatWillBeCommitted = mock(Transaction.class);
        transactionThatWillBeCommitted.expects(once()).method("commit");
        return (Transaction) transactionThatWillBeCommitted.proxy();
    }

    private Transaction transactionThatWillBeRollbacked() {
        Mock transactionThatWillBeRollbacked = mock(Transaction.class);
        transactionThatWillBeRollbacked.expects(once()).method("rollback");
        return (Transaction) transactionThatWillBeRollbacked.proxy();
    }

    class ForTestingSakeSessionDelegator extends SessionDelegator {
        private Session session;

        public ForTestingSakeSessionDelegator(Session session) {
            this.session = session;
        }

        public Session getSession() {
            return this.session;
        }

        public void invalidateSession() throws HibernateException {
            TestCase.fail("It should never happen.");
        }
    }

}
