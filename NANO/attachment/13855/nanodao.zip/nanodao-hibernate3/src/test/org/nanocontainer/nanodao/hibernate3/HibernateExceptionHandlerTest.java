package org.nanocontainer.nanodao.hibernate3;

import org.hibernate.ObjectDeletedException;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.QueryException;
import org.hibernate.StaleObjectStateException;
import org.hibernate.UnresolvableObjectException;
import org.hibernate.WrongClassException;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;
import org.nanocontainer.nanodao.ExceptionFactory;

/**
 * Test and shows the logic behind the HibernateExceptionHandler.
 */
public class HibernateExceptionHandlerTest extends MockObjectTestCase {

    private static final RuntimeException RUNTIME_EXCEPTION = new RuntimeException();

    private static final String ANY_STRING = "ANY_STRING_OR_SERIALIZABLE_VALUE";

    /**
     * Test if HibernateExceptionHandler is handling optimistic locking
     * properly.
     * 
     * WATCH OUT! When you run this test it will print a stack trace on jUnit
     * console. Its because StaleObjectStateException call System.out to print
     * it. I've already write an issue to Hibernate team, hope soon they'll fix
     * it.
     */
    public void testHandlingOptimisticLocking() throws Exception {
        Mock exceptionFactoryMocker = mock(ExceptionFactory.class);

        exceptionFactoryMocker.expects(once()).method("createOptimisticLockingException").withAnyArguments().will(returnValue(RUNTIME_EXCEPTION));
        HibernateExceptionHandler heh = new HibernateExceptionHandler((ExceptionFactory) exceptionFactoryMocker.proxy());
        heh.handle(new StaleObjectStateException(ANY_STRING, ANY_STRING));
    }

    /**
     * Test if HibernateExceptionHandler is handling object retrieval failure
     * properly.
     */
    public void testHandlingObjectRetrievalFailure() throws Exception {
        Mock exceptionFactoryMocker = mock(ExceptionFactory.class);

        exceptionFactoryMocker.expects(once()).method("createObjectRetrievalFailureException").withAnyArguments().will(returnValue(RUNTIME_EXCEPTION));
        exceptionFactoryMocker.expects(once()).method("createObjectRetrievalFailureException").withAnyArguments().will(returnValue(RUNTIME_EXCEPTION));
        exceptionFactoryMocker.expects(once()).method("createObjectRetrievalFailureException").withAnyArguments().will(returnValue(RUNTIME_EXCEPTION));
        exceptionFactoryMocker.expects(once()).method("createObjectRetrievalFailureException").withAnyArguments().will(returnValue(RUNTIME_EXCEPTION));

        HibernateExceptionHandler heh = new HibernateExceptionHandler((ExceptionFactory) exceptionFactoryMocker.proxy());

        heh.handle(new UnresolvableObjectException(ANY_STRING, ANY_STRING));
        heh.handle(new ObjectDeletedException(ANY_STRING, ANY_STRING, ANY_STRING));
        heh.handle(new ObjectNotFoundException(ANY_STRING, ANY_STRING));
        heh.handle(new WrongClassException(ANY_STRING, ANY_STRING, ANY_STRING));
    }

    /**
     * Test if HibernateExceptionHandler is handling query exceptions properly.
     */
    public void testHandlingQueryException() {
        Mock exceptionFactoryMocker = mock(ExceptionFactory.class);

        exceptionFactoryMocker.expects(once()).method("createQueryException").withAnyArguments().will(returnValue(RUNTIME_EXCEPTION));
        HibernateExceptionHandler heh = new HibernateExceptionHandler((ExceptionFactory) exceptionFactoryMocker.proxy());
        heh.handle(new QueryException(ANY_STRING, ANY_STRING));
    }

    /**
     * Test if HibernateExceptionHandler is handling unknown cases properly.
     */
    public void testUnknownCase() {
        Mock exceptionFactoryMocker = mock(ExceptionFactory.class);

        // If it handles an unknown RuntimeException it must be returned.
        HibernateExceptionHandler heh = new HibernateExceptionHandler((ExceptionFactory) exceptionFactoryMocker.proxy());
        RuntimeException e = new RuntimeException();
        assertSame(e, heh.handle(e));

        // If it handles an unknown non RuntimeException it must call
        // UnknownException and return its results.
        exceptionFactoryMocker.reset();
        Exception nonRuntimeException = new Exception();
        exceptionFactoryMocker.expects(once()).method("createUnknownException").with(this.same(nonRuntimeException)).will(returnValue(RUNTIME_EXCEPTION));
        heh = new HibernateExceptionHandler((ExceptionFactory) exceptionFactoryMocker.proxy());
        heh.handle(nonRuntimeException);
    }

}
