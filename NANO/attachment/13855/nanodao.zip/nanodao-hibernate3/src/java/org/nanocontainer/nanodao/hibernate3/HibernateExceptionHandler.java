package org.nanocontainer.nanodao.hibernate3;

import org.hibernate.QueryException;
import org.hibernate.StaleObjectStateException;
import org.hibernate.UnresolvableObjectException;
import org.hibernate.WrongClassException;
import org.nanocontainer.nanodao.ExceptionFactory;
import org.nanocontainer.nanodao.ExceptionHandler;

/**
 * Implementation of nanodao's ExceptionHandler for Hibernate 3. See
 * org.nanocontainer.nanodao.ExceptionHandler for more details.
 * 
 * @see org.nanocontainer.nanodao.ExceptionHandler
 * 
 * @author Jose Peleteiro
 * @version $Revision$ <$Date$>
 */
public class HibernateExceptionHandler implements ExceptionHandler {

    private ExceptionFactory exceptionFactory;

    public HibernateExceptionHandler(ExceptionFactory exceptionFactory) {
        this.exceptionFactory = exceptionFactory;
    }

    public RuntimeException handle(Exception ex) {
        
        // Optimistic locking cases.
        if (ex instanceof StaleObjectStateException) {
            StaleObjectStateException e = (StaleObjectStateException) ex;
            return this.exceptionFactory.createOptimisticLockingException(e.getPersistentClass(), e.getIdentifier());
        }

        // Object retrieval failure cases.
        if (ex instanceof UnresolvableObjectException) {
            UnresolvableObjectException e = (UnresolvableObjectException) ex;
            return this.exceptionFactory.createObjectRetrievalFailureException(e.getPersistentClass(), e.getIdentifier());
        }

        if (ex instanceof WrongClassException) {
            WrongClassException e = (WrongClassException) ex;
            return this.exceptionFactory.createObjectRetrievalFailureException(e.getPersistentClass(), e.getIdentifier());
        }

        // Query exception cases.
        if (ex instanceof QueryException) {
            QueryException e = (QueryException) ex;
            return this.exceptionFactory.createQueryException();
        }

        // if (ex instanceof PersistentObjectException) {
        // means InvalidDataAccessApiUsageException?
        // }
        //
        // if (ex instanceof TransientObjectException) {
        // means InvalidDataAccessApiUsageException?
        // }

        // Unknown cases.
        
        // If the unknown exception is a RuntimeException type, just return it
        // back.
        if (ex instanceof RuntimeException) {
            return (RuntimeException) ex;
        }

        // Otherwise, return an UnknowException kind.
        return this.exceptionFactory.createUnknownException(ex);
    }

}