package org.nanocontainer.nanodao.hibernate3;

import java.util.EmptyStackException;
import java.util.Stack;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.nanocontainer.nanodao.TxManager;
import org.picocontainer.Startable;

/**
 * Implementation of nanodao's TxManager for Hibernate 3. See
 * org.nanocontainer.nanodao.TxManager for more details.
 * 
 * It's an Startable component, at start it has nothing to do but at stop, it
 * commits all opened transaction of its session.
 * 
 * It must be registred in the container after Session since it should stop
 * before the session.
 * 
 * @see org.nanocontainer.nanodao.ExceptionHandler
 * 
 * @author Jose Peleteiro
 * @version $Revision$ <$Date$>
 */
public class HibernateTxManager implements TxManager, Startable {

    private Session session;

    private Stack transactionStack = new Stack();

    public HibernateTxManager(Session session) {
        this.session = session;
        this.transactionStack.push(session.beginTransaction());
    }

    /**
     * @see org.nanocontainer.nanodao.TxManager#begin()
     */
    public void begin() {
        this.transactionStack.push(this.session.beginTransaction());
    }

    /**
     * @see org.nanocontainer.nanodao.TxManager#cancel()
     */
    public void cancel() {
        Transaction transaction = (Transaction) this.transactionStack.pop();
        transaction.rollback();

        // Make sure that there always one transaction open.
        if (this.transactionStack.size() == 0) {
            this.begin();
        }
    }

    /**
     * @see org.nanocontainer.nanodao.TxManager#end()
     */
    public void end() {
        Transaction transaction = (Transaction) this.transactionStack.pop();
        transaction.commit();

        // Make sure that there always one transaction open.
        if (this.transactionStack.size() == 0) {
            this.begin();
        }
    }

    /**
     * Do nothing.
     */
    public void start() {
    }

    /**
     * Commit all pending transactions.
     */
    public void stop() {
        Transaction transaction;
        try {
            while (true) {
                transaction = (Transaction) this.transactionStack.pop();
                transaction.commit();
            }
        } catch (EmptyStackException e) {
            // Do nothing. It is what we were wating for.
        }
    }

}
