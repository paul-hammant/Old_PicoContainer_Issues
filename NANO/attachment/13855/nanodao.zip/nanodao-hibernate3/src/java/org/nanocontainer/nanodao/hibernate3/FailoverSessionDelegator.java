package org.nanocontainer.nanodao.hibernate3;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.nanocontainer.nanodao.ExceptionHandler;

/**
 * Pretty same as org.nanocontainer.hibernate3.FailoverSessionDelegator but it
 * handles hibernate exceptions using an ExceptionHandler component.
 * 
 * @see org.nanocontainer.hibernate3.FailoverSessionDelegator
 * @see org.nanocontainer.nanodao.ExceptionHandler
 * 
 * @author Jose Peleteiro <juzepeleteiro@intelli.biz>
 * @version $Revision: 1.0 $
 */
public class FailoverSessionDelegator extends org.nanocontainer.hibernate3.FailoverSessionDelegator {

    private ExceptionHandler exceptionHandler;

    public FailoverSessionDelegator(SessionFactory sessionFactory, ExceptionHandler exceptionHandler) {
        super(sessionFactory);
        this.exceptionHandler = exceptionHandler;
    }

    public RuntimeException handleException(HibernateException cause) throws HibernateException {
        return this.exceptionHandler.handle(cause);
    }
}
