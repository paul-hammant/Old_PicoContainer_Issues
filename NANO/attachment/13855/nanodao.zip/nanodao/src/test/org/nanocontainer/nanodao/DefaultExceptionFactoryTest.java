package org.nanocontainer.nanodao;

import org.nanocontainer.nanodao.e.ObjectRetrievalFailureException;
import org.nanocontainer.nanodao.e.OptimisticLockingException;
import org.nanocontainer.nanodao.e.QueryException;
import org.nanocontainer.nanodao.e.UnknownException;

import junit.framework.TestCase;

public class DefaultExceptionFactoryTest extends TestCase {

    public void testCreates() throws Exception {
        final String ANYTHING = "anything";
        final Exception ANY_EXCEPTION = new Exception();

        ExceptionFactory ef = new DefaultExceptionFactory();

        assertTrue("Method createObjectRetrievalFailureException of DefaultExceptionFactory fails.", ef.createObjectRetrievalFailureException(ANYTHING, ANYTHING) instanceof ObjectRetrievalFailureException);
        assertTrue("Method createOptimisticLockingException of DefaultExceptionFactory fails.", ef.createOptimisticLockingException(ANYTHING, ANYTHING) instanceof OptimisticLockingException);
        assertTrue("Method createQueryException of DefaultExceptionFactory fails.", ef.createQueryException() instanceof QueryException);
        assertTrue("Method createUnknowException of DefaultExceptionFactory fails.", ef.createUnknownException(ANY_EXCEPTION) instanceof UnknownException);
    }

}
