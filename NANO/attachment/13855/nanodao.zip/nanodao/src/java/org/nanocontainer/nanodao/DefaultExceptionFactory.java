package org.nanocontainer.nanodao;

import java.io.Serializable;

import org.nanocontainer.nanodao.e.ObjectRetrievalFailureException;
import org.nanocontainer.nanodao.e.OptimisticLockingException;
import org.nanocontainer.nanodao.e.QueryException;
import org.nanocontainer.nanodao.e.UnknownException;

/**
 * It is a factory for the nanodao defaults exceptions (package
 * org.nanocontainer.nanodao.e).
 * 
 * @see ExceptionFactory
 * @see org.nanocontainer.nanodao.e
 * 
 * @author Jose Peleteiro <juzepeleteiro@intelli.biz>
 * @version $Revision: 1.0 $
 */
public class DefaultExceptionFactory implements ExceptionFactory {

    /**
     * @return org.nanocontainer.nanodao.e.OptimisticLockingException
     */
    public RuntimeException createOptimisticLockingException(String type, Serializable id) {
        return new OptimisticLockingException(type, id);
    }

    /**
     * @return org.nanocontainer.nanodao.e.ObjectRetrievalFailureException
     */
    public RuntimeException createObjectRetrievalFailureException(String type, Serializable id) {
        return new ObjectRetrievalFailureException(type, id);
    }

    /**
     * @return org.nanocontainer.nanodao.e.QueryException
     */
    public RuntimeException createQueryException() {
        return new QueryException();
    }

    /**
     * @return org.nanocontainer.nanodao.e.UnknowException
     */
    public RuntimeException createUnknownException(Throwable cause) {
        return new UnknownException(cause);
    }

}
