package org.nanocontainer.nanodao;

/**
 * It handles your persistent engines exceptions and return a user known
 * exception.
 * 
 * It must use ExceptionFactory in order to create an exception instance.
 * 
 * @see ExceptionFactory
 * 
 * @author Jose Peleteiro <juzepeleteiro@intelli.biz>
 * @version $Revision: 1.0 $
 */
public interface ExceptionHandler {

    /**
     * Handles your persistent engine exceptions and return a user known
     * exception.
     */
    public RuntimeException handle(Exception e);

}
