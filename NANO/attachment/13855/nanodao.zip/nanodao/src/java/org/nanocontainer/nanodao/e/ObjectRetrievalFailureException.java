package org.nanocontainer.nanodao.e;

import java.io.Serializable;


/**
 * @author Jose Peleteiro <juzepeleteiro@intelli.biz>
 * @version $Revision: 1.0 $
 */
public class ObjectRetrievalFailureException extends BaseException {

    public ObjectRetrievalFailureException(String type, Serializable id) {
    }
    
}
