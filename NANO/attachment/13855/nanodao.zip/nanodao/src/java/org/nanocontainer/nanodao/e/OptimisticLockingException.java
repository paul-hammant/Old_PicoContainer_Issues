package org.nanocontainer.nanodao.e;

import java.io.Serializable;


/**
 * @author Jose Peleteiro <juzepeleteiro@intelli.biz>
 * @version $Revision: 1.0 $
 */
public class OptimisticLockingException extends BaseException {

    public OptimisticLockingException(String type, Serializable id) {
    }
    
}
