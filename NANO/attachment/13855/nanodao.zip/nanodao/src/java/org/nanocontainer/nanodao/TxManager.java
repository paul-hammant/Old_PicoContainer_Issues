package org.nanocontainer.nanodao;

/**
 * Manages the user transaction. This is how the users see our transaction with
 * no knowledge if its hibernate, jdo or whatever. The users just ask pico for
 * TxManager.
 * 
 * There is always an transaction opened that will be commited when container
 * stop. But if you need you can begin inner transaction.
 * 
 * @author Jose Peleteiro <juzepeleteiro@intelli.biz>
 * @version $Revision: 1.0 $
 */
public interface TxManager {

    /**
     * Begins a new transaction inside the current transaction (Since there is
     * always one transaction opened).
     */
    public void begin();

    /**
     * Cancel the current transaction, if its the root transaction it opens a
     * fresh new transaction.
     */
    public void cancel();

    /**
     * Commit the current transaction, if its the root trasaction it opens a
     * fresh new transaction.
     */
    public void end();

}
