package org.nanocontainer.nanodao.e;

/**
 * @author Jose Peleteiro <juzepeleteiro@intelli.biz>
 * @version $Revision: 1.0 $
 */
public class BaseException extends RuntimeException {

    public BaseException() {
    }

    public BaseException(Throwable cause) {
        super(cause);
    }

}
