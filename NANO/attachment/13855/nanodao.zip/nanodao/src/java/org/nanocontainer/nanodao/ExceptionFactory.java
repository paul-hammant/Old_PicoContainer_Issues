package org.nanocontainer.nanodao;

import java.io.Serializable;

/**
 * This component creates your defined exceptions for each case. It must be used
 * for ExceptionHandler in order to create exception.
 * 
 * @see ExceptionHandler
 * 
 * @author Jose Peleteiro <juzepeleteiro@intelli.biz>
 * @version $Revision: 1.0 $
 */
public interface ExceptionFactory {

    public RuntimeException createOptimisticLockingException(String type, Serializable id);

    public RuntimeException createObjectRetrievalFailureException(String type, Serializable id);

    public RuntimeException createQueryException();

    public RuntimeException createUnknownException(Throwable cause);

}
