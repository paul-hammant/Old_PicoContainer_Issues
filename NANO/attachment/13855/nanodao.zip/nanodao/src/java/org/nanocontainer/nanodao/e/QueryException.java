package org.nanocontainer.nanodao.e;


/**
 * @author Jose Peleteiro <juzepeleteiro@intelli.biz>
 * @version $Revision: 1.0 $
 */
public class QueryException extends BaseException {

}
