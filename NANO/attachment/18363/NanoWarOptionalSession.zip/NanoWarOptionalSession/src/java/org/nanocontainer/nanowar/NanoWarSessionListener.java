/*****************************************************************************
 * Copyright (C) NanoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the LICENSE.txt file.                                                     *
 *                                                                           *
 *****************************************************************************/

package org.nanocontainer.nanowar;

import javax.servlet.http.HttpSessionListener;
import javax.servlet.http.HttpSessionEvent;
import org.nanocontainer.integrationkit.ContainerComposer;
import javax.servlet.http.HttpSession;
import org.picocontainer.defaults.ObjectReference;
import org.nanocontainer.integrationkit.ContainerBuilder;
import javax.servlet.http.HttpSessionBindingEvent;
import org.picocontainer.defaults.SimpleReference;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionBindingListener;
import java.io.Serializable;

/**
 * Allow the session listener.  This creates Session Level containers.
 * <p>
 * To use, simply add as a listener to web.xml the listener-class
 * <code>org.nanocontainer.nanowar.NanoWarSessionListener</code>.
 * </p>
 * <p><strong>Warning</strong> Session-Level containers can be problematic on
 * many fronts including persisted sessions, clustering, etc (as of 12/28/05).
 * </p>
 * @author Michael Rimov
 * @author Joe Walnes
 * @author Aslak Helles&oslash;y
 * @author Philipp Meier
 * @author Paul Hammant
 * @author Mauro Talevi
 * @author Konstantin Pribluda
 */
public class NanoWarSessionListener extends AbstractNanoListener implements HttpSessionListener, KeyConstants {

    public static final String KILLER_HELPER = "KILLER_HELPER";
    public static final String CONTAINER_COMPOSER = ContainerComposer.class.getName();
    public static final String CONTAINER_COMPOSER_CONFIGURATION = CONTAINER_COMPOSER + ".configuration";

    public NanoWarSessionListener() {
        super();
    }

    private ContainerBuilder getBuilder(ServletContext context) {
        ObjectReference assemblerRef = new ApplicationScopeObjectReference(context, BUILDER);
        return (ContainerBuilder) assemblerRef.get();
    }

    public void sessionCreated(HttpSessionEvent event) {
        HttpSession session = event.getSession();
        ServletContext context = session.getServletContext();
        ContainerBuilder containerBuilder = getBuilder(context);
        ObjectReference sessionContainerRef = new SessionScopeObjectReference(session, SESSION_CONTAINER);
        ObjectReference webappContainerRef = new ApplicationScopeObjectReference(context, APPLICATION_CONTAINER);
        containerBuilder.buildContainer(sessionContainerRef, webappContainerRef, session, false);

        session.setAttribute(KILLER_HELPER, new SessionContainerKillerHelper() {
            public void valueBound(HttpSessionBindingEvent bindingEvent) {
                HttpSession session = bindingEvent.getSession();
                containerRef = new SimpleReference();
                containerRef.set(new SessionScopeObjectReference(session, SESSION_CONTAINER).get());
            }

            public void valueUnbound(HttpSessionBindingEvent event) {
                try {
                    killContainer(containerRef);
                } catch (IllegalStateException e) {
                    //
                    //Some servlet containers (Jetty) call contextDestroyed(ServletContextEvent event)
                    //and then afterwards call valueUnbound(HttpSessionBindingEvent event).

                    //contextDestroyed will kill the top level (app level) pico container which will
                    //cascade stop() down to the session children.

                    //This means that when valueUnbound is called later, the session level container will
                    //already be stopped.
                    //
                }
            }
        });


    }

    public void sessionDestroyed(HttpSessionEvent se) {
        // no implementation - session scoped container killed by SessionContainerKillerHelper
    }


    private abstract class SessionContainerKillerHelper implements HttpSessionBindingListener, Serializable {
        transient SimpleReference containerRef;
    }
}
