/*****************************************************************************
 * Copyright (C) NanoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the LICENSE.txt file.                                                     *
 *                                                                           *
 *****************************************************************************/

package org.nanocontainer.nanowar;

import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.Enumeration;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.nanocontainer.DefaultNanoContainer;
import org.nanocontainer.NanoContainer;
import org.nanocontainer.integrationkit.ContainerBuilder;
import org.nanocontainer.integrationkit.ContainerComposer;
import org.nanocontainer.integrationkit.DefaultLifecycleContainerBuilder;
import org.nanocontainer.integrationkit.PicoCompositionException;
import org.nanocontainer.script.ScriptBuilderResolver;
import org.nanocontainer.script.ScriptedContainerBuilderFactory;
import org.picocontainer.ComponentAdapter;
import org.picocontainer.Parameter;
import org.picocontainer.PicoContainer;
import org.picocontainer.defaults.ConstantParameter;
import org.picocontainer.defaults.ObjectReference;
import org.picocontainer.defaults.SimpleReference;

/**
 * Split apart the context-level listaner.  Originally a portion of ServletContainerListener.
 * Include this listener if you want application-level services to be managed by
 * NanoWAR.
 * Allow the session listener.  This creates Session Level containers.
 * <p>
 * To use, simply add as a listener to web.xml the listener-class
 * <code>org.nanocontainer.nanowar.NanoWarContextListener</code>.
 * </p>
 * <p><strong>Warning</strong> Session-Level containers can be problematic on
 * many fronts including persisted sessions, clustering, etc (as of 12/28/05).
 * </p>
 * @author Michael Rimov
 * @author Joe Walnes
 * @author Aslak Helles&oslash;y
 * @author Philipp Meier
 * @author Paul Hammant
 * @author Mauro Talevi
 * @author Konstantin Pribluda
 */
public class NanoWarContextListener extends AbstractNanoListener implements ServletContextListener,KeyConstants {

    public static final String NANOCONTAINER_PREFIX = "nanocontainer";

    public static final String CONTAINER_COMPOSER = ContainerComposer.class.getName();

    public static final String CONTAINER_COMPOSER_CONFIGURATION = CONTAINER_COMPOSER + ".configuration";


    public NanoWarContextListener() {
        super();
    }

    public void contextInitialized(ServletContextEvent event) {
        ServletContext context = event.getServletContext();
        try {
            ContainerBuilder containerBuilder = createContainerBuilder(context);

            ObjectReference builderRef = new ApplicationScopeObjectReference(context, BUILDER);
            builderRef.set(containerBuilder);

            ObjectReference containerRef = new ApplicationScopeObjectReference(context, APPLICATION_CONTAINER);
            containerBuilder.buildContainer(containerRef, new SimpleReference(), context, false);
        } catch (Exception e) {
            // Not all servlet containers print the nested exception. Do it here.
            event.getServletContext().log(e.getMessage(), e);
            throw new PicoCompositionException(e);
        }
    }

    private ContainerBuilder createContainerBuilder(ServletContext context) throws ClassNotFoundException {
        Enumeration initParameters = context.getInitParameterNames();
        while (initParameters.hasMoreElements()) {
            String initParameter = (String) initParameters.nextElement();
            if (initParameter.startsWith(NANOCONTAINER_PREFIX)) {
                String builderClassName = getBuilderClassName(initParameter);
                String script = context.getInitParameter(initParameter);
                Reader scriptReader;
                if (script.trim().startsWith("/") && !(script.trim().startsWith("//") || script.trim().startsWith("/*"))) {
                    // the script isn't inlined, but in a separate file.
                    scriptReader = new InputStreamReader(context.getResourceAsStream(script));
                } else {
                    scriptReader = new StringReader(script);
                }
                ScriptedContainerBuilderFactory scriptedContainerBuilderFactory = new ScriptedContainerBuilderFactory(scriptReader, builderClassName, Thread.currentThread().getContextClassLoader());
                return scriptedContainerBuilderFactory.getContainerBuilder();
            }
            if (initParameter.equals(CONTAINER_COMPOSER)) {
                ContainerComposer containerComposer = createContainerComposer(context);
                return new DefaultLifecycleContainerBuilder(containerComposer);
            }
        }
        throw new PicoCompositionException("Couldn't create a builder from context parameters in web.xml");
    }

    private String getBuilderClassName(String scriptName){
        String extension = scriptName.substring(scriptName.lastIndexOf('.'));
        ScriptBuilderResolver resolver = new ScriptBuilderResolver();
        return resolver.getBuilderClassName(extension);
    }

    private ContainerComposer createContainerComposer(ServletContext context) throws ClassNotFoundException{
        String containerComposerClassName = context.getInitParameter(CONTAINER_COMPOSER);
        // disposable container used to instantiate the ContainerComposer
        NanoContainer nanoContainer = new DefaultNanoContainer(Thread.currentThread().getContextClassLoader());
        String script = context.getInitParameter(CONTAINER_COMPOSER_CONFIGURATION);
        PicoContainer picoConfiguration = null;
        if ( script != null ){
            Reader scriptReader = new InputStreamReader(context.getResourceAsStream(script));
            String builderClassName = getBuilderClassName(script);
            ScriptedContainerBuilderFactory scriptedContainerBuilderFactory = new ScriptedContainerBuilderFactory(scriptReader, builderClassName, Thread.currentThread().getContextClassLoader());
            picoConfiguration = buildContainer(scriptedContainerBuilderFactory.getContainerBuilder());
        }
        ComponentAdapter componentAdapter = null;
        if ( picoConfiguration != null ){
            Parameter[] parameters = new Parameter[]{ new ConstantParameter(picoConfiguration) };
            componentAdapter = nanoContainer.registerComponentImplementation(containerComposerClassName, containerComposerClassName, parameters);
        } else {
            componentAdapter = nanoContainer.registerComponentImplementation(containerComposerClassName);
        }
        return (ContainerComposer) componentAdapter.getComponentInstance(nanoContainer.getPico());
    }

    public void contextDestroyed(ServletContextEvent event) {
        ServletContext context = event.getServletContext();
        ObjectReference containerRef = new ApplicationScopeObjectReference(context, APPLICATION_CONTAINER);
        killContainer(containerRef);
    }
}
