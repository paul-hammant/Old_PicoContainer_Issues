/*****************************************************************************
 * Copyright (C) NanoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the LICENSE.txt file.                                                     *
 *                                                                           *
 *****************************************************************************/
package org.nanocontainer.struts;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;

/**
 * Uses Pico to produce Actions and inject dependencies into them.  Only use this class if you are using
 * Struts 1.0.  If you are using Struts 1.1, use {@link PicoRequestProcessor} or {@link PicoTilesRequestProcessor}
 * instead.
 *
 * @author Stephen Molitor
 * @see ActionFactory
 * @see PicoRequestProcessor
 * @see PicoTilesRequestProcessor
 */
public class PicoActionServlet extends org.apache.struts.action.ActionServlet {

    private final ActionFactory actionFactory = new ActionFactory();

    /**
     * Creates or retrieves the action instance.  The action is retrieved from the actions
     * Pico container, using the mapping path as the component key.  If no such action exists,
     * a new one will be instantiated and placed in the actions container, thus injecting
     * its dependencies.
     *
     * @param mapping the action mapping.
     * @param request the HTTP request.
     * @return the action instance.
     */
    protected Action processActionCreate(ActionMapping mapping,
                                         HttpServletRequest request) {
        return actionFactory.getAction(request, mapping, this);
    }

}
