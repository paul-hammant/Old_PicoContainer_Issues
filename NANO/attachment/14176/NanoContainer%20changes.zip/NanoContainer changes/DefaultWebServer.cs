using System;
using System.Text;
using NUnit.Framework;

namespace NanoContainer.Test.TestModel
{
	/// <summary>
	/// Summary description for DefaultWebServer.
	/// </summary>
	public class DefaultWebServer : WebServer
	{
		public DefaultWebServer(WebServerConfig wsc)
		{
			Assert.IsNotNull(wsc.getHost());
			Assert.IsTrue(wsc.getPort()>0);
		}

		//PSANTOS new
		public DefaultWebServer(WebServerConfig wsc, StringBuilder sb)
		{
			Assert.IsTrue(wsc.getPort() > 0, "No port number specified");
			Assert.IsNotNull("No host name specified", wsc.getHost());
			sb.Append("-WebServer:" + wsc.getHost() + ":" + wsc.getPort());
		}
	}
}
