package org.nanocontainer.xml;

import org.picocontainer.PicoException;

/**
 * @author jcn
 */
public class XmlFrontEndException extends PicoException {

	/**
	 * 
	 */
	public XmlFrontEndException() {
		super();
	}

	/**
	 * @param message
	 */
	public XmlFrontEndException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public XmlFrontEndException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public XmlFrontEndException(String message, Throwable cause) {
		super(message, cause);
	}

}
