package org.nanocontainer.xml;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import junit.framework.TestCase;

import org.nanocontainer.testmodel.DefaultWebServerConfig;
import org.picocontainer.PicoContainer;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * @author Jeppe Cramon
 */
public class ParameterXmlFrontEndTest extends TestCase {
	
	private Element getRootElement(InputSource is) throws ParserConfigurationException, IOException, SAXException {
			return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is).getDocumentElement();
	}	

	/**
	 * Constructor for InputSourceFrontEndTest.
	 * @param arg0
	 */
	public ParameterXmlFrontEndTest(String arg0) {
		super(arg0);
	}

	public void testSingleDefaultContainer() throws ParameterInputSourceFrontEndException, EmptyXmlConfigurationException, IOException, SAXException, ClassNotFoundException, ParserConfigurationException {
		InputSource inputSource = new InputSource(new StringReader(
				"<container>" +
				"      <component classname='org.nanocontainer.testmodel.DefaultWebServerConfig'/>" +
				"      <component key='com.brf.solaise.testmodel.WebServer' classname='org.nanocontainer.testmodel.WebServerImpl'/>" +
				"</container>"));
		ParameterXmlFrontEnd inputSourceContainerFactory = new ParameterXmlFrontEnd();
		PicoContainer picoContainer = inputSourceContainerFactory.createPicoContainer(getRootElement(inputSource));
		assertNotNull(picoContainer.getComponentInstance(DefaultWebServerConfig.class));
	}

	public void testPicoInPico() throws ParameterInputSourceFrontEndException, EmptyXmlConfigurationException, IOException, SAXException, ClassNotFoundException, ParserConfigurationException {
		InputSource inputSource = new InputSource(new StringReader(
				"<container>" +
				"      <component classname='org.nanocontainer.testmodel.DefaultWebServerConfig'/>" +
				"      <container>" +
				"          <component key='org.nanocontainer.testmodel.WebServer' classname='org.nanocontainer.testmodel.WebServerImpl'/>" +
				"      </container>" +
				"</container>"));

		ParameterXmlFrontEnd inputSourceContainerFactory = new ParameterXmlFrontEnd();
		PicoContainer rootContainer = inputSourceContainerFactory.createPicoContainer(getRootElement(inputSource));
		assertNotNull(rootContainer.getComponentInstance(DefaultWebServerConfig.class));

		PicoContainer childContainer = (PicoContainer) rootContainer.getChildContainers().iterator().next();
		assertNotNull(childContainer.getComponentInstance("org.nanocontainer.testmodel.WebServer"));
	}

	public void testSingleDefaultContainerWithParams() throws ParameterInputSourceFrontEndException, EmptyXmlConfigurationException, IOException, SAXException, ClassNotFoundException, ParserConfigurationException {
		InputSource inputSource = new InputSource(new StringReader(
				"<container classname='org.nanocontainer.jmx.NanoMXContainer'>" +
				"      <component classname='org.nanocontainer.testmodel.DefaultWebServerConfig'>" +
				"		 <parameter classname='String'>localhost</parameter>" + 		
				"		 <parameter classname='int'>8080</parameter>" + 		
				"      </component>" + 
				"      <component key='org.nanocontainer.testmodel.WebServer' classname='org.nanocontainer.testmodel.WebServerImpl'/>" +
				"</container>"));
		ParameterXmlFrontEnd inputSourceContainerFactory = new ParameterXmlFrontEnd();
		PicoContainer picoContainer = inputSourceContainerFactory.createPicoContainer(getRootElement(inputSource));
		assertNotNull(picoContainer.getComponentInstance(DefaultWebServerConfig.class));
		DefaultWebServerConfig config = (DefaultWebServerConfig) picoContainer.getComponentInstance(DefaultWebServerConfig.class);
		assertEquals("localhost", config.getHost());
		assertEquals(8080, config.getPort());
	}
}
