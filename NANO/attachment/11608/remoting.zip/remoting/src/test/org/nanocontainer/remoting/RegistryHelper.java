package org.nanocontainer.remoting;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.RemoteException;

/**
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1.3 $
 */
public class RegistryHelper {
    private static Registry registry;

    public static Registry getRegistry() {
        return registry;
    }

    static {
        try {
            registry = LocateRegistry.createRegistry(9877);
        } catch (RemoteException e) {
        }
    }



}