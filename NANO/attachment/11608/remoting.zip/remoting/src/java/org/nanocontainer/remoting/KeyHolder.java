package org.nanocontainer.remoting;

/**
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1.3 $
 */
public interface KeyHolder {
    ByRefKey getKey();
}