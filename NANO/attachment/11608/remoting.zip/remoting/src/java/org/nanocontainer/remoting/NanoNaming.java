/*
 * Created by IntelliJ IDEA.
 * User: ahelleso
 * Date: 09-Mar-2004
 * Time: 14:23:47
 */
package org.nanocontainer.remoting;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.io.Serializable;

public interface NanoNaming extends Remote {
    Object lookup(ByRefKey key) throws RemoteException;
}