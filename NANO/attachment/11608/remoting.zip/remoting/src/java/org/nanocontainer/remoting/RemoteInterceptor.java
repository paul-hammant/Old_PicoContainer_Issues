/*
 * Created by IntelliJ IDEA.
 * User: ahelleso
 * Date: 02-Mar-2004
 * Time: 16:57:02
 */
package org.nanocontainer.remoting;

import org.nanocontainer.remoting.Invocation;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.AlreadyBoundException;
import java.lang.reflect.InvocationTargetException;

/**
 * @author Neil Clayton
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1.3 $
 */
public interface RemoteInterceptor extends Remote {
    Object invoke(Invocation invocation) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, RemoteException;
}