/*****************************************************************************
 * Copyright (C) NanoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the LICENSE.txt file.                                                     *
 *                                                                           *
 * Original code by Leo Simons                                               *
 *****************************************************************************/
package org.nanocontainer.bsh;

import java.util.Arrays;
import java.io.IOException;
import java.io.File;

import org.picocontainer.Parameter;
import org.picocontainer.ComponentAdapter;
import org.picocontainer.MutablePicoContainer;
import org.picocontainer.PicoInitializationException;
import org.picocontainer.PicoIntrospectionException;

import bsh.Interpreter;
import bsh.EvalError;

/**
 *
 *
 * @author <a href="mail at leosimons dot com">Leo Simons</a>
 * @version $Id: BeanShellComponentAdapter.java,v 1.2 2003/09/17 15:52:05 lsimons Exp $
 */
public class BeanShellComponentAdapter implements ComponentAdapter
{
    private Object m_componentKey;
    private Class m_componentImplementation;
    private Parameter[] m_parameters;

    public BeanShellComponentAdapter( Object componentKey, Class componentImplementation, Parameter[] parameters )
    {
        m_componentKey = componentKey;
        m_componentImplementation = componentImplementation;
        m_parameters = parameters;
    }

    public Object getComponentKey()
    {
        return m_componentKey;
    }

    public Class getComponentImplementation()
    {
        return m_componentImplementation;
    }

    public Object getComponentInstance( MutablePicoContainer picoContainer )
            throws PicoInitializationException, PicoIntrospectionException
    {
        BeanShellUtil util = new BeanShellUtil( picoContainer );

        try
        {
            Interpreter i = new Interpreter();
            i.set( "adapter", this );
            i.set( "container", picoContainer );
            i.set( "key", m_componentKey );
            i.set( "clazz", m_componentImplementation );
            i.set( "parameters", Arrays.asList( m_parameters ) );
            i.set( "util", util );
            i.eval( "import " + m_componentImplementation.getName() + ";" );
            i.source( getInitSource() );

            return i.get( "instance" );
        } catch( EvalError ee )
        {
            throw new BeanShellScriptInitializationException( ee );
        } catch( IOException e )
        {
            throw new BeanShellScriptInitializationException( e );
        }
    }

    protected String getInitSource()
    {
        String name =
                classNameToPathName( m_componentImplementation.getName() ) +
                 ".init.bsh";
        return name;
    }
    protected final static String classNameToPathName( String className )
    {
        String copy = className;
        while( copy.indexOf('.') != -1 )
            copy = copy.replace( '.', File.separatorChar );

        return copy;
    }

}
