/*****************************************************************************
 * Copyright (C) NanoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the LICENSE.txt file.                                                     *
 *                                                                           *
 * Original code by Leo Simons                                               *
 *****************************************************************************/
package org.nanocontainer.bsh;

import org.picocontainer.MutablePicoContainer;
import org.picocontainer.ComponentAdapter;

/**
 *
 *
 * @author <a href="mail at leosimons dot com">Leo Simons</a>
 * @version $Id: BeanShellUtil.java,v 1.2 2003/09/17 15:52:05 lsimons Exp $
 */
public class BeanShellUtil
{
    private MutablePicoContainer m_container;

    public BeanShellUtil( MutablePicoContainer container )
    {
        m_container = container;
    }

    public Object getInstance( Class clazz )
    {
        ComponentAdapter adapter = m_container.findComponentAdapter( clazz );
        return adapter.getComponentInstance( m_container );
    }
}
