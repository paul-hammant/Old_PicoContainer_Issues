package test;

import java.util.logging.Logger;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class BDependsOnAImpl implements BDependsOnA{

    private final static Logger LOGGER = Logger.getLogger(BDependsOnAImpl.class.getName());

    private ADependsOnB a;

    public BDependsOnAImpl(ADependsOnB a) {
        this.a = a;
    }

    public void start(){
        LOGGER.info("Starting component '" + getClass().getName() +  "'!");
        LOGGER.info(printA());
    }

    public void stop(){

    }

    public String printA(){
        return a.toString();
    }

    public String toString(){
        return PRINT_B;
    }

}
