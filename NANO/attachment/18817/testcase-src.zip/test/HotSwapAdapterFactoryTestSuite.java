package test;

import junit.framework.TestSuite;
import junit.framework.Test;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class HotSwapAdapterFactoryTestSuite extends TestSuite {

    private static final String FIRST_CAF =
                "   <component-adapter-factory key='factory' class='org.picocontainer.gems.adapters.HotSwappingComponentAdapterFactory'>"+
                "       <component-adapter-factory class='org.picocontainer.defaults.CachingComponentAdapterFactory'/>"+
                "       <component-adapter-factory class='org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory'/>"+
                "   </component-adapter-factory>";

    private static final String SECOND_CAF =
                "   <component-adapter-factory key='factory' class='org.picocontainer.gems.adapters.HotSwappingComponentAdapterFactory'>"+
                "       <component-adapter-factory class='org.picocontainer.defaults.CachingComponentAdapterFactory'>"+
                "           <component-adapter-factory class='org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory'/>"+
                "       </component-adapter-factory>" +
                "   </component-adapter-factory>";

    private static final String THIRD_CAF =
                "   <component-adapter-factory key='factory' class='org.picocontainer.defaults.CachingComponentAdapterFactory'>"+
                "       <component-adapter-factory class='org.picocontainer.gems.adapters.HotSwappingComponentAdapterFactory'>"+
                "           <component-adapter-factory class='org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory'/>"+
                "       </component-adapter-factory>" +
                "   </component-adapter-factory>";

    private static final String FOURTH_CAF =
                "   <component-adapter-factory key='factory' class='org.picocontainer.defaults.CachingComponentAdapterFactory'>"+
                "       <component-adapter-factory class='org.picocontainer.gems.adapters.HotSwappingComponentAdapterFactory'/>"+
                "       <component-adapter-factory class='org.picocontainer.defaults.ConstructorInjectionComponentAdapterFactory'/>"+
                "   </component-adapter-factory>";


    public HotSwapAdapterFactoryTestSuite() {
        // Nano
        addTest(new HotSwapAdapterFactoryTestCase(FIRST_CAF));
        addTest(new HotSwapAdapterFactoryTestCase(SECOND_CAF));
        addTest(new HotSwapAdapterFactoryTestCase(THIRD_CAF));
        addTest(new HotSwapAdapterFactoryTestCase(FOURTH_CAF));
    }


    public static Test suite() {
        return new HotSwapAdapterFactoryTestSuite();
    }
}
