/**
 * @author Jens Krefeldt
 * @version $Revision$
 */
package test;

import org.picocontainer.PicoContainer;
import org.picocontainer.PicoInitializationException;
import org.picocontainer.defaults.ObjectReference;
import org.picocontainer.defaults.SimpleReference;
import org.picocontainer.defaults.UnsatisfiableDependenciesException;
import org.nanocontainer.script.ScriptedContainerBuilder;
import org.nanocontainer.script.xml.XMLContainerBuilder;

import junit.framework.TestCase;

import java.io.Reader;
import java.io.StringReader;
import java.util.logging.Logger;


public class HotSwapAdapterFactoryTestCase extends TestCase {

    private final static Logger LOGGER = Logger.getLogger(HotSwapAdapterFactoryTestCase.class.getName());

    protected ObjectReference containerRef = new SimpleReference();
    protected ObjectReference parentContainerRef = new SimpleReference();

    protected Reader script;



    public HotSwapAdapterFactoryTestCase() {
        this(null);
    }

    /**
     * Constructs a test case with a nano script.
     */
    public HotSwapAdapterFactoryTestCase(String cafStr) {
        super();
        script = new StringReader(
                "<container>" +
                cafStr +
                "   <component-adapter key='test.ADependsOnB' class='test.ADependsOnBImpl' factory='factory'>" +
                "       <parameter key='test.BDependsOnA'>" +
                "           <class>test.BDependsOnAImpl</class>" +
                "       </parameter>" +
                "   </component-adapter>" +
                "   <component-adapter key='test.BDependsOnA' class='test.BDependsOnAImpl' factory='factory'>" +
                "       <parameter key='test.ADependsOnB'>" +
                "           <class>test.ADependsOnBImpl</class>" +
                "       </parameter>" +
                "   </component-adapter>" +
                "</container>");
    }


    public void runTest(){
        testHotSwappingCAF();
    }


    public void testHotSwappingCAF(){
        PicoContainer pico = null;
        try{
            pico = buildWithNanocontainer();
        }catch(UnsatisfiableDependenciesException e){
            fail("UnsatisfiableDependenciesException: " + e.getMessage());
        }catch(PicoInitializationException e){
            fail("PicoInitializationException: " + e.getMessage());
        }

        ADependsOnB a = (ADependsOnB) pico.getComponentInstance("test.ADependsOnB");
        assertNotNull(a);
        assertTrue(a.printB().equals(BDependsOnA.PRINT_B));
        BDependsOnA b = (BDependsOnA) pico.getComponentInstance("test.BDependsOnA");
        assertNotNull(b);
        assertTrue(b.printA().equals(ADependsOnB.PRINT_A));
    }


    private PicoContainer buildWithNanocontainer() {
        return buildContainer(new XMLContainerBuilder(script, getClass().getClassLoader()), null, "SOME_SCOPE");
    }


    protected PicoContainer buildContainer(ScriptedContainerBuilder builder, PicoContainer parentContainer, Object scope) {
        parentContainerRef.set(parentContainer);
        builder.buildContainer(containerRef, parentContainerRef, scope, true);
        return (PicoContainer) containerRef.get();
    }
}

