package test;

import org.picocontainer.Startable;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public interface ADependsOnB extends Startable {

    public static final String PRINT_A = "A depends on B";

    public String printB();

    public String toString();

}
