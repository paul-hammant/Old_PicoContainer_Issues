package test;

import java.util.logging.Logger;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public class ADependsOnBImpl implements ADependsOnB{

    private final static Logger LOGGER = Logger.getLogger(ADependsOnBImpl.class.getName());

    private BDependsOnA b;

    public ADependsOnBImpl(BDependsOnA b) {
        this.b = b;
    }

    public void start(){
        LOGGER.info("Starting component '" + getClass().getName() +  "'!");
        LOGGER.info(printB());
    }

    public String printB(){
        return b.toString();
    }

    public void stop(){

    }

    public String toString(){
        return PRINT_A;
    }

}
