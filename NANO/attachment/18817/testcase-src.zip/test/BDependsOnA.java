package test;

import org.picocontainer.Startable;


/**
 * .
 *
 * @author <A HREF="mailto:j.krefeldt@gmx.de">Jens Krefeldt</A>
 * @version $Revision$, $Date$, last change by: $Author$
 */
public interface BDependsOnA extends Startable {

    public static final String PRINT_B = "B depends on A";

    public String printA();

    public String toString();

}
