/*****************************************************************************
 * Copyright (C) NanoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the LICENSE.txt file.                                                     *
 *                                                                           *
 *****************************************************************************/
package org.nanocontainer.webwork2;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.nanocontainer.servlet.KeyConstants;
import org.nanocontainer.servlet.RequestScopeObjectReference;
import org.nanocontainer.servlet.ServletRequestContainerLauncher;
import org.picocontainer.PicoContainer;
import org.picocontainer.defaults.ObjectReference;

import com.opensymphony.webwork.dispatcher.ServletDispatcher;
import com.opensymphony.xwork.ObjectFactory;

/**
 * <p>
 * Extension to the standard WebWork2 ServletDispatcher that instantiates a new
 * container in the
 * {@link org.nanocontainer.webwork2.ThreadLocalContainerReference}for each
 * request and disposes of it correctly at the end of the request.
 * </p>
 * 
 * <p>
 * To use, replace the WebWork ServletDispatcher in web.xml with this.
 * </p>
 * 
 * @author <a href="mailto:joe@thoughtworks.net">Joe Walnes </a>
 * @author <a href="mailto:cleclerc@pobox.com">Cyrille Le Clerc </a>
 */
public class PicoServletDispatcher extends ServletDispatcher {

	/**
	 * TODO Should <code>containerReference</code> be instantiated in
	 * {@link ServletDispatcher#init(javax.servlet.ServletConfig)}to follow
	 * Servlet API spirit or should it be in the constructor for the
	 * <code>PicoServletDispatcher</code> to follow "Contructor Based
	 * Dependency Injection" pattern and have a component that is fully
	 * initialised in its contructor ?
	 *  
	 */
	public PicoServletDispatcher() {
		super();
		ObjectFactory picoObjectFactory = new PicoObjectFactory();
		ObjectFactory.setObjectFactory(picoObjectFactory);
	}

	/**
	 * @see javax.servlet.http.HttpServlet#service(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException {
		ServletRequestContainerLauncher containerLauncher = new ServletRequestContainerLauncher(
				getServletContext(), request);
		ObjectReference containerReference = new ThreadLocalContainerReference();
		try {
			containerLauncher.startContainer();

			/*
			 * Store the created container in a threadLocal to get it in the
			 * Object factory
			 * 
			 * TODO : should we update ServletRequestContainerLauncher and add a
			 * getContainerReference() accessor instead of using the
			 * RequestScopeObjectReference that is not as self explanatory
			 */
			ObjectReference requestContainerRef = new RequestScopeObjectReference(request,
					KeyConstants.REQUEST_CONTAINER);
			PicoContainer requestContainer = (PicoContainer) requestContainerRef.get();
			containerReference.set(requestContainer);

			// process the servlet using webwork2
			super.service(request, response);
		} catch (Exception e) {
			throw new ServletException(e);
		} finally {
			/*
			 * Note : setting to null is enough to free memory as threadLocal
			 * relies on threadLocal.ThreadLocalMap that uses WeakReferences to
			 * garbage references to Threads (that are internal keys)
			 */
			containerReference.set(null);
			try {
				containerLauncher.killContainer();
			} catch (Exception e) {
				throw new ServletException(e);
			}
		}
	}
}