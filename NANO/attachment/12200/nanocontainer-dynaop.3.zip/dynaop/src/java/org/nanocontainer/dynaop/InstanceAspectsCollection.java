/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import dynaop.Aspects;
import dynaop.ProxyFactory;

/**
 * Collection of <code>InstanceAspects</code> objects.
 * 
 * @author Stephen Molitor
 */
public class InstanceAspectsCollection {

    private final List instanceAspects = new ArrayList();

    /**
     * Adds another piece of advice to this collection.
     * 
     * @param advice
     *            the advice to add.
     */
    public void add(InstanceAspect advice) {
        instanceAspects.add(advice);
    }

    /**
     * Creates a proxy that applies the aspects to the target object.
     * 
     * @param target
     *            the target object to wrap.
     * @return the dynamically generated proxy.
     */
    public Object wrap(Object target) {
        Aspects aspects = new Aspects();
        Iterator iterator = instanceAspects.iterator();
        while (iterator.hasNext()) {
            InstanceAspect advice = (InstanceAspect) iterator.next();
            advice.apply(aspects);
        }
        return ProxyFactory.getInstance(aspects).wrap(target);
    }

}