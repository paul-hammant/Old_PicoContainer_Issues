/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import org.picocontainer.MutablePicoContainer;

import dynaop.Aspects;
import dynaop.ClassPointcut;
import dynaop.Interceptor;
import dynaop.MethodPointcut;

/**
 * Extends the <code>org.picocontainer.MutablePicoContainer</code> API with
 * methods for applying Dynaop aspects to container managed components.
 * <code>Dynaop</code> is almost (see below) the union of the
 * <code>org.picocontainer.MutablePicoContainer</code> and
 * <code>org.dynaop.Aspects</code> API's. In addition, <code>DynaPico</code>
 * provides methods for applying advice to just one container managed component
 * (the <code>component...</code> methods), methods for applying advice where
 * the advice object is supplied by the container (the
 * <code>containerSupplied...</code> methods), and methods for applying advice
 * to just one component, where the advice object itself is also supplied by the
 * container(the <code>containerSuppliedComponent...</code> methods).
 * <p>
 * <code>DynaPico</code> does narrow the Dynaop
 * <code>org.dynaop.Aspects</code> API slightly. <code>Aspects</code>
 * includes methods for creating mixin and interceptor advice using special
 * <code>org.dynaop.Closure</code> objects. These closures allow users to have
 * more control over the advice creation process - supplying dependencies to the
 * advice object, etc. But that's where Pico comes in. The
 * <code>containerSupplied...</code> methods remove the need for these closure
 * objects, so <code>DynaPico</code> does not include equivalents for the
 * <code>Aspects</code> methods that take closure objects as parameters.
 * However, the <code>getAspects</code> method does return a reference to the
 * actual <code>org.dynaop.Aspects</code> object being used, so you can always
 * use that reference directly if you do want to use <code>Aspects</code>
 * methods not also provided in the <code>DynaPico</code> API.
 * 
 * @author Stephen Molitor
 */
public interface DynaPico extends MutablePicoContainer {

    /**
     * Adds interfaces to components picked by pointcut.
     * 
     * @param classPointcut
     *            classes to add interfaces to.
     * @param interfaces
     *            the interfaces to add.
     */
    public void interfaces(ClassPointcut classPointcut, Class[] interfaces);

    /**
     * Applies interceptor advice to methods of components that are matched by
     * the pointcuts.
     * 
     * @param classPointcut
     *            picks target classes.
     * @param methodPointcut
     *            picks methods to add interceptor to.
     * @param interceptor
     *            the interceptor advice.
     */
    void interceptor(ClassPointcut classPointcut,
            MethodPointcut methodPointcut, Interceptor interceptor);

    /**
     * Applies mixin advice to components matched by the class pointcut.
     * 
     * @param classPointcut
     *            picks target classes.
     * @param interfaces
     *            interfaces that the mixin implements.
     * @param mixinClass
     *            the mixin implementation class.
     */
    void mixin(ClassPointcut classPointcut, Class[] interfaces, Class mixinClass);

    /**
     * Applies mixin advice to components matched by the class pointcut. This is
     * a convenience method that will use all interfaces implemented by the
     * mixin class.
     * 
     * @param classPointcut
     *            picks target classes.
     * @param mixinClass
     *            the mixin implementation class.
     */
    void mixin(ClassPointcut classPointcut, Class mixinClass);

    /**
     * Applies a container supplied interceptor to methods of components that
     * are matched by the pointcuts.
     * 
     * @param classPointcut
     *            picks target classes.
     * @param methodPointcut
     *            picks methods to add interceptor to.
     * @param interceptorComponentKey
     *            the key the interceptor advice was registered with.
     */
    void containerSuppliedInterceptor(ClassPointcut classPointcut,
            MethodPointcut methodPointcut, Object interceptorComponentKey);

    /**
     * Applies a container supplied mixin to components that are matched by the
     * pointcut.
     * 
     * @param classPointcut
     *            picks target classes.
     * @param interfaces
     *            interfaces that the mixin implements.
     * @param mixinComponentKey
     *            the key the mixin advice was registered with.
     */
    void containerSuppliedMixin(ClassPointcut classPointcut,
            Class[] interfaces, Object mixinComponentKey);

    /**
     * Applies interceptor advice to just one component.
     * 
     * @param componentKey
     *            the key the component was registered with.
     * @param methodPointcut
     *            picks methods to add interceptor to.
     * @param interceptor
     *            the interceptor advice.
     */
    void componentInterceptor(Object componentKey,
            MethodPointcut methodPointcut, Interceptor interceptor);

    /**
     * Applies mixin advice to just one component.
     * 
     * @param componentKey
     *            the key the component was registered with.
     * @param interfaces
     *            the interfaces that the mixin implements.
     * @param mixinClass
     *            the mixin implementation class.
     */
    void componentMixin(Object componentKey, Class[] interfaces,
            Class mixinClass);

    /**
     * Applies a container supplied interceptor to one component.
     * 
     * @param componentKey
     *            the key the component was registered with.
     * @param methodPointcut
     *            picks methods to add the interceptor to.
     * @param interceptorComponentKey
     *            the key the interceptor was registered with.
     */
    void containerSuppliedComponentInterceptor(Object componentKey,
            MethodPointcut methodPointcut, Object interceptorComponentKey);

    /**
     * Applies a container supplied mixin to one component.
     * 
     * @param componentKey
     *            the key the component was registered with.
     * @param interfaces
     *            the interfaces that the mixin implements.
     * @param mixinComponentKey
     *            the key the mixin was registered with.
     */
    void containerSuppliedComponentMixin(Object componentKey,
            Class[] interfaces, Object mixinComponentKey);

    /**
     * Gets the Dynaop <code>Aspects</code> object used to apply aspects to
     * components.
     * 
     * @return the object used to apply aspects to components in the container.
     */
    Aspects getAspects();

    /**
     * Gets the Pico container.
     * 
     * @return the Pico container instance.
     */
    MutablePicoContainer getPico();

}