/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import dynaop.Aspects;

/**
 * Aspect that applies to just one instance or component. Contains a set of
 * advice and the method pointcuts that the advice should apply to on the
 * component instance.
 * 
 * @author Stephen Molitor
 */
public interface InstanceAspect {

    /**
     * Applies the aspects.
     * 
     * @param aspects
     *            the Dynaop aspects instance used to apply the advice.
     */
    void apply(Aspects aspects);

}