/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import dynaop.Aspects;
import dynaop.Interceptor;
import dynaop.InterceptorFactory;
import dynaop.MethodPointcut;
import dynaop.Pointcuts;

/**
 * Interceptor advice that applies to just one component instance.
 * 
 * @author Stephen Molitor
 */
public class InstanceInterceptorAdvice implements InstanceAspect {

    private final MethodPointcut methodPointcut;
    private Interceptor interceptor;
    private InterceptorFactory interceptorFactory;

    /**
     * Creates a new <code>InstanceInterceptorAdvice</code> object.
     * 
     * @param methodPointcut
     *            the set of methods to intercept.
     * @param interceptor
     *            the interceptor object.
     */
    public InstanceInterceptorAdvice(MethodPointcut methodPointcut,
            Interceptor interceptor) {
        this.methodPointcut = methodPointcut;
        this.interceptor = interceptor;
    }

    /**
     * Creates a new <code>InstanceInterceptorAdvice</code> object.
     * 
     * @param methodPointcut
     *            the set of methods to intercept.
     * @param interceptorFactory
     *            the factory used to produce the interceptor object.
     */
    public InstanceInterceptorAdvice(MethodPointcut methodPointcut,
            InterceptorFactory interceptorFactory) {
        this.methodPointcut = methodPointcut;
        this.interceptorFactory = interceptorFactory;
    }

    public void apply(Aspects aspects) {
        if (interceptor != null) {
            aspects.interceptor(Pointcuts.ALL_CLASSES, methodPointcut,
                    interceptor);
        } else {
            aspects.interceptor(Pointcuts.ALL_CLASSES, methodPointcut,
                    interceptorFactory);
        }
    }

}