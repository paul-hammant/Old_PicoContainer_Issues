/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import java.io.Reader;

import org.nanocontainer.integrationkit.PicoCompositionException;
import org.nanocontainer.script.ScriptedContainerBuilder;
import org.picocontainer.PicoContainer;

import bsh.EvalError;
import bsh.Interpreter;
import dynaop.Pointcuts;

/**
 * Creates <code>PicoContainer</code> objects via BeanShell scripts and the
 * <code>DynaPico</code> API. A <code>DynaPico</code> object is imported
 * into the scripted under the name "dynaPico". The script uses the object to
 * configure the Pico container and apply Dynaop aspects to components in the
 * container. In addition, a covenient BeanShell script helper object is
 * imported, and other convenient syntatic sugar is applied, as desribed in the
 * Dynaop documention.
 * 
 * @author Stephen Molitor
 */
public class DynaPicoBeanShellContainerBuilder extends ScriptedContainerBuilder {

    /**
     * Creates new <code>DynaPicoBeanShellContainerBuilder</code> object.
     * 
     * @param script
     *            the script read.
     * @param classLoader
     *            the class loader used.
     */
    public DynaPicoBeanShellContainerBuilder(Reader script,
            ClassLoader classLoader) {
        super(script, classLoader);
    }

    protected PicoContainer createContainerFromScript(
            PicoContainer parentContainer, Object assemblyScope) {
        DynaPico dynaPico = new DefaultDynaPico(parentContainer);
        DynaPicoScriptHelper helper = new DynaPicoScriptHelper(dynaPico);

        Interpreter i = new Interpreter();
        try {
            i.set("parent", parentContainer);
            i.set("assemblyScope", assemblyScope);
            i.set("dynaPico", dynaPico);
            i.set("$_helper", helper);
            i.eval("importObject($_helper);");

            i.eval("import dynaop.*;");
            i.eval("static import " + Pointcuts.class.getName() + ".*;");

            i.eval(script, i.getNameSpace(), "nanocontainer.bsh");
            dynaPico = (DynaPico) i.get("dynaPico");
            return dynaPico.getPico();
        } catch (EvalError e) {
            throw new PicoCompositionException(e);
        }
    }

}