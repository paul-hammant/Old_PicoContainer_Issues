/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;

import org.apache.oro.text.regex.MalformedPatternException;
import org.picocontainer.ComponentAdapter;
import org.picocontainer.Parameter;
import org.picocontainer.PicoContainer;
import org.picocontainer.PicoIntrospectionException;
import org.picocontainer.PicoRegistrationException;
import org.picocontainer.PicoVerificationException;

import dynaop.Aspects;
import dynaop.ClassPointcut;
import dynaop.Interceptor;
import dynaop.InterceptorFactory;
import dynaop.MethodPointcut;
import dynaop.MixinFactory;
import dynaop.bsh.BshHelper;
import dynaop.util.Closure;

/**
 * Syntactic sugar for DynaPico BeanShell scripts. Used by
 * <code>DynaPicoBeanShellContainerBuilder</code>.
 * 
 * @author Stephen Molitor
 */
public class DynaPicoScriptHelper {

    private final DynaPico dynaPico;
    private final BshHelper bshHelper;

    /**
     * Creates a new helper object.
     * 
     * @param dynaPico
     *            the <code>DynaPico</code> object to use for configuring the
     *            Pico container and applying aspects.
     */
    public DynaPicoScriptHelper(DynaPico dynaPico) {
        this.dynaPico = dynaPico;
        this.bshHelper = createBshHelper(dynaPico.getAspects());
    }

    public void componentInterceptor(Object componentKey,
            MethodPointcut methodPointcut, Interceptor interceptor) {
        dynaPico
                .componentInterceptor(componentKey, methodPointcut, interceptor);
    }

    public void componentMixin(Object componentKey, Class[] interfaces,
            Class mixinClass) {
        dynaPico.componentMixin(componentKey, interfaces, mixinClass);
    }

    public void containerSuppliedComponentInterceptor(Object componentKey,
            MethodPointcut methodPointcut, Object interceptorComponentKey) {
        dynaPico.containerSuppliedComponentInterceptor(componentKey,
                methodPointcut, interceptorComponentKey);
    }

    public void containerSuppliedComponentMixin(Object componentKey,
            Class[] interfaces, Object mixinComponentKey) {
        dynaPico.containerSuppliedComponentMixin(componentKey, interfaces,
                mixinComponentKey);
    }

    public void containerSuppliedInterceptor(Object classPointcut,
            MethodPointcut methodPointcut, Object interceptorComponentKey) {
        dynaPico.containerSuppliedInterceptor(toClassPointcut(classPointcut),
                methodPointcut, interceptorComponentKey);
    }

    public void containerSuppliedMixin(Object classPointcut,
            Class[] interfaces, Object mixinComponentKey) {
        dynaPico.containerSuppliedMixin(toClassPointcut(classPointcut),
                interfaces, mixinComponentKey);
    }

    public void dispose() {
        dynaPico.dispose();
    }

    public ComponentAdapter getComponentAdapter(Object componentKey) {
        return dynaPico.getComponentAdapter(componentKey);
    }

    public ComponentAdapter getComponentAdapterOfType(Class componentType) {
        return dynaPico.getComponentAdapterOfType(componentType);
    }

    public Collection getComponentAdapters() {
        return dynaPico.getComponentAdapters();
    }

    public List getComponentAdaptersOfType(Class componentType) {
        return dynaPico.getComponentAdaptersOfType(componentType);
    }

    public Object getComponentInstance(Object componentKey) {
        return dynaPico.getComponentInstance(componentKey);
    }

    public Object getComponentInstanceOfType(Class componentType) {
        return dynaPico.getComponentInstanceOfType(componentType);
    }

    public List getComponentInstances() {
        return dynaPico.getComponentInstances();
    }

    public PicoContainer getParent() {
        return dynaPico.getParent();
    }

    //********************************************************************
    // Pointcut convenience methods.
    //********************************************************************

    public MethodPointcut declaringClass(Object o)
            throws MalformedPatternException {
        return bshHelper.declaringClass(o);
    }

    public MethodPointcut returnType(Object o) throws MalformedPatternException {
        return bshHelper.returnType(o);
    }

    public Object union(Object a, Object b) throws MalformedPatternException {
        return bshHelper.union(a, b);
    }

    public Object intersection(Object a, Object b)
            throws MalformedPatternException {
        return bshHelper.intersection(a, b);
    }

    //********************************************************************
    // Mixin convenience methods.
    //********************************************************************

    public void mixin(Object classPointcut, Class[] interfaces, Class mixin,
            Closure initializer) throws MalformedPatternException {
        bshHelper.mixin(classPointcut, interfaces, mixin, initializer);
    }

    public void mixin(Object classPointcut, Class[] interfaces, Class mixin)
            throws MalformedPatternException {
        bshHelper.mixin(classPointcut, interfaces, mixin);
    }

    public void mixin(Object classPointcut, Class[] interfaces,
            MixinFactory mixinFactory) throws MalformedPatternException {
        bshHelper.mixin(classPointcut, interfaces, mixinFactory);
    }

    public void mixin(Object classPointcut, Class mixin, Closure initializer)
            throws MalformedPatternException {
        bshHelper.mixin(classPointcut, mixin, initializer);
    }

    public void mixin(Object classPointcut, Class mixin)
            throws MalformedPatternException {
        bshHelper.mixin(classPointcut, mixin);
    }

    public void interfaces(Object classPointcut, Class[] interfaces)
            throws MalformedPatternException {
        bshHelper.interfaces(classPointcut, interfaces);
    }

    //********************************************************************
    // Interceptor convenience methods.
    //********************************************************************

    public void interceptor(Object classPointcut, Object methodPointcut,
            Interceptor interceptor) throws MalformedPatternException {
        bshHelper.interceptor(classPointcut, methodPointcut, interceptor);
    }

    public void interceptor(Object classPointcut, Object methodPointcut,
            InterceptorFactory interceptorFactory)
            throws MalformedPatternException {
        bshHelper
                .interceptor(classPointcut, methodPointcut, interceptorFactory);
    }

    public void interceptor(ClassPointcut classPointcut,
            MethodPointcut methodPointcut, Interceptor interceptor) {
        dynaPico.interceptor(classPointcut, methodPointcut, interceptor);
    }

    public void mixin(ClassPointcut classPointcut, Class mixinClass) {
        dynaPico.mixin(classPointcut, mixinClass);
    }

    public void mixin(ClassPointcut classPointcut, Class[] interfaces,
            Class mixinClass) {
        dynaPico.mixin(classPointcut, interfaces, mixinClass);
    }

    public ComponentAdapter registerComponent(ComponentAdapter componentAdapter)
            throws PicoRegistrationException {
        return dynaPico.registerComponent(componentAdapter);
    }

    public ComponentAdapter registerComponentImplementation(
            Class componentImplementation) throws PicoRegistrationException {
        return dynaPico
                .registerComponentImplementation(componentImplementation);
    }

    public ComponentAdapter registerComponentImplementation(
            Object componentKey, Class componentImplementation)
            throws PicoRegistrationException {
        return dynaPico.registerComponentImplementation(componentKey,
                componentImplementation);
    }

    public ComponentAdapter registerComponentImplementation(
            Object componentKey, Class componentImplementation,
            Parameter[] parameters) throws PicoRegistrationException {
        return dynaPico.registerComponentImplementation(componentKey,
                componentImplementation, parameters);
    }

    public ComponentAdapter registerComponentInstance(Object componentInstance)
            throws PicoRegistrationException {
        return dynaPico.registerComponentInstance(componentInstance);
    }

    public ComponentAdapter registerComponentInstance(Object componentKey,
            Object componentInstance) throws PicoRegistrationException {
        return dynaPico.registerComponentInstance(componentKey,
                componentInstance);
    }

    public void start() {
        dynaPico.start();
    }

    public void stop() {
        dynaPico.stop();
    }

    public ComponentAdapter unregisterComponent(Object componentKey) {
        return dynaPico.unregisterComponent(componentKey);
    }

    public ComponentAdapter unregisterComponentByInstance(
            Object componentInstance) {
        return dynaPico.unregisterComponentByInstance(componentInstance);
    }

    public void verify() throws PicoVerificationException {
        dynaPico.verify();
    }

    private static BshHelper createBshHelper(Aspects aspects) {
        try {
            Constructor constructor = BshHelper.class
                    .getDeclaredConstructor(new Class[] { Aspects.class });
            constructor.setAccessible(true);
            return (BshHelper) constructor
                    .newInstance(new Object[] { aspects });
        } catch (SecurityException e) {
            throw new PicoIntrospectionException(e);
        } catch (NoSuchMethodException e) {
            throw new PicoIntrospectionException(e);
        } catch (IllegalArgumentException e) {
            throw new PicoIntrospectionException(e);
        } catch (InstantiationException e) {
            throw new PicoIntrospectionException(e);
        } catch (IllegalAccessException e) {
            throw new PicoIntrospectionException(e);
        } catch (InvocationTargetException e) {
            throw new PicoIntrospectionException(e);
        }
    }

    private ClassPointcut toClassPointcut(Object o) {
        return (ClassPointcut) invokeBshHelperMethod("toClassPointcut", o);
    }

    private MethodPointcut toMethodPointcut(Object o) {
        return (MethodPointcut) invokeBshHelperMethod("toMethodPointcut", o);
    }

    private Object invokeBshHelperMethod(String methodName, Object o) {
        try {
            Method method = BshHelper.class.getDeclaredMethod(methodName,
                    new Class[] { Object.class });
            method.setAccessible(true);
            return method.invoke(bshHelper, new Object[] { o });
        } catch (SecurityException e) {
            throw new PicoIntrospectionException(e);
        } catch (NoSuchMethodException e) {
            throw new PicoIntrospectionException(e);
        } catch (IllegalArgumentException e) {
            throw new PicoIntrospectionException(e);
        } catch (IllegalAccessException e) {
            throw new PicoIntrospectionException(e);
        } catch (InvocationTargetException e) {
            throw new PicoIntrospectionException(e);
        }
    }

}