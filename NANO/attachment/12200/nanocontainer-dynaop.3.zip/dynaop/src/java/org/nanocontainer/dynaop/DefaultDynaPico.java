/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import java.util.Collection;
import java.util.List;

import org.picocontainer.ComponentAdapter;
import org.picocontainer.MutablePicoContainer;
import org.picocontainer.Parameter;
import org.picocontainer.PicoContainer;
import org.picocontainer.PicoRegistrationException;
import org.picocontainer.PicoVerificationException;
import org.picocontainer.defaults.ComponentAdapterFactory;
import org.picocontainer.defaults.DefaultComponentAdapterFactory;
import org.picocontainer.defaults.DefaultPicoContainer;

import dynaop.Aspects;
import dynaop.ClassPointcut;
import dynaop.Interceptor;
import dynaop.MethodPointcut;

/**
 * @author Stephen Molitor
 */
public class DefaultDynaPico implements DynaPico {

    private final Aspects aspects = new Aspects();
    private final ComponentAdapterFactory delegateAdapterFactory = new DefaultComponentAdapterFactory();
    private final AspectsComponentAdapterFactory aspectsAdapterFactory = new AspectsComponentAdapterFactory(
            delegateAdapterFactory, aspects);
    private final MutablePicoContainer delegateContainer;

    public DefaultDynaPico() {
        this(null);
    }

    public DefaultDynaPico(PicoContainer parentContainer) {
        delegateContainer = new DefaultPicoContainer(aspectsAdapterFactory,
                parentContainer);
    }

    public void interfaces(ClassPointcut classPointcut, Class[] interfaces) {
        aspects.interfaces(classPointcut, interfaces);
    }

    public void interceptor(ClassPointcut classPointcut,
            MethodPointcut methodPointcut, Interceptor interceptor) {
        aspects.interceptor(classPointcut, methodPointcut, interceptor);
    }

    public void mixin(ClassPointcut classPointcut, Class[] interfaces,
            Class mixinClass) {
        aspects.mixin(classPointcut, interfaces, mixinClass,
                EmptyInitializer.INSTANCE);
    }

    public void mixin(ClassPointcut classPointcut, Class mixinClass) {
        aspects.mixin(classPointcut, mixinClass, EmptyInitializer.INSTANCE);
    }

    public void containerSuppliedInterceptor(ClassPointcut classPointcut,
            MethodPointcut methodPointcut, Object interceptorComponentKey) {
        aspects.interceptor(classPointcut, methodPointcut,
                new PicoInterceptorFactory(this, interceptorComponentKey));
    }

    public void containerSuppliedMixin(ClassPointcut classPointcut,
            Class[] interfaces, Object mixinComponentKey) {
        aspects.mixin(classPointcut, interfaces, new PicoMixinFactory(this,
                mixinComponentKey));
    }

    public void componentInterceptor(Object componentKey,
            MethodPointcut methodPointcut, Interceptor interceptor) {
        aspectsAdapterFactory.addComponentAdvice(componentKey,
                new InstanceInterceptorAdvice(methodPointcut, interceptor));
    }

    public void componentMixin(Object componentKey, Class[] interfaces,
            Class mixinClass) {
        aspectsAdapterFactory.addComponentAdvice(componentKey,
                new InstanceMixinAdvice(interfaces, mixinClass));
    }

    public void containerSuppliedComponentInterceptor(Object componentKey,
            MethodPointcut methodPointcut, Object interceptorComponentKey) {
        aspectsAdapterFactory.addComponentAdvice(componentKey,
                new InstanceInterceptorAdvice(methodPointcut,
                        new PicoInterceptorFactory(this,
                                interceptorComponentKey)));
    }

    public void containerSuppliedComponentMixin(Object componentKey,
            Class[] interfaces, Object mixinComponentKey) {
        aspectsAdapterFactory.addComponentAdvice(componentKey,
                new InstanceMixinAdvice(interfaces, new PicoMixinFactory(this,
                        mixinComponentKey)));

    }

    public void addOrderedComponentAdapter(ComponentAdapter componentAdapter) {
        delegateContainer.addOrderedComponentAdapter(componentAdapter);
    }

    public void dispose() {
        delegateContainer.dispose();
    }

    public ComponentAdapter getComponentAdapter(Object componentKey) {
        return delegateContainer.getComponentAdapter(componentKey);
    }

    public ComponentAdapter getComponentAdapterOfType(Class componentType) {
        return delegateContainer.getComponentAdapterOfType(componentType);
    }

    public Collection getComponentAdapters() {
        return delegateContainer.getComponentAdapters();
    }

    public List getComponentAdaptersOfType(Class componentType) {
        return delegateContainer.getComponentAdaptersOfType(componentType);
    }

    public Object getComponentInstance(Object componentKey) {
        return delegateContainer.getComponentInstance(componentKey);
    }

    public Object getComponentInstanceOfType(Class componentType) {
        return delegateContainer.getComponentInstanceOfType(componentType);
    }

    public List getComponentInstances() {
        return delegateContainer.getComponentInstances();
    }

    public PicoContainer getParent() {
        return delegateContainer.getParent();
    }

    public ComponentAdapter registerComponent(ComponentAdapter componentAdapter)
            throws PicoRegistrationException {
        return delegateContainer.registerComponent(componentAdapter);
    }

    public ComponentAdapter registerComponentImplementation(
            Class componentImplementation) throws PicoRegistrationException {
        return delegateContainer
                .registerComponentImplementation(componentImplementation);
    }

    public ComponentAdapter registerComponentImplementation(
            Object componentKey, Class componentImplementation)
            throws PicoRegistrationException {
        return delegateContainer.registerComponentImplementation(componentKey,
                componentImplementation);
    }

    public ComponentAdapter registerComponentImplementation(
            Object componentKey, Class componentImplementation,
            Parameter[] parameters) throws PicoRegistrationException {
        return delegateContainer.registerComponentImplementation(componentKey,
                componentImplementation, parameters);
    }

    public ComponentAdapter registerComponentInstance(Object componentInstance)
            throws PicoRegistrationException {
        return delegateContainer.registerComponentInstance(componentInstance);
    }

    public ComponentAdapter registerComponentInstance(Object componentKey,
            Object componentInstance) throws PicoRegistrationException {
        return delegateContainer.registerComponentInstance(componentKey,
                componentInstance);
    }

    public void setParent(PicoContainer parent) {
        delegateContainer.setParent(parent);
    }

    public void start() {
        delegateContainer.start();
    }

    public void stop() {
        delegateContainer.stop();
    }

    public ComponentAdapter unregisterComponent(Object componentKey) {
        return delegateContainer.unregisterComponent(componentKey);
    }

    public ComponentAdapter unregisterComponentByInstance(
            Object componentInstance) {
        return delegateContainer
                .unregisterComponentByInstance(componentInstance);
    }

    public void verify() throws PicoVerificationException {
        delegateContainer.verify();
    }

    public Aspects getAspects() {
        return aspects;
    }

    public MutablePicoContainer getPico() {
        return delegateContainer;
    }

}