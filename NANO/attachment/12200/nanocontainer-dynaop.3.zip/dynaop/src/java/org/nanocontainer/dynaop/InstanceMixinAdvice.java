/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import dynaop.Aspects;
import dynaop.MixinFactory;
import dynaop.Pointcuts;

/**
 * Mixin advice that applies to just one component instance.
 * 
 * @author Stephen Molitor
 */
public class InstanceMixinAdvice implements InstanceAspect {

    private final Class[] interfaces;
    private Class mixinClass;
    private MixinFactory mixinFactory;

    /**
     * Creates a new <code>InstanceMixinAdvice</code> object.
     * 
     * @param interfaces
     *            interfaces that the mixin implements.
     * @param mixinClass
     *            the mixin class.
     */
    public InstanceMixinAdvice(Class[] interfaces, Class mixinClass) {
        this.interfaces = interfaces;
        this.mixinClass = mixinClass;
    }

    /**
     * Creates a new <code>InstanceMixinAdvice</code> object.
     * 
     * @param interfaces
     *            interfaces that the mixin implements.
     * @param mixinFactory
     *            the factory used to produce the mixin.
     */
    public InstanceMixinAdvice(Class[] interfaces, MixinFactory mixinFactory) {
        this.interfaces = interfaces;
        this.mixinFactory = mixinFactory;
    }

    public void apply(Aspects aspects) {
        if (mixinClass != null) {
            aspects.mixin(Pointcuts.ALL_CLASSES, interfaces, mixinClass,
                    EmptyInitializer.INSTANCE);
        } else {
            aspects.mixin(Pointcuts.ALL_CLASSES, interfaces, mixinFactory);
        }
    }

}