/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * @author Stephen Molitor
 */
public class AbstractNanoDynaopTestCase extends TestCase {

    public void verifyIdentifiable(MyComponent myComponent) {
        Identifiable identifiable = (Identifiable) myComponent;
        Assert.assertEquals(new Integer(0), identifiable.getId());
        identifiable.setId(new Integer(1));
        Assert.assertEquals(new Integer(1), identifiable.getId());
    }

    public void verifyIntercepted(MyComponent myComponent, StringBuffer log) {
        assertEquals("", log.toString());
        myComponent.aMethod();
        assertEquals("startend", log.toString());
    }

}