/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import org.picocontainer.ComponentAdapter;
import org.picocontainer.MutablePicoContainer;
import org.picocontainer.defaults.ConstructorInjectionComponentAdapter;
import org.picocontainer.defaults.DefaultPicoContainer;

import dynaop.Aspects;
import dynaop.Pointcuts;

/**
 * @author Stephen Molitor
 */
public class AspectsComponentAdapterTestCase extends AbstractNanoDynaopTestCase {

    private MutablePicoContainer container = new DefaultPicoContainer();
    private Aspects aspects = new Aspects();
    private StringBuffer log = new StringBuffer();
    private LoggingInterceptor loggingInterceptor = new LoggingInterceptor(log);
    private ComponentAdapter delegateCA = new ConstructorInjectionComponentAdapter(
            MyComponent.class, MyComponentImpl.class);

    public void testGeneralAspectsOnly() {
        aspects.interceptor(Pointcuts.instancesOf(MyComponent.class),
                Pointcuts.ALL_METHODS, loggingInterceptor);
        container.registerComponent(new AspectsComponentAdapter(aspects,
                delegateCA));
        MyComponent myComponent = (MyComponent) container
                .getComponentInstance(MyComponent.class);
        verifyIntercepted(myComponent, log);
    }

    public void testComponentAspects() {
        aspects.interceptor(Pointcuts.instancesOf(MyComponent.class),
                Pointcuts.ALL_METHODS, loggingInterceptor);
        InstanceAspectsCollection componentAspects = new InstanceAspectsCollection();
        componentAspects.add(new InstanceInterceptorAdvice(
                Pointcuts.ALL_METHODS, loggingInterceptor));
        container.registerComponent(new AspectsComponentAdapter(aspects,
                delegateCA, componentAspects));

        MyComponent myComponent = (MyComponent) container
                .getComponentInstance(MyComponent.class);

        assertEquals("", log.toString());
        myComponent.aMethod();
        assertEquals("startstartendend", log.toString());
    }

}