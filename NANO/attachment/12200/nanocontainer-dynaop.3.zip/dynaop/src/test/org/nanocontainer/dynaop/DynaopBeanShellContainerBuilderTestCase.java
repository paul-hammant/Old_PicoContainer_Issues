/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import java.io.FileReader;

import org.nanocontainer.NanoContainer;
import org.nanocontainer.integrationkit.ContainerBuilder;
import org.picocontainer.PicoContainer;
import org.picocontainer.defaults.DefaultPicoContainer;
import org.picocontainer.defaults.ObjectReference;
import org.picocontainer.defaults.SimpleReference;

/**
 * @author Stephen Molitor
 */
public class DynaopBeanShellContainerBuilderTestCase extends
        AbstractNanoDynaopTestCase {

    public void testBasicPicoConfig() throws Exception {
        PicoContainer parent = new DefaultPicoContainer();
        PicoContainer pico = buildContainer("basicPicoConfig.bsh", parent,
                "testScope");
        MyComponent viaAdapter = (MyComponent) pico
                .getComponentInstance("viaAdapter");
        assertNotNull(viaAdapter);
        assertEquals("paramValue", viaAdapter.getParam());

        MyComponent viaImplOneArg = (MyComponent) pico
                .getComponentInstance(MyComponentImpl.class);
        assertNotNull(viaImplOneArg);

        MyComponent viaImplTwoArgs = (MyComponent) pico
                .getComponentInstance("viaImplTwoArgs");
        assertNotNull(viaImplTwoArgs);

        MyComponent withParam = (MyComponent) pico
                .getComponentInstance("withParam");
        assertNotNull(withParam);
        assertEquals("paramValue", withParam.getParam());

        assertEquals("testScope", pico.getComponentInstance("assemblyScope"));
    }

    public void testBasicAspectsConfig() throws Exception {
        PicoContainer pico = buildContainer("basicAspectsConfig.bsh", null,
                null);
        MyComponent myComponent = (MyComponent) pico
                .getComponentInstance(MyComponent.class);
        StringBuffer log = (StringBuffer) pico.getComponentInstance("log");

        assertNotNull(myComponent);
        assertNotNull(log);

        assertEquals("", log.toString());
        myComponent.aMethod();
        assertEquals("startend", log.toString());
        verifyIdentifiable(myComponent);
    }

    public void testContainerSuppliedInterceptor() throws Exception {
        PicoContainer pico = buildContainer("containerSuppliedInterceptor.bsh",
                null, null);
        MyComponent myComponent = (MyComponent) pico
                .getComponentInstance(MyComponent.class);
        StringBuffer log = (StringBuffer) pico
                .getComponentInstance(StringBuffer.class);
        assertNotNull(log);
        assertEquals("", log.toString());
        myComponent.aMethod();
        assertEquals("startend", log.toString());
    }

    public void testContainerSuppliedMixin() throws Exception {
        PicoContainer pico = buildContainer("containerSuppliedMixin.bsh", null,
                null);
        MyComponent myComponent = (MyComponent) pico
                .getComponentInstance(MyComponent.class);
        verifyIdentifiable(myComponent);
    }

    public void testComponentInterceptor() throws Exception {
        PicoContainer pico = buildContainer("componentInterceptor.bsh", null,
                null);
        MyComponent hasInterceptor = (MyComponent) pico
                .getComponentInstance("hasInterceptor");
        MyComponent doesNotHaveInterceptor = (MyComponent) pico
                .getComponentInstance("doesNotHaveInterceptor");
        assertNotNull(hasInterceptor);
        assertNotNull(doesNotHaveInterceptor);

        StringBuffer log = (StringBuffer) pico
                .getComponentInstance(StringBuffer.class);
        assertNotNull(log);
        assertEquals("", log.toString());

        doesNotHaveInterceptor.aMethod();
        assertEquals("", log.toString());

        hasInterceptor.aMethod();
        assertEquals("startend", log.toString());
    }

    public void testComponentMixin() throws Exception {
        PicoContainer pico = buildContainer("componentMixin.bsh", null, null);
        MyComponent hasMixin = (MyComponent) pico
                .getComponentInstance("hasMixin");
        MyComponent doesNotHaveMixin = (MyComponent) pico
                .getComponentInstance("doesNotHaveMixin");
        assertNotNull(hasMixin);
        assertNotNull(doesNotHaveMixin);
        verifyIdentifiable(hasMixin);
        assertFalse(doesNotHaveMixin instanceof Identifiable);
    }

    public void testContainerSuppliedComponentInterceptor() throws Exception {
        PicoContainer pico = buildContainer(
                "containerSuppliedComponentInterceptor.bsh", null, null);
        MyComponent myComponent = (MyComponent) pico
                .getComponentInstance(MyComponent.class);
        assertNotNull(myComponent);
        StringBuffer log = (StringBuffer) pico
                .getComponentInstance(StringBuffer.class);
        assertEquals("", log.toString());
        myComponent.aMethod();
        assertEquals("startend", log.toString());
    }

    public void testContainerSuppliedComponentMixin() throws Exception {
        PicoContainer pico = buildContainer(
                "containerSuppliedComponentMixin.bsh", null, null);
        MyComponent myComponent = (MyComponent) pico
                .getComponentInstance(MyComponent.class);
        assertNotNull(myComponent);
        verifyIdentifiable(myComponent);
    }

    public void testExample() throws Exception {
        PicoContainer pico = buildContainer("example.bsh", null, null);
        MyComponent myComponent = (MyComponent) pico
                .getComponentInstance(MyComponent.class);
        assertNotNull(myComponent);

        StringBuffer log = (StringBuffer) pico.getComponentInstance("log");
        verifyIntercepted(myComponent, log);
    }

    private PicoContainer buildContainer(String testFile,
            PicoContainer parentContainer, Object assemblyScope)
            throws Exception {
        NanoContainer nanoContainer = new NanoContainer(new FileReader(
                "./src/test/org/nanocontainer/dynaop/" + testFile),
                DynaPicoBeanShellContainerBuilder.class.getName());
        ObjectReference containerRef = new SimpleReference();
        ObjectReference parentRef = new SimpleReference();
        parentRef.set(parentContainer);
        ContainerBuilder builder = nanoContainer.getContainerBuilder();
        builder.buildContainer(containerRef, parentRef, assemblyScope);
        return (PicoContainer) containerRef.get();
    }

}