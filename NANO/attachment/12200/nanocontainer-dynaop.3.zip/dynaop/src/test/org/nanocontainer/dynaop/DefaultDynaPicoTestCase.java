/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import dynaop.Interceptor;
import dynaop.Pointcuts;

/**
 * @author Stephen Molitor
 */
public class DefaultDynaPicoTestCase extends AbstractNanoDynaopTestCase {

    private DynaPico dynaPico = new DefaultDynaPico();

    public void testContainerSuppliedInterceptor() {
        dynaPico.registerComponentImplementation(MyComponent.class,
                MyComponentImpl.class);
        dynaPico.registerComponentImplementation(StringBuffer.class);
        dynaPico.registerComponentImplementation(LoggingInterceptor.class);
        dynaPico.containerSuppliedInterceptor(Pointcuts
                .instancesOf(MyComponent.class), Pointcuts.ALL_METHODS,
                LoggingInterceptor.class);

        StringBuffer log = (StringBuffer) dynaPico
                .getComponentInstance(StringBuffer.class);

        MyComponent myComponent = (MyComponent) dynaPico
                .getComponentInstance(MyComponent.class);
        assertEquals("", log.toString());
        myComponent.aMethod();
        assertEquals("startend", log.toString());
    }

    public void testContainerSuppliedMixin() {
        dynaPico.registerComponentImplementation(MyComponent.class,
                MyComponentImpl.class);
        dynaPico.registerComponentImplementation(IdentifiableMixin.class);
        dynaPico.containerSuppliedComponentMixin(MyComponent.class,
                new Class[] { Identifiable.class }, IdentifiableMixin.class);

        MyComponent myComponent = (MyComponent) dynaPico
                .getComponentInstance(MyComponent.class);
        verifyIdentifiable(myComponent);
    }

    public void testComponentInterceptor() {
        StringBuffer log = new StringBuffer();
        Interceptor interceptor = new LoggingInterceptor(log);

        dynaPico.registerComponentImplementation("doesNotHaveInterceptor",
                MyComponentImpl.class);
        dynaPico.registerComponentImplementation("hasInterceptor",
                MyComponentImpl.class);

        dynaPico.componentInterceptor("hasInterceptor", Pointcuts.ALL_METHODS,
                interceptor);

        MyComponent doesNotHaveInterceptor = (MyComponent) dynaPico
                .getComponentInstance("doesNotHaveInterceptor");
        MyComponent hasInterceptor = (MyComponent) dynaPico
                .getComponentInstance("hasInterceptor");

        assertEquals("", log.toString());
        doesNotHaveInterceptor.aMethod();
        assertEquals("", log.toString());

        hasInterceptor.aMethod();
        assertEquals("startend", log.toString());
    }

    public void testComponentInterceptorReverseConfigurationOrder() {
        StringBuffer log = new StringBuffer();
        Interceptor interceptor = new LoggingInterceptor(log);

        // configure the interceptor before configuring the component
        // that it will interceptor.
        dynaPico.componentInterceptor("hasInterceptor", Pointcuts.ALL_METHODS,
                interceptor);

        dynaPico.registerComponentImplementation("doesNotHaveInterceptor",
                MyComponentImpl.class);
        dynaPico.registerComponentImplementation("hasInterceptor",
                MyComponentImpl.class);

        MyComponent doesNotHaveInterceptor = (MyComponent) dynaPico
                .getComponentInstance("doesNotHaveInterceptor");
        MyComponent hasInterceptor = (MyComponent) dynaPico
                .getComponentInstance("hasInterceptor");

        assertEquals("", log.toString());
        doesNotHaveInterceptor.aMethod();
        assertEquals("", log.toString());

        hasInterceptor.aMethod();
        assertEquals("startend", log.toString());
    }

    public void testComponentMixin() {
        dynaPico.componentMixin(MyComponent.class,
                new Class[] { Identifiable.class }, IdentifiableMixin.class);
        dynaPico.registerComponentImplementation(MyComponent.class,
                MyComponentImpl.class);

        MyComponent myComponent = (MyComponent) dynaPico
                .getComponentInstance(MyComponent.class);
        verifyIdentifiable(myComponent);
    }

    public void testContainerSuppliedComponentInterceptor() {
        dynaPico.registerComponentImplementation(StringBuffer.class);
        dynaPico.registerComponentImplementation(LoggingInterceptor.class);
        dynaPico.registerComponentImplementation(MyComponent.class,
                MyComponentImpl.class);
        dynaPico.containerSuppliedComponentInterceptor(MyComponent.class,
                Pointcuts.ALL_METHODS, LoggingInterceptor.class);

        StringBuffer log = (StringBuffer) dynaPico
                .getComponentInstance(StringBuffer.class);
        MyComponent myComponent = (MyComponent) dynaPico
                .getComponentInstance(MyComponent.class);

        assertEquals("", log.toString());
        myComponent.aMethod();
        assertEquals("startend", log.toString());
    }

    public void testContainerSuppliedComponentMixin() {
        dynaPico.registerComponentImplementation(IdentifiableMixin.class);
        dynaPico.registerComponentImplementation(MyComponent.class,
                MyComponentImpl.class);
        dynaPico.containerSuppliedComponentMixin(MyComponent.class,
                new Class[] { Identifiable.class }, IdentifiableMixin.class);
    }

}