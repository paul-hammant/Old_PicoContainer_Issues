/*****************************************************************************
 * Copyright (c) PicoContainer Organization. All rights reserved.            *
 * ------------------------------------------------------------------------- *
 * The software in this package is published under the terms of the BSD      *
 * style license a copy of which has been included with this distribution in *
 * the license.html file.                                                    *
 *                                                                           *
 * Idea by Rachel Davies, Original code by Aslak Hellesoy and Paul Hammant   *
 *****************************************************************************/
package org.nanocontainer.dynaop;

import org.picocontainer.MutablePicoContainer;
import org.picocontainer.Parameter;
import org.picocontainer.defaults.ComponentParameter;

import dynaop.Pointcuts;

/**
 * @author Stephen Molitor
 */
public class ExamplesTestCase extends AbstractNanoDynaopTestCase {

    private StringBuffer log = new StringBuffer();

    public void testExample1() {
        DynaPico dynaPico = new DefaultDynaPico();
        dynaPico.registerComponentImplementation(MyComponent.class,
                MyComponentImpl.class);
        dynaPico.interceptor(Pointcuts.instancesOf(MyComponent.class),
                Pointcuts.ALL_METHODS, new LoggingInterceptor(log));

        MutablePicoContainer pico = dynaPico.getPico();
        MyComponent myComponent = (MyComponent) pico
                .getComponentInstance(MyComponent.class);
        myComponent.aMethod(); // should see log messages in the console

        assertEquals("startend", log.toString());
    }

    public void testExample2() {
        DynaPico dynaPico = new DefaultDynaPico();
        dynaPico.registerComponentImplementation("hasInterceptor",
                MyComponentImpl.class);
        dynaPico.registerComponentImplementation("doesNotHaveInterceptor",
                MyComponentImpl.class);

        dynaPico.componentInterceptor("hasInterceptor", Pointcuts.ALL_METHODS,
                new LoggingInterceptor(log));

        MutablePicoContainer pico = dynaPico.getPico();
        MyComponent hasInterceptor = (MyComponent) pico
                .getComponentInstance("hasInterceptor");
        MyComponent doesNotHaveInterceptor = (MyComponent) pico
                .getComponentInstance("doesNotHaveInterceptor");

        hasInterceptor.aMethod(); // should see log messages in console
        doesNotHaveInterceptor.aMethod(); // should NOT see log messages in
        // console

        assertEquals("startend", log.toString());
    }

    public void testExample3() {
        DynaPico dynaPico = new DefaultDynaPico();
        dynaPico.registerComponentImplementation(MyComponent.class,
                MyComponentImpl.class);
        dynaPico.registerComponentImplementation("log", StringBuffer.class);
        dynaPico.registerComponentImplementation("loggingInterceptor",
                LoggingInterceptor.class,
                new Parameter[] { new ComponentParameter("log") });

        // Apply the 'debuggingInterceptor' component to all methods of all
        // instances of
        // MyComponent:
        dynaPico.containerSuppliedInterceptor(Pointcuts
                .instancesOf(MyComponent.class), Pointcuts.ALL_METHODS,
                "loggingInterceptor");

        StringBuffer log = (StringBuffer) dynaPico.getPico()
                .getComponentInstance("log");
        MyComponent myComponent = (MyComponent) dynaPico.getPico()
                .getComponentInstance(MyComponent.class);
        verifyIntercepted(myComponent, log);
    }

    public void testExample4() {
        DynaPico dynaPico = new DefaultDynaPico();
        dynaPico.registerComponentImplementation(MyComponent.class,
                MyComponentImpl.class);
        dynaPico.registerComponentImplementation("log", StringBuffer.class);
        dynaPico.registerComponentImplementation("loggingInterceptor",
                LoggingInterceptor.class,
                new Parameter[] { new ComponentParameter("log") });

        dynaPico.containerSuppliedComponentInterceptor(MyComponent.class,
                Pointcuts.ALL_METHODS, "loggingInterceptor");

        StringBuffer log = (StringBuffer) dynaPico.getPico()
                .getComponentInstance("log");
        MyComponent myComponent = (MyComponent) dynaPico.getPico()
                .getComponentInstance(MyComponent.class);
        verifyIntercepted(myComponent, log);
    }

}