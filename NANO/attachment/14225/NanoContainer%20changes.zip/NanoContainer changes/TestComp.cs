using System;

public class TestComp 
{
	public TestComp() 
	{
	}
}
